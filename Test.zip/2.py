# -*- coding: utf-8 -*-

import LINETCR
from LINETCR.lib.curve.ttypes import *
from datetime import datetime
import time, random, sys, ast, re, os, io, json, subprocess, threading, string, codecs, requests, ctypes, urllib, urllib2, urllib3, wikipedia, tempfile
from bs4 import BeautifulSoup
from urllib import urlopen
from io import StringIO
from threading import Thread
from gtts import gTTS
from googletrans import Translator

#cl = LINETCR.LINE()
#cl.login(qr=True)
#cl.loginResult()

cl = LINETCR.LINE()
cl.login(token="Er1cbiPTJO2GJ7SV0Kn7.v6vlKucf+QBWtbN2+LIqvW.0nZJ3n6p3221t/ErJPgIscxeoAPbyQzx+0t4AC8BFPo=")
cl.loginResult()
#ue8b464b7b97ecb946f763ad07e7a7533
print "==================[Login Success]==================="
reload(sys)
sys.setdefaultencoding('utf-8')

helpmsg ="""╔════ஜ🎲🎓🎲ஜ═══╗
║             🎩^$€^™^β¤t^🎩         ║
╚════ஜ🎲🎓🎲ஜ═══╝
⚖Hᴇʟᴘ ᴘᴄ
⚖Hᴇʟᴘ sᴇʟғ
⚖Hᴇʟᴘ ɢʀᴜᴘ
⚖Hᴇʟᴘ sᴇᴛ
⚖Hᴇʟᴘ ᴋɪᴄᴋ
⚖Hᴇʟᴘ ᴍᴇᴅɪᴀ
⚖Hᴇʟᴘ ᴏᴛʜᴇʀ
⚖Hᴇʟᴘ ᴄᴏsᴛᴜᴍᴇ
╔════ஜ🎲🎓🎲ஜ═══╗
║  line.me/ti/p/mt6qgzsLee     ║
╚════ஜ🎲🎓🎲ஜ═══╝
"""

helppc ="""╔════ஜ🎲🎓🎲ஜ═══╗
║             🎩^$€^™^β¤t^🎩         ║
╚════ஜ🎲🎓🎲ஜ═══╝
⚖Sᴘᴇᴇᴅ
⚖Rᴜɴᴛɪᴍᴇ
⚖Bᴏᴛ ᴏɴ
⚖Bᴏᴛ ᴍᴍᴜᴛᴇ
⚖Rᴇsᴛᴀʀᴛ
⚖Tᴜʀɴ ᴏғғ 
╔════ஜ🎲🎓🎲ஜ═══╗
║  line.me/ti/p/mt6qgzsLee     ║
╚════ஜ🎲🎓🎲ஜ═══╝
"""

helpkick ="""╔════ஜ🎲🎓🎲ஜ═══╗
║             🎩^$€^™^β¤t^🎩         ║
╚════ஜ🎲🎓🎲ஜ═══╝
⚖ʙᴜɴᴜʜ.@.
⚖ᴋɪᴄᴋ.@.
⚖ᴜʟᴛɪ.@.
⚖ᴄʟɴ
⚖ɴᴋ
⚖ʀᴇʟᴀxɪɴɢ
⚖ᴄᴀɴᴄᴇʟ
╠════ஜ🎲🎓🎲ஜ═══╣
⚖ʙᴀɴ.@.
⚖ᴍɪᴅʙᴀɴ
⚖ᴜɴʙᴀɴ.@.
⚖ᴄʟᴇᴀʀʙᴀɴ
⚖ʙᴀɴʟɪsᴛ
╔════ஜ🎲🎓🎲ஜ═══╗
║  line.me/ti/p/mt6qgzsLee     ║
╚════ஜ🎲🎓🎲ஜ═══╝
"""

helpself ="""╔════ஜ🎲🎓🎲ஜ═══╗
║             🎩^$€^™^β¤t^🎩         ║
╚════ஜ🎲🎓🎲ஜ═══╝
⚖Cʀᴇᴀᴛᴏʀ
⚖Mᴇ
⚖Mʏᴍɪᴅ
⚖Mʏɴᴀᴍᴇ:
⚖Mʏʙɪᴏ:
⚖Mʏᴘɪᴄᴛ
⚖Gʟɪsᴛ
⚖Gʀᴜᴘʟɪsᴛ
⚖Gᴄᴀɴᴄᴇʟ
⚖ʀᴇᴍᴏᴠᴇᴄʜᴀᴛ.
⚖Mᴇɴᴛɪᴏɴ/Cɪʟᴜᴋ ʙᴀᴀ 
╠═══ஜ🎲🎓🎲ஜ═══╣
⚖Gᴇᴛᴍɪᴅ 
⚖Gᴇᴛᴘʀᴏғɪʟᴇ
⚖Gᴇᴛᴄᴏɴᴛᴀᴄᴛ
⚖Gᴇᴛɪɴғᴏ
⚖Gᴇᴛɴᴀᴍᴇ
⚖Gᴇᴛʙɪᴏ
╔════ஜ🎲🎓🎲ஜ═══╗
║  line.me/ti/p/mt6qgzsLee     ║
╚════ஜ🎲🎓🎲ஜ═══╝
"""

helpset ="""╔════ஜ🎲🎓🎲ஜ═══╗
║             🎩^$€^™^β¤t^🎩         ║
╚════ஜ🎲🎓🎲ஜ═══╝
⚖Pʀᴏᴛᴇᴄᴛ ᴏɴ/ᴏғғ
⚖Qʀ ᴏɴ/ᴏғғ
⚖Iɴᴠɪᴛ ᴏɴ/ᴏғғ
⚖Cᴀɴᴄᴇʟ ᴏɴ/ᴏғғ
⚖Lɪɴᴋ ᴏɴ/ᴏғғ
⚖SᴇᴛPʀᴏ ᴏɴ/ᴏғғ
⚖Sᴇᴛsᴇʟғ ᴏɴ/ᴏғ
╠════ஜ🎲🎓🎲ஜ═══╣
⚖Sɪᴅᴇʀ ᴏɴ/ᴏғғ
⚖Ksɪᴅᴇʀ ᴏɴ/ᴏғ
⚖ᴊᴏɪɴᴋɪᴄᴋ ᴏɴ/ᴏғғ
⚖Cᴏɴᴛᴀᴄᴛ ᴏɴ/ᴏғғ
⚖Aᴜᴛᴏᴊᴏɪɴ ᴏɴ/ᴏғғ
⚖Aᴜᴛᴏʟᴇᴀᴠᴇ ᴏɴ/ᴏғғ
⚖Aᴜᴛᴏᴀᴅᴅ ᴏɴ/ᴏғғ
⚖ᴊᴀᴍ ᴏɴ/ᴏғғ
╠════ஜ🎲🎓🎲ஜ═══╣
⚖Aᴜᴛᴏʀᴇsᴘᴏɴ ᴏɴ/ᴏғғ
⚖Rᴇsᴘᴏɴ ᴏɴ
⚖Rᴇsᴘᴏɴᴋɪᴄᴋ ᴏɴ/ᴏғғ
⚖Sᴛɪᴄᴋᴇʀ ᴏɴ/ᴏғғ
⚖Mɪᴍɪᴄ ᴏɴ/ᴏғғ
⚖Wᴇʟᴄᴏᴍᴇ ᴏɴ/ᴏғғ
⚖Cᴏᴍᴇ ᴏɴ/ᴏғғ
⚖Cᴏᴍᴇ ᴄᴇᴋ
⚖Cᴏᴍᴇsᴇᴛ:
╠════ஜ🎲🎓🎲ஜ═══╣
⚖Lɪᴋᴇ ᴏɴ/ᴏғғ
⚖Lɪᴋᴇ ᴍᴇ
⚖Lɪᴋᴇ ғʀɪᴇɴᴅ
╠════ஜ🎲🎓🎲ஜ═══╣
⚖Rᴇᴀᴅ ᴏɴ/ᴏғғ
⚖Sʜᴀʀᴇ ᴏɴ/ᴏғғ
⚖Sɪᴍɪsɪᴍɪ ᴏɴ/ᴏғғ
╠════ஜ🎲🎓🎲ஜ═══╣
⚖Mɪᴍɪᴄ ᴛᴀʀɢᴇᴛ
⚖Mɪᴄʟɪsᴛ
⚖Mʏᴄᴏᴘʏ
⚖Mʏʙᴀᴄᴋᴜᴘ
⚖Sᴛᴀᴛᴜs
╔════ஜ🎲🎓🎲ஜ═══╗
║  line.me/ti/p/mt6qgzsLee     ║
╚════ஜ🎲🎓🎲ஜ═══╝
"""
helpcostume ="""╔════ஜ🎲🎓🎲ஜ═══╗
║             🎩^$€^™^β¤t^🎩         ║
╚════ஜ🎲🎓🎲ஜ═══╝
⚖CᴏᴍᴇɢʀᴇᴀᴛSᴇᴛ: [ᴄᴇᴋ]
⚖LᴇғᴛɢʀᴇᴀᴛSᴇᴛ: [ᴄᴇᴋ]
⚖AᴅᴅɢʀᴇᴀᴛSᴇᴛ: [ᴄᴇᴋ]
⚖SɪᴅᴇʀSᴇᴛ: [ᴄᴇᴋ]
⚖RᴇsᴘᴏɴSᴇᴛ: [ᴄᴇᴋ]
╔════ஜ🎲🎓🎲ஜ═══╗
║  line.me/ti/p/mt6qgzsLee     ║
╚════ஜ🎲🎓🎲ஜ═══╝
"""

helpgrup ="""╔════ஜ🎲🎓🎲ஜ═══╗
║             🎩^$€^™^β¤t^🎩         ║
╚════ஜ🎲🎓🎲ஜ═══╝
⚖Wᴇʟᴄᴏᴍᴇ
⚖Iɴғᴏɢʀᴜᴘ
⚖Gʀᴜᴘɴᴀᴍᴇ
⚖Uʀʟɢʀᴜᴘ ɪᴍᴀɢᴇ
⚖Gᴇᴛɢʀᴜᴘ ɪᴍᴀɢᴇ
⚖Gᴄʀᴇᴀᴛᴏʀ
⚖Gʀᴜᴘɪᴅɢʀᴜᴘ ɪᴅ
⚖Mᴇᴍʟɪsᴛ
⚖ʟᴜʀᴋ ᴏɴ/ғғ
⚖ʟᴜʀᴋᴇʀs
⚖Aᴅᴅ ᴀʟʟ
⚖Aᴅᴅ
╠═══ஜ🎲🎓🎲ஜ═══╣
⚖Gɴᴀᴍᴇ
⚖Gʀᴜᴘɪᴍᴀɢᴇ:
⚖Gʙʀᴏᴀᴅᴄᴀsᴛ
⚖Cʙʀᴏᴀᴅᴄᴀsᴛ:
╠═══ஜ🎲🎓🎲ஜ═══╣
⚖Uʀʟ
⚖Iɴᴠɪᴛᴇ
⚖ɪɴᴠɪᴛᴇ:ᴄʀᴇᴀᴛʙᴏᴛ
⚖ɪɴᴠɪᴛᴇ:ɢᴄʀᴇᴀᴛᴏʀ
⚖Sᴘᴀᴍ
⚖Gɪғᴛ
⚖Bʏᴇ.
⚖Bʏᴇᴀʟʟ.
╔════ஜ🎲🎓🎲ஜ═══╗
║  line.me/ti/p/mt6qgzsLee     ║
╚════ஜ🎲🎓🎲ஜ═══╝
"""

helpmed ="""╔════ஜ🎲🎓🎲ஜ═══╗
║             🎩^$€^™^β¤t^🎩         ║
╚════ஜ🎲🎓🎲ஜ═══╝
⚖Tʀ-ɪᴅ/ᴇɴ/ᴋᴏ/ᴊᴘ/ᴛʜ/ᴊᴡ
⚖Sᴀʏ-ɪᴅ/ᴇɴ/ᴋᴏ/ᴊᴘ/ᴛʜ
╠════ஜ🎲🎓🎲ஜ═══╣
⚖ᴘʀᴏғɪʟᴇɪɢ
⚖ᴄʜᴇᴄᴋᴅᴀᴛᴇ
⚖Kᴀʟᴇɴᴅᴇʀ
⚖Iᴍᴀɢᴇ
⚖Mᴜsɪᴄ
⚖Lɪʀɪᴋ
⚖Pʟᴀʏsᴛᴏʀᴇ
⚖Wɪᴋɪᴘᴇᴅɪᴀ
╠════ஜ🎲🎓🎲ஜ═══╣
⚖ʏᴛ-sᴇᴀʀᴄʜ
⚖ʏᴛ-ᴍᴘ4
⚖ʏᴛ-ɢᴇᴛ
╔════ஜ🎲🎓🎲ஜ═══╗
║  line.me/ti/p/mt6qgzsLee     ║
╚════ஜ🎲🎓🎲ஜ═══╝
"""
helpother ="""╔════ஜ🎲🎓🎲ஜ═══╗
║             🎩^$€^™^β¤t^🎩         ║
╚════ஜ🎲🎓🎲ஜ═══╝
⚖Wᴇʟᴄᴏᴍᴇ
⚖Sɪᴍʙᴏʟ1
⚖Sɪᴍʙᴏʟ2
⚖Sɪᴍʙᴏʟ3
⚖Sɪᴍʙᴏʟ4
⚖Sɪᴍʙᴏʟ5
╔════ஜ🎲🎓🎲ஜ═══╗
║  line.me/ti/p/mt6qgzsLee     ║
╚════ஜ🎲🎓🎲ஜ═══╝
"""

mid = cl.getProfile().mid
Bots=[mid,"u57a54b914085fea6f04c19f6fe589057"]
Owner=["u57a54b914085fea6f04c19f6fe589057"]
admin=["u57a54b914085fea6f04c19f6fe589057"]
blacklist=[""]
dangerMessage = [".Modar",".modar","!modar","#modar",".","Cleanse","cleanse","Group cleansed.",".winebot",".kickall","Mayhem","mayhem","Kick on","makasih :d","!kickall","Nuke","nuke"]

wait = {
    "likeOn":True,
    "alwayRead":False,
    "detectMention":False,
    "detectMention2":False,  
    "detectMention3":True,  
    "detectMentionpc":False,  
    "kickMention":False,
    "steal":False,
    'pap':{},
    'invite':{},
    "spam":{},
    'contact':False,
    'autoJoin':True,
    'autoCancel':{"on":False,"members":50},
    "joinkick":False,
    'leaveRoom':True,
    'timeline':False,
    'autoAdd':False,
    'message':"",
    "lang":"JP",
    "comment":"╔══ஜ°°°Aᴜᴛᴏ°°Lɪᴋᴇ°°°ஜ══╗\n║           🎩^$€^™^β¤t^🎩           \n╚══ஜ°°Oᴘᴇɴ Oʀᴅᴇʀ°°ஜ══╝\n⚖SᴇʟғBᴏᴛ\n⚖Pʀᴏᴛᴇᴄᴛ Bᴏᴛ\n⚖Cᴏɪɴ Lɪɴᴇ Vɪᴀ Gɪғᴛ\n⚖Tʜᴇᴍᴀ\n⚖Vɪᴘ Sᴍᴜʟᴇ\n⚖Sᴀɢᴀʟᴀ Aʏᴀ Wᴇʟᴀʜ\n╔═ஜ°° Cʀᴇᴀᴛᴇᴅ Bʏ °°ஜ══╗\n║  line.me/ti/p/QvU09Wriyc \n╚═ஜ°°Sᴜɴᴅᴀɴis Eᴅᴀɴ°°ஜ═╝",
    "arespon":"",
    "comegreat":"",
    "leftgreat":"",
    "comepc":"",
    "addgreat":"",
    "siderset":"",
    "comment1":"❂➤Thanks For Add me!!\n 🎩^$€^~Sᴜɴᴅᴀɴis Eᴅᴀɴ™β¤t~🎩\n\n http://line.me/ti/p/QvU09Wriyc",
    "commentOn":True,
    "commentBlack":{},
    "wblack":False,
    "dblack":False,
    "clock":False,
    "cNames":"",
    "blacklist":{},
    "wblacklist":False,
    "dblacklist":False,
    "protect":False,
    "cancelprotect":False,
    "inviteprotect":False,
    "linkprotect":False,
    "Ghost":False,
    "Sambutan":True,
    "admincipok":False,
    "adminletak":False,
    "Sider":{},
    "Kicksider":False,
    "sticker":False,
    "Bot":True,
}

wait2 = {
    "readPoint":{},
    "readMember":{},
    "setTime":{},
    "ROM":{}
    }

mimic = {
    "copy":False,
    "copy2":False,
    "status":False,
    "target":{}
    }
    
settings = {
    "simiSimi":{}
    }

cctv = {
    "cyduk":{},
    "point":{},
    "sidermem":{}
}    

res = {
    'num':{},
    'us':{},
    'au':{},
    }

setTime = {}
setTime = wait2['setTime']
mulai = time.time() 

contact = cl.getProfile()
backup = cl.getProfile()
backup.displayName = contact.displayName
backup.statusMessage = contact.statusMessage                        
backup.pictureStatus = contact.pictureStatus

def restart_program():
    python = sys.executable
    os.execl(python, python, * sys.argv)
        
def download_page(url):
    version = (3,0)
    cur_version = sys.version_info
    if cur_version >= version:     #If the Current Version of Python is 3.0 or above
        import urllib,request    #urllib library for Extracting web pages
        try:
            headers = {}
            headers['User-Agent'] = "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36"
            req = urllib,request.Request(url, headers = headers)
            resp = urllib,request.urlopen(req)
            respData = str(resp.read())
            return respData
        except Exception as e:
            print(str(e))
    else:                        #If the Current Version of Python is 2.x
        import urllib2
        try:
            headers = {}
            headers['User-Agent'] = "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.17 (KHTML, like Gecko) Chrome/24.0.1312.27 Safari/537.17"
            req = urllib2.Request(url, headers = headers)
            response = urllib2.urlopen(req)
            page = response.read()
            return page
        except:
            return"Page Not found"

#Finding 'Next Image' from the given raw page
def _images_get_next_item(s):
    start_line = s.find('rg_di')
    if start_line == -1:    #If no links are found then give an error!
        end_quote = 0
        link = "no_links"
        return link, end_quote
    else:
        start_line = s.find('"class="rg_meta"')
        start_content = s.find('"ou"',start_line+90)
        end_content = s.find(',"ow"',start_content-90)
        content_raw = str(s[start_content+6:end_content-1])
        return content_raw, end_content
        
#Getting all links with the help of '_images_get_next_image'
def _images_get_all_items(page):
    items = []
    while True:
        item, end_content = _images_get_next_item(page)
        if item == "no_links":
            break
        else:
            items.append(item)      #Append all the links in the list named 'Links'
            time.sleep(0.1)        #Timer could be used to slow down the request for image downloads
            page = page[end_content:]
    return items

def upload_tempimage(client):
    '''
        Upload a picture of a kitten. We don't ship one, so get creative!
    '''
    config = {
        'album': album,
        'name':  'bot auto upload',
        'title': 'bot auto upload',
        'description': 'bot auto upload'
    }

    print("Uploading image... ")
    image = client.upload_from_path(image_path, config=config, anon=False)
    print("Done")
    print()

def summon(to, nama):
    aa = ""
    bb = ""
    strt = int(14)
    akh = int(14)
    nm = nama
    for mm in nm:
      akh = akh + 2
      aa += """{"S":"""+json.dumps(str(strt))+""","E":"""+json.dumps(str(akh))+""","M":"""+json.dumps(mm)+"},"""
      strt = strt + 6
      akh = akh + 4
      bb += "\xe2\x95\xa0 @x \n"
    aa = (aa[:int(len(aa)-1)])
    msg = Message()
    msg.to = to
    msg.text = "\xe2\x95\x94\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\n"+bb+"\xe2\x95\x9a\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90"
    msg.contentMetadata ={'MENTION':'{"MENTIONEES":['+aa+']}','EMTVER':'4'}
    print "[Command] Tag All"
    try:
       cl.sendMessage(msg)
    except Exception as error:
       print error
       
def waktu(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    return '%02d Jam %02d Menit %02d Detik' % (hours, mins, secs)      

def cms(string, commands): #/XXX, >XXX, ;XXX, ^XXX, %XXX, $XXX...
    tex = ["+","@","/",">",";","^","%","$","＾","サテラ:","サテラ:","サテラ：","サテラ："]
    for texX in tex:
        for command in commands:
            if string ==command:
                return True
    return False

def sendMessage(to, text, contentMetadata={}, contentType=0):
    mes = Message()
    mes.to, mes.from_ = to, profile.mid
    mes.text = text
    mes.contentType, mes.contentMetadata = contentType, contentMetadata
    if to not in messageReq:
        messageReq[to] = -1
    messageReq[to] += 1

def autolike():
    count = 1
    while True:
        try:
           for posts in cl.activity(1)["result"]["posts"]:
             if posts["postInfo"]["liked"] is False:
                if wait["likeOn"] == True:
                   cl.like(posts["userInfo"]["writerMid"], posts["postInfo"]["postId"], 1001)
                   print "Like"
                   if wait["commentOn"] == True:
                      if posts["userInfo"]["writerMid"] in wait["commentBlack"]:
                         pass
                      else:
                          cl.comment(posts["userInfo"]["writerMid"],posts["postInfo"]["postId"],wait["comment"])
        except:
            count += 1
            if(count == 50):
                sys.exit(0)
            else:
                pass
thread2 = threading.Thread(target=autolike)
thread2.daemon = True
thread2.start()

def likefriend():
    for zx in range(0,20):
      hasil = cl.activity(limit=20)
      if hasil['result']['posts'][zx]['postInfo']['liked'] == False:
        try:
          cl.like(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],likeType=1001)
          print "Like"
        except:
          pass
      else:
          print "Already Liked"
time.sleep(0.60)

def likeme():
    for zx in range(0,20):
        hasil = cl.activity(limit=20)
        if hasil['result']['posts'][zx]['postInfo']['liked'] == False:
            if hasil['result']['posts'][zx]['userInfo']['mid'] in mid:
                try:
                    cl.like(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],likeType=1002)
                    print "Like"
                except:
                    pass
            else:
                print "Status Sudah di Like"
                
def bot(op):
    try:
        if op.type == 0:
            return
        if op.type == 13:
            if mid in op.param3:
                G = cl.getGroup(op.param1)
                if wait["autoJoin"] == True:
                    if wait["autoCancel"]["on"] == True:
                        if len(G.members) <= wait["autoCancel"]["members"]:
                            cl.rejectGroupInvitation(op.param1)
                        else:
                            cl.acceptGroupInvitation(op.param1)
                    else:
                        cl.acceptGroupInvitation(op.param1)
                elif wait["autoCancel"]["on"] == True:
                    if len(G.members) <= wait["autoCancel"]["members"]:
                        cl.rejectGroupInvitation(op.param1)
            else:
                Inviter = op.param3.replace("",',')
                InviterX = Inviter.split(",")
                matched_list = []
                for tag in wait["blacklist"]:
                    matched_list+=filter(lambda str: str == tag, InviterX)
                if matched_list == []:
                    pass
                else:
                    cl.cancelGroupInvitation(op.param1, matched_list)
        if op.type == 13:
            if blacklist in op.param3:
                cl.cancelGroupInvitation(op.param1, matched_list)
            else:
                pass
            
        if op.type == 5:
            print ("[ 5 ] NOTIFIED ADD CONTACT")
            if wait["autoAdd"] == True:
                dit = wait["addgreat"]
                dut = cl.getContact(op.param1).displayName
                cl.sendText(op.param1, "Haii...❂➤" + dut + " \nThanks For Add me!!\n 🎩^$€^~Sᴜɴᴅᴀɴis Eᴅᴀɴ™β¤t~🎩\n\n http://line.me/ti/p/QvU09Wriyc" + dit)
            else:
                dit = wait["addgreat"]
                dut = cl.getContact(op.param1).displayName
                cl.sendText(op.param1, "Yap...❂➤" + dut + " \nThanks For Add Me..!!\n 🎩^$€^~Sᴜɴᴅᴀɴis Eᴅᴀɴ™β¤t~🎩\n\n http://line.me/ti/p/QvU09Wriyc" + dit)
#-------------------------------------------------------------------------------
        if op.type == 19:
            if mid in op.param3:
                wait["blacklist"][op.param2] = True
#-------------------------------------------------------------------------------
        if op.type == 22:
            if wait["leaveRoom"] == True:
                cl.leaveRoom(op.param1)
#-------------------------------------------------------------------------------
        if op.type == 24:
            if wait["leaveRoom"] == True:
                cl.leaveRoom(op.param1)
#==============================================#
        if op.type == 17:
            if op.param2 not in Bots:
                if op.param2 in Bots:
                    pass
            if wait["protect"] == True:
                if wait["blacklist"][op.param2] == True:
                    try:
                        cl.kickoutFromGroup(op.param1,[op.param2])
                        G = cl.getGroup(op.param1)
                        G.preventJoinByTicket = True
                        cl.updateGroup(G)
                    except:
                        try:
                            cl.kickoutFromGroup(op.param1,[op.param2])
                            G = cl.getGroup(op.param1)
                            G.preventJoinByTicket = True
                            cl.updateGroup(G)
                        except:
                            pass
                                                            
#----------------------------------------------------------------------
        if op.type == 19:
            if op.param2 not in Bots:
                if op.param2 in Bots:
                    pass
                elif wait["protect"] == True:
                    wait ["blacklist"][op.param2] = True
                    cl.kickoutFromGroup(op.param1,[op.param2])
                    cl.inviteIntoGroup(op.param1,[op.param2])
                    
        if op.type == 13:
            if op.param2 not in Bots:
                if op.param2 in Bots:
                    pass
                elif wait["inviteprotect"] == True:
                    wait ["blacklist"][op.param2] = True
                    cl.kickoutFromGroup(op.param1,[op.param2])
                    if op.param2 not in Bots:
                        if op.param2 in Bots:
                            pass
                        elif wait["inviteprotect"] == True:
                            wait ["blacklist"][op.param2] = True
                            cl.cancelGroupInvitation(op.param1,[op.param3])
                            if op.param2 not in Bots:
                                if op.param2 in Bots:
                                    pass
                                elif wait["cancelprotect"] == True:
                                    wait ["blacklist"][op.param2] = True
                                    cl.cancelGroupInvitation(op.param1,[op.param3])
        if op.type == 11:
            if op.param2 not in Bots:
                if op.param2 in Bots:
                    pass
                elif wait["linkprotect"] == True:
                    wait ["blacklist"][op.param2] = True
                    G = cl.getGroup(op.param1)
                    G.preventJoinByTicket = True
                    cl.updateGroup(G)
                    cl.kickoutFromGroup(op.param1,[op.param2])
                    
        if op.type == 5:
            if wait["autoAdd"] == True:
                if (wait["message"] in [""," ","\n",None]):
                    pass
                else:
                    cl.sendText(op.param1,str(wait["message"]))

        if op.type == 11:
            if wait["linkprotect"] == True:
                if op.param2 not in Bots:
                    G = cl.getGroup(op.param1)
                    G.preventJoinByTicket = True
                    cl.kickoutFromGroup(op.param1,[op.param3])
                    cl.updateGroup(G)
                        
        if op.type == 55:
            try:
                if op.param1 in wait2['readPoint']:
           
                    if op.param2 in wait2['readMember'][op.param1]:
                        pass
                    else:
                        wait2['readMember'][op.param1] += op.param2
                    wait2['ROM'][op.param1][op.param2] = op.param2
                    with open('sider.json', 'w') as fp:
                     json.dump(wait2, fp, sort_keys=True, indent=4)
                else:
                    pass
            except:
                pass           
                    
                    
        if op.type == 59:
            print op
                
        if op.type == 55:
            try:
                group_id = op.param1
                user_id=op.param2
                subprocess.Popen('echo "'+ user_id+'|'+str(op.createdTime)+'" >> dataSeen/%s.txt' % group_id, shell=True, stdout=subprocess.PIPE, )
            except Exception as e:
                print e
                                
        if op.type == 55:
                try:
                    if cctv['cyduk'][op.param1]==True:
                        if op.param1 in cctv['point']:
                            Name = cl.getContact(op.param2).displayName
                            ginfo = cl.getGroup(op.param1)
                            dit = wait["siderset"]
                            contact = cl.getContact(op.param2)
                            image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                            if Name in cctv['sidermem'][op.param1]:
                                pass
                            else:
                                cctv['sidermem'][op.param1] += "\n• " + Name
                                if " " in Name:
                                    nick = Name.split(' ')
                                    if len(nick) == 2:
                                        time.sleep(0.2)
                                        summon(op.param1,[op.param2])
                                        cl.sendImageWithURL(op.param1,image)
                                        cl.sendText(op.param1, "『Aᴜᴛᴏsɪᴅᴇʀ』" + "\nEʜ ᴀᴅᴀ...🎩 " + nick[0] + " 🎩" + "\n" + dit)
                                    else:
                                        time.sleep(0.2)
                                        summon(op.param1,[op.param2])
                                        cl.sendImageWithURL(op.param1,image)
                                        cl.sendText(op.param1, "『Aᴜᴛᴏsɪᴅᴇʀ』" + "\nEʜ ᴀᴅᴀ...🎩 " + nick[1] + " 🎩" + "\n" + dit)
                                else:
                                    time.sleep(0.2)
                                    summon(op.param1,[op.param2])
                                    cl.sendImageWithURL(op.param1,image)
                                    cl.sendText(op.param1, "『Aᴜᴛᴏsɪᴅᴇʀ』" + "\nEʜ ᴀᴅᴀ...🎩 " + Name + " 🎩" + "\n" + dit)
                        else:
                            pass
                    else:
                        pass
                except:
                    pass
        else:
            pass 
#-------------------------------------------------------------------------------
        if op.type == 55:
            if op.param2 not in Bots:
                if op.param2 in admin and Bots and Owner:
                    pass
                elif wait["Kicksider"] == True:
                    wait["Sider"] == True
                    wait ["blacklist"][op.param2] = True
                    cl.kickoutFromGroup(op.param1,[op.param2])
#-------------------------------------------------------------------------------
        if op.type == 25:
            msg = op.message
            if msg.toType == 0:
                msg.to = msg.from_
                if msg.from_ == mid:
                    if "join:" in msg.text:
                        list_ = msg.text.split(":")
                        try:
                            cl.acceptGroupInvitationByTicket(list_[1],list_[2])
                            G = cl.getGroup(list_[1])
                            G.preventJoinByTicket = True
                            cl.updateGroup(G)
                        except:
                            cl.sendText(msg.to,"❂➤error")
#-------------------------------------------------------------------------------
            if msg.toType == 1:
                if wait["leaveRoom"] == True:
                    cl.leaveRoom(msg.to)
#-------------------------------------------------------------------------------
            if msg.contentType == 16:
                url = msg.contentMetadata["postEndUrl"]
                cl.like(url[25:58], url[66:], likeType=1001)
#-------------------------------------------------------------------------------
        if op.type == 26:
            msg = op.message
            if msg.from_ in mimic["target"] and mimic["status"] == True and mimic["target"][msg.from_] == True:
                    text = msg.text
                    if text is not None:
                        cl.sendText(msg.to,text)
#-------------------------------------------------------------------------------
        if op.type == 26 or op.type == 25:
            if msg.contentType == 7:
                if wait["sticker"] == True:
                    msg.contentType = 0
                    stk_id = msg.contentMetadata['STKID']
                    stk_ver = msg.contentMetadata['STKVER']
                    pkg_id = msg.contentMetadata['STKPKGID']
                    filler = "『 Sticker Check 』\nSTKID : %s\nSTKPKGID : %s\nSTKVER : %s\n『 Link 』\nline://shop/detail/%s" % (stk_id,pkg_id,stk_ver,pkg_id)
                    cl.sendText(msg.to, filler)
#                    wait["sticker"] = False
                else:
                    pass    
#-------------------------------------------------------------------------------
        if op.type == 26:
            msg = op.message
            if msg.to in settings["simiSimi"]:
                if settings["simiSimi"][msg.to] == True:
                    if msg.text is not None:
                        text = msg.text
                        r = requests.get("http://api.ntcorp.us/chatbot/v1/?text=" + text.replace(" ","+") + "&key=beta1.nt")
                        data = r.text
                        data = json.loads(data)
                        if data['status'] == 200:
                            if data['result']['result'] == 100:
                                cl.sendText(msg.to, "[ChatBOT] " + data['result']['response'].encode('utf-8'))
#-------------------------------------------------------------------------------
            if 'MENTION' in msg.contentMetadata.keys() != None:
                 if wait["detectMention"] == True:
                     contact = cl.getContact(msg.from_)
                     cName = contact.displayName
                     dit = wait["arespon"]
                     name = re.findall(r'@(\w+)', msg.text)
                     mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                     mentionees = mention['MENTIONEES']
                     for mention in mentionees:
                           if mention['M'] in Bots:
                                  cl.sendText(msg.to, "Hai.. ✒  " + cName + " \n ..😊😊😊.. " + dit +"\n")
                                  break            
                                    
            if 'MENTION' in msg.contentMetadata.keys() != None:
                 if wait["detectMention2"] == True:          
                    contact = cl.getContact(msg.from_)
                    cName = contact.displayName
                    balas = ["Ciee..." + cName + "Mau Ngasih Kado Yaa...",cName + " Ada Yang Bisa Saya Bantu Kak..?? \n" + cName,"Ada Apa Kak..??" + cName + " Kangen Aku Kah ??"]
                    ret_ = random.choice(balas)
                    name = re.findall(r'@(\w+)', msg.text)
                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                    mentionees = mention['MENTIONEES']
                    for mention in mentionees:
                           if mention['M'] in Bots:
                                  cl.sendText(msg.to,ret_)
                                  msg.contentType = 7   
                                  msg.text = None
                                  msg.contentMetadata = {
                                                       "STKID" : "5507",
                                                       "STKPKGID" : "608",
                                                       "STKVER" : "16" }
                                  cl.sendMessage(msg)                                
                                  break
                                    
            if 'MENTION' in msg.contentMetadata.keys() != None:
                 if wait["detectMention3"] == True:          
                    contact = cl.getContact(msg.from_)
                    cName = contact.displayName
                    balas = ["Hᴀɪɪ...❂☞ " + cName + "☜❂"]
                    balas1 = "Kaka Pasti Kangen Aku Ya. . .??"
                    ret_ = random.choice(balas)
                    image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                    dit = wait["arespon"]
                    name = re.findall(r'@(\w+)', msg.text)
                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                    mentionees = mention['MENTIONEES']
                    for mention in mentionees:
                           if mention['M'] in Bots:
                                  cl.sendText(msg.to,ret_)
#                                 cl.sendText(msg.to,balas1)
                                  cl.sendImageWithURL(msg.to,image)
                                  cl.sendText(msg.to, "『Aᴜᴛᴏʀᴇsᴘᴏɴ』\n❂☞" + cName + "☜❂\n" + dit +"")
                                  msg.contentType = 7   
                                  msg.text = None
                                  msg.contentMetadata = {
                                                       "STKID" : "5507",
                                                       "STKPKGID" : "608",
                                                       "STKVER" : "16" }
                                  cl.sendMessage(msg)                                
                                  break
                                    
            if 'MENTION' in msg.contentMetadata.keys() != None:
                if wait["detectMentionpc"] == True:          
                    contact = cl.getContact(msg.from_)
                    cName = contact.displayName
                    balas = wait["comepc"]
                    name = re.findall(r'@(\w+)', msg.text)
                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                    mentionees = mention['MENTIONEES']
                    for mention in mentionees:
                        if mention['M'] in admin:
                                cl.sendText(msg.from_,balas)
                                msg.to = msg.from_
                                msg.contentType = 7   
                                msg.text = None
                                msg.contentMetadata = {
                                                       "STKID": "410",
                                                       "STKPKGID": "1",
                                                       "STKVER": "100" }
                                cl.sendMessage(msg)                                
                                break
#-------------------------------------------------------------------------------
            if 'MENTION' in msg.contentMetadata.keys() != None:
                 if wait["kickMention"] == True:
                     contact = cl.getContact(msg.from_)
                     cName = contact.displayName
                     balas = ["Dont Tag Me!! Im Busy",cName + " Ngapain Ngetag?",cName + " Nggak Usah Tag-Tag! Kalo Penting Langsung Pc Aja","-_-","Gw lagi off", cName + " Kenapa Tag saya?","SPAM PC aja " + cName, "Jangan Suka Tag gua " + cName, "Kamu siapa " + cName + "?", "Ada Perlu apa " + cName + "?","Tenggelamkan tuh yang suka tag pake BOT","Tersummon -_-"]
                     ret_ = "[Auto Respond] " + random.choice(balas)
                     name = re.findall(r'@(\w+)', msg.text)
                     mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                     mentionees = mention['MENTIONEES']
                     for mention in mentionees:
                           if mention['M'] in Bots:
                                  cl.sendText(msg.to,ret_)
                                  cl.kickoutFromGroup(msg.to,[msg.from_])
                                  break
#-------------------------------------------------------------------------------
            if msg.toType == 2:
                if msg.text in dangerMessage:
                    wait["blacklist"] = True
                    if msg.from_ in admin and Bots:
                        pass
                    else:
                        if wait["protect"] == True:
                            try:
                                cl.kickoutFromGroup(msg.to,[msg.from_])
                                cl.sendText(msg.from_,"❂➤Wᴀᴛᴄʜ ʏᴏᴜʀ ᴡᴏʀᴅs...!!!")
                            except:
                                pass
                        else:
                            pass
                else:
                    pass
#---------------------------------------------------------------------
            if msg.contentType == 13:
                if wait['invite'] == True:
                    _name = msg.contentMetadata["displayName"]
                    invite = msg.contentMetadata["mid"]
                    groups = cl.getGroup(msg.to)
                    pending = groups.invitee
                    targets = []
                    for s in groups.members:
                        if _name in s.displayName:
                            cl.sendText(msg.to, _name + "❂➤ Berada DiGrup Ini")
                        else:
                            targets.append(invite)
                    if targets == []:
                        pass
                    else:
                        for target in targets:
                            try:
                                cl.findAndAddContactsByMid(target)
                                cl.inviteIntoGroup(msg.to,[target])
                                cl.sendText(msg.to,"Invite " + _name)
                                wait['invite'] = False
                                break                              
                            except:             
                                    cl.sendText(msg.to,"Error")
                                    wait['invite'] = False
                                    break
#=============================[ Admin add Contact ]==================================
            if msg.contentType == 13:
                    if wait['admincipok'] == True:
                        wait['adminletak'] == False
                        _name = msg.contentMetadata["displayName"]
                        gs = msg.contentMetadata["mid"]
                        try:
                            admin[gs] = True
                            f=codecs.open('admin.json','w','utf-8')
                            json.dump(admin, f, sort_keys=True, indent=4,ensure_ascii=False)
                            cl.sendText(msg.to,"❂➤WL Dɪᴛᴀᴍʙᴀʜᴋᴀɴ\nKɪʀɪᴍ ᴋᴏɴᴛᴀᴋ ʟᴀɢɪ, ᴀᴛᴀᴜ ᴍᴀᴛɪᴋᴀɴ")
                        except:
                            pass
#----------------------------------------------------------------------------
            if msg.contentType == 13:
                    if wait['adminletak'] == True:
                        wait['adminletak'] == False
                        _name = msg.contentMetadata["displayName"]
                        gs = msg.contentMetadata["mid"]
                        try:
                            del admin[gs]
                            f=codecs.open('admin.json','w','utf-8')
                            json.dump(admin, f, sort_keys=True, indent=4,ensure_ascii=False)
                            cl.sendText(msg.to,"❂➤WL Dɪʜᴀᴘᴜs\nKɪʀɪᴍ ᴋᴏɴᴛᴀᴋ ʟᴀɢɪ, ᴀᴛᴀᴜ ᴍᴀᴛɪᴋᴀɴ")
                        except:
                            pass
#=============================[ Admin add Contact ]==================================
            if msg.contentType == 13:
                if wait["steal"] == True:
                    _name = msg.contentMetadata["displayName"]
                    copy = msg.contentMetadata["mid"]
                    groups = cl.getGroup(msg.to)
                    pending = groups.invitee
                    targets = []
                    for s in groups.members:
                        if _name in s.displayName:
                            print "[Target] Stealed"
                            break                             
                        else:
                            targets.append(copy)
                    if targets == []:
                        pass
                    else:
                        for target in targets:
                            try:
                                cl.findAndAddContactsByMid(target)
                                contact = cl.getContact(target)
                                cu = cl.channel.getCover(target)
                                path = str(cu)
                                image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                                cl.sendText(msg.to,"Nama :\n" + contact.displayName + "\n\nMid :\n" + msg.contentMetadata["mid"] + "\n\nBio :\n" + contact.statusMessage)
                                cl.sendText(msg.to,"Profile Picture " + contact.displayName)
                                cl.sendImageWithURL(msg.to,image)
                                cl.sendText(msg.to,"Cover " + contact.displayName)
                                cl.sendImageWithURL(msg.to,path)
                                wait["steal"] = False
                                break
                            except:
                                    pass    
#-------------------------------------------------------------------------------
            if msg.contentType == 16:
                if wait["likeOn"] == True:
                    url = msg.contentMetadata["postEndUrl"]
                    cl.like(url[25:58], url[66:], likeType=1005)
                    cl.comment(url[25:58], url[66:], wait["comment"])
                    cl.sendText(msg.to,"❂➤Like Success") 
                    wait["likeOn"] == False
#-------------------------------------------------------------------------------
            if wait["alwayRead"] == True:
                if msg.toType == 0:
                    cl.sendChatChecked(msg.from_,msg.id)
                else:
                    cl.sendChatChecked(msg.to,msg.id)
#-------------------------------------------------------------------------------
        if op.type == 17:
          if wait["joinkick"] == True:
            if op.param2 in admin:
              if op.param2 in Bots:
                return
            cl.kickoutFromGroup(op.param1,[op.param2])
            print "MEMBER JOIN KICK TO GROUP"
#-------------------------------------------------------------------------------
        if op.type == 17:
            if wait["Sambutan"] == True:
                if op.param2 in Bots:
                    return
                ginfo = cl.getGroup(op.param1)
                contact = cl.getContact(op.param2)
                image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                jawaban1 = ("Selamat Datang Di Grup " + str(ginfo.name))
                tts = gTTS(text=jawaban1, lang='id')
                tts.save('tts.mp3')
                dit = wait["comegreat"]
                cl.sendText(op.param1,"╔════ஜ🎲🎓🎲ஜ════╗\n╠⚖    Wɪʟᴜjᴇᴜɴɢ Sᴜᴍᴘɪɴɢ     \n╚════ஜ🎲🎓🎲ஜ════╝")
                cl.sendImageWithURL(op.param1,image) 
                cl.sendText(op.param1,"╔══════ஜ🎲🎓🎲ஜ══════\n╠⚖ Hᴇʟʟᴏ...❂➤" + cl.getContact(op.param2).displayName + "\n╠⚖ Wᴇʟᴄᴏᴍᴇ Tᴏ...🎩 " + str(ginfo.name) + " 🎩" + "\n╠⚖"  + dit)
                print "MEMBER JOIN TO GROUP"
#-------------------------------------------------------------------------------
        if op.type == 15:
            if wait["Sambutan"] == True:
                if op.param2 in Bots:
                    return
                image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                dit = wait["leftgreat"]
                cl.sendImageWithURL(op.param1,image)
                cl.sendText(op.param1,"❂➤Good Bye... " + cl.getContact(op.param2).displayName +  "\n" + dit)
#  	            cl.sendImageWithURL(op.param1,image)
                d = Message(to=op.param1, from_=None, text=None, contentType=7)
                d.contentMetadata = {
                                    "STKID": "14741438",
                                    "STKPKGID": "1376009",
                                    "STKVER": "1"}
                cl.sendMessage(d)
                print "MEMBER HAS LEFT THE GROUP"
#-------------------------------------------------------------------------------
        if op.type == 25:
            msg = op.message
            if msg.contentType == 13:
                if wait["wblack"] == True:
                    if msg.contentMetadata["mid"] in wait["commentBlack"]:
                        cl.sendText(msg.to,"❂➤In Blacklist")
                        wait["wblack"] = False
                    else:
                        wait["commentBlack"][msg.contentMetadata["mid"]] = True
                        wait["wblack"] = False
                        cl.sendText(msg.to,"❂➤Nothing")
                elif wait["dblack"] == True:
                    if msg.contentMetadata["mid"] in wait["commentBlack"]:
                        del wait["commentBlack"][msg.contentMetadata["mid"]]
                        cl.sendText(msg.to,"❂➤Done")
                        wait["dblack"] = False
                    else:
                        wait["dblack"] = False
                        cl.sendText(msg.to,"❂➤Not in Blacklist")
                elif wait["wblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["blacklist"]:
                        cl.sendText(msg.to,"In Blacklist")
                        wait["wblacklist"] = False
                    else:
                        wait["blacklist"][msg.contentMetadata["mid"]] = True
                        wait["wblacklist"] = False
                        cl.sendText(msg.to,"❂➤Done")
                elif wait["dblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["blacklist"]:
                        del wait["blacklist"][msg.contentMetadata["mid"]]
                        cl.sendText(msg.to,"❂➤Done")
                        wait["dblacklist"] = False
                    else:
                        wait["dblacklist"] = False
                        cl.sendText(msg.to,"❂➤Done")
                elif wait["contact"] == True:
                    msg.contentType = 0
                    cl.sendText(msg.to,msg.contentMetadata["mid"])
                    if 'displayName' in msg.contentMetadata:
                        contact = cl.getContact(msg.contentMetadata["mid"])
                        try:
                            cu = cl.channel.getCover(msg.contentMetadata["mid"])
                        except:
                            cu = ""
                        cl.sendText(msg.to,"[displayName]:\n" + msg.contentMetadata["displayName"] + "\n[mid]:\n" + msg.contentMetadata["mid"] + "\n[statusMessage]:\n" + contact.statusMessage + "\n[pictureStatus]:\nhttp://dl.profile.line-cdn.net/" + contact.pictureStatus + "\n[coverURL]:\n" + str(cu))
                    else:
                        contact = cl.getContact(msg.contentMetadata["mid"])
                        try:
                            cu = cl.channel.getCover(msg.contentMetadata["mid"])
                        except:
                            cu = ""
                        cl.sendText(msg.to,"[displayName]:\n" + contact.displayName + "\n[mid]:\n" + msg.contentMetadata["mid"] + "\n[statusMessage]:\n" + contact.statusMessage + "\n[pictureStatus]:\nhttp://dl.profile.line-cdn.net/" + contact.pictureStatus + "\n[coverURL]:\n" + str(cu))
#-------------------------------------------------------------------------------
            elif msg.contentType == 16:
                if wait["timeline"] == True:
                    msg.contentType = 0
                    if wait["lang"] == "JP":
                        msg.text = "menempatkan URL\n" + msg.contentMetadata["postEndUrl"]
                    else:
                        msg.text = msg.contentMetadata["postEndUrl"]
                    cl.sendText(msg.to,msg.text)
#-------------------------------------------------------------------------------
            elif msg.text is None:
                return
#======================================================================================#
#===============================[ JK HELP START ]================================#
#======================================================================================#  
            elif msg.text.lower() == 'help':
                if wait["lang"] == "JP":
                    cl.sendText(msg.to,helpmsg)
                else:
                    cl.sendText(msg.to,helpmsg)
            elif msg.text.lower() == 'help pc':
                if wait["lang"] == "JP":
                    cl.sendText(msg.to,helppc)
                else:
                    cl.sendText(msg.to,helppc)
            elif msg.text.lower() == 'help self':
                if wait["lang"] == "JP":
                    cl.sendText(msg.to,helpself)
                else:
                    cl.sendText(msg.to,helpself)
            elif msg.text.lower() == 'help grup':
                if wait["lang"] == "JP":
                    cl.sendText(msg.to,helpgrup)
                else:
                    cl.sendText(msg.to,helpgrup)
            elif msg.text.lower() == 'help set':
                if wait["lang"] == "JP":
                    cl.sendText(msg.to,helpset)
                else:
                    cl.sendText(msg.to,helpset)
            elif msg.text.lower() == 'help costume':
                if wait["lang"] == "JP":
                    cl.sendText(msg.to,helpcostume)
                else:
                    cl.sendText(msg.to,helpset)
            elif msg.text.lower() == 'help media':
                if wait["lang"] == "JP":
                    cl.sendText(msg.to,helpmed)
                else:
                    cl.sendText(msg.to,helpmed)
            elif msg.text.lower() == 'help other':
                if wait["lang"] == "JP":
                    cl.sendText(msg.to,helpother)
                else:
                    cl.sendText(msg.to,helpother)
            elif msg.text.lower() == 'help kick':
                if wait["lang"] == "JP":
                    cl.sendText(msg.to,helpkick)
                else:
                    cl.sendText(msg.to,helpkick)

#======================================================================================#
#===============================[ JK PC START ]==================================#
#======================================================================================#  

            elif msg.text.lower() == 'ifconfig':
                if msg.from_ in Owner and admin and Bots:
                    botKernel = subprocess.Popen(["ifconfig"], stdout=subprocess.PIPE).communicate()[0]
                    cl.sendText(msg.to, botKernel + "\n\n===SERVER INFO NetStat===")
#-------------------------------------------------------------------------------
            elif msg.text.lower() == 'system':
                if msg.from_ in Owner and admin and Bots:
                    botKernel = subprocess.Popen(["df","-h"], stdout=subprocess.PIPE).communicate()[0]
                    cl.sendText(msg.to, botKernel + "\n\n===SERVER INFO SYSTEM===")
#-------------------------------------------------------------------------------
            elif msg.text.lower() == 'kernel':
                if msg.from_ in Owner and admin and Bots:
                    botKernel = subprocess.Popen(["uname","-srvmpio"], stdout=subprocess.PIPE).communicate()[0]
                    cl.sendText(msg.to, botKernel + "\n\n===SERVER INFO KERNEL===")
#-------------------------------------------------------------------------------
            elif msg.text.lower() == 'cpu':
                if msg.from_ in Owner and admin and Bots:
                    botKernel = subprocess.Popen(["cat","/proc/cpuinfo"], stdout=subprocess.PIPE).communicate()[0]
                    cl.sendText(msg.to, botKernel + "\n\n===SERVER INFO CPU===")
#-------------------------------------------------------------------------------
            elif msg.text in ["Sp","Speed","speed"]:
                if msg.from_ in Owner and admin and Bots:
                    start = time.time()
                    cl.sendText(msg.to, "Progress...")
                    elapsed_time = time.time() - start
                    cl.sendText(msg.to, "%sseconds" % (elapsed_time))
#-------------------------------------------------------------------------------
            elif "Restart" in msg.text:
                if msg.from_ in Owner:
                    print "[Command]Restart"
                    try:
                        cl.sendText(msg.to,"❂➤Rᴇsᴛᴀʀᴛɪɴɢ...\nLoading\n█▒▒▒▒▒▒▒▒▒\n10%\n███▒▒▒▒▒▒▒\n30%\n█████▒▒▒▒▒\n50%\n███████▒▒▒\n100%\n██████████")
                        cl.sendText(msg.to,"❂➤Rᴇsᴛᴀʀᴛ Sᴜᴄᴄᴇss")
                        restart_program()
                    except:
                        cl.sendText(msg.to,"❂➤Pʟᴇᴀsᴇ ᴡᴀɪᴛ")
                        restart_program()
                        pass
#-------------------------------------------------------------------------------
            elif "Turn off" in msg.text:
                if msg.from_ in Owner:
                    try:
                        import sys
                        sys.exit()
                    except:
                        pass
                        
            elif cms(msg.text,["Matikan"]):
                if msg.from_ in Owner:
                    cl.sendText(msg.to,"Reboot")
                    exit(1)
#-------------------------------------------------------------------------------
            elif msg.text.lower() == 'runtime':
                if msg.from_ in Owner:
                    eltime = time.time() - mulai
                    van = "❂➤Bot has been active "+waktu(eltime)
                    cl.sendText(msg.to,van) 
#======================================================================================# 
#===============================[ JK STATUS START ]==============================#
#======================================================================================# 
            elif msg.text.lower() == 'status':
                if msg.from_ in Owner and admin and Bots:
                    today = datetime.today()
                    future = datetime(2018,06,07)
                    days = (str(future - today))
                    comma = days.find(",")
                    days = days[:comma]
                    dit = wait["arespon"]
                    dat = wait["comepc"]
                    dut = wait["comegreat"]
                    dot = wait["leftgreat"]
                    det = wait["addgreat"]
                    crot = wait["siderset"]
                    crit = wait["comment"]
                    md = ""
                    md+="╚══ஜ🎩Pʀᴏᴛᴇᴄᴛ🎩ஜ══╝\n"
                    if wait["protect"] == True: md+="⚖ Pʀᴏᴛᴇᴄᴛ: Oɴ \n"
                    else:md+="⚖ Pʀᴏᴛᴇᴄᴛ: Oғғ \n"
                    if wait["inviteprotect"] == True: md+="⚖ Iɴᴠɪᴛᴀᴛɪᴏɴ Pʀᴏᴛᴇᴄᴛ: Oɴ \n"
                    else:md+="⚖ Iɴᴠɪᴛᴀᴛɪᴏɴ Pʀᴏᴛᴇᴄᴛ: Oғғ \n"
                    if wait["cancelprotect"] == True: md+="⚖ Cᴀɴᴄᴇʟ Pʀᴏᴛᴇᴄᴛ: Oɴ \n"
                    else:md+="⚖ Cᴀɴᴄᴇʟ Pʀᴏᴛᴇᴄᴛ: Oғғ \n"
                    if wait["linkprotect"] == True: md+="⚖ Lɪɴᴋ Pʀᴏᴛᴇᴄᴛ: Oɴ \n"
                    else:md+="⚖ Lɪɴᴋ Pʀᴏᴛᴇᴄᴛ: Oғғ \n"
                    md+="╠═══ஜ🎩Sᴇʟғ🎩ஜ═══╣\n"
                    if wait["autoJoin"] == True: md+="⚖ Aᴜᴛᴏ Jᴏɪɴ: Oɴ \n"
                    else: md +="⚖ Aᴜᴛᴏ Jᴏɪɴ: Oғғ \n"
                    if wait["leaveRoom"] == True: md+="⚖ Aᴜᴛᴏ ʟᴇᴀᴠᴇ: Oɴ \n"
                    else: md+="⚖ Aᴜᴛᴏ ʟᴇᴀᴠᴇ: Oғғ \n"
                    if wait["contact"] == True: md+="⚖ Cᴏɴᴛᴀᴄᴛ: Oɴ  \n"
                    else: md+="⚖ Cᴏɴᴛᴀᴄᴛ: Oғғ \n"
                    if wait["autoCancel"] == True: md+="⚖ Auto cancel: Oɴ \n"
                    else: md+= "⚖ Gʀᴏᴜᴘ ᴄᴀɴᴄᴇʟ: Oғғ \n"
                    if wait["timeline"] == True: md+="⚖ Sʜᴀʀᴇ: Oɴ \n"
                    else:md+="⚖ Sʜᴀʀᴇ: Oғғ \n"
                    if wait["clock"] == True: md+="⚖ Jᴀᴍ: Oɴ \n"
                    else:md+="⚖ Jᴀᴍ: Oғғ \n"
                    if wait["likeOn"] == True: md+="⚖ Aᴜᴛᴏ Lɪᴋᴇ: Oɴ \n"
                    else:md+="⚖ Aᴜᴛᴏ Lɪᴋᴇ: Oғғ \n"
                    if wait["autoAdd"] == True: md+="⚖ Aᴜᴛᴏ ᴀᴅᴅ: Oɴ \n"
                    else:md+="⚖ Aᴜᴛᴏ ᴀᴅᴅ: Oғғ \n"
                    if wait["alwayRead"] == True: md+="⚖ Aᴜᴛᴏ Rᴇᴀᴅ: Oɴ \n"
                    else:md+="⚖ Aᴜᴛᴏ Rᴇᴀᴅ: Oғғ \n"
                    if wait["detectMention3"] == True: md+="⚖ Aᴜᴛᴏʀᴇsᴘᴏɴ: Oɴ \n"
                    else:md+="⚖ Aᴜᴛᴏʀᴇsᴘᴏɴ: Oғғ \n"
                    if wait["detectMentionpc"] == True: md+="⚖ Pᴄʀᴇsᴘᴏɴ: Oɴ \n"
                    else:md+="⚖ Pᴄʀᴇsᴘᴏɴ: Oғғ \n"
                    if mimic["status"] == True: md+="⚖ Mɪᴍɪᴄ: Oɴ \n"
                    else:md+="⚖ Mɪᴍɪᴄ: Oғғ \n"
                    if settings["simiSimi"] == True: md+="⚖ Sɪᴍɪsɪᴍɪ Oɴ \n"
                    else:md+="⚖ Sɪᴍɪsɪᴍɪ: Oғғ \n"
                    if wait["commentOn"] == True: md+="⚖ Cᴏᴍᴍᴇɴᴛ: Oɴ \n"
                    else:md+="⚖ Cᴏᴍᴍᴇɴᴛ: Oғғ \n"
                    if wait["Sambutan"] == True: md+="⚖ Wᴇʟᴄᴏᴍᴇ: Oɴ \n"
                    else:md+="⚖ Wᴇʟᴄᴏᴍᴇ: Oғғ \n"
                    if wait["sticker"] == True: md+="⚖ Dᴇᴛᴇᴄᴛ Sᴛɪᴄᴋᴇʀ: Oɴ \n"
                    else:md+="⚖ Dᴇᴛᴇᴄᴛ Sᴛɪᴄᴋᴇʀ: Oғғ \n"
                    if wait["Sider"] == True: md+="⚖ Aᴜᴛᴏ sɪᴅᴇʀ: Oɴ \n"
                    else:md+="⚖ Aᴜᴛᴏ sɪᴅᴇʀ: Oғғ \n"
                    if wait["Kicksider"] == True: md+="⚖ Aᴜᴛᴏᴋɪᴄᴋ sɪᴅᴇʀ: Oɴ \n"
                    else:md+="⚖ Aᴜᴛᴏᴋɪᴄᴋ sɪᴅᴇʀ: Oғғ \n"
                    if wait["kickMention"] == True: md+="⚖ Rᴇsᴘᴏɴᴋɪᴄᴋ: Oɴ \n"
                    else:md+="⚖ Rᴇsᴘᴏɴᴋɪᴄᴋ: Oғғ \n"
                    if wait["joinkick"] == True: md+="⚖ Jᴏɪɴᴋɪᴄᴋ: Oɴ \n"
                    else:md+="⚖ Jᴏɪɴᴋɪᴄᴋ: Oғғ \n"
                    md+="╠═ஜ🎩ᴄᴏSᴛᴜᴍᴇSᴇᴛ🎩ஜ═╣"
                    md+="\n⚖RᴇsᴘᴏɴSᴇᴛ:" + dit + ""
                    md+="\n⚖PᴄʀᴇSᴘᴏɴSᴇᴛ:" + dat + ""
                    md+="\n⚖CᴏᴍᴇɢʀᴇᴀᴛSᴇᴛ:" + dut + ""
                    md+="\n⚖LᴇғᴛɢʀᴇᴀᴛSᴇᴛ:" + dot + ""
                    md+="\n⚖AᴅᴅɢʀᴇᴀᴛSᴇᴛ:" + det + ""
                    md+="\n⚖SɪᴅᴇʀSᴇᴛ:" + crot + ""
                    md+="\n╔═══🎩^$€^™^β¤t^🎩══╗\n╚> line.me/ti/p/mt6qgzsLee <╝"
                    cl.sendText(msg.to,"╔═══>ஜ🎲🎓🎲ஜ<═══╗\n║              ⚖-Sᴛᴀᴛᴜᴤ-⚖\n"+md)
#-------------------------------------------------------------------------------#  
            elif msg.text in ["Wlcip","Allcipok"]:
                if msg.from_ in Owner:
                    wait["admincipok"] = True
                    cl.sendText(msg.to,"❂➤Pʟᴇᴀsᴇ sᴇɴᴅ ᴄᴏɴᴛᴀᴄᴛs ғʀᴏᴍ ᴛʜᴇ ᴘᴇʀsᴏɴ ʏᴏᴜ ᴡᴀɴᴛ ᴛᴏ ᴀᴅᴅ WL")
                else:
                    cl.sendText(msg.to,"❂➤ Cᴏᴍᴍᴀɴᴅ Fᴏʀ Oᴡɴᴇʀ")
#-------------------------------------------------------------------------------#  
            elif msg.text in ["Wlet","Allletak"]:
                if msg.from_ in Owner:
                    wait["adminletak"] = True
                    cl.sendText(msg.to,"❂➤Pʟᴇᴀsᴇ sᴇɴᴅ ᴄᴏɴᴛᴀᴄᴛs ғʀᴏᴍ ᴛʜᴇ ᴘᴇʀsᴏɴ ʏᴏᴜ ᴡᴀɴᴛ ᴛᴏ ʀᴇᴍᴏᴠᴇ WL")
                else:
                    cl.sendText(msg.to,"❂➤ Cᴏᴍᴍᴀɴᴅ Fᴏʀ Oᴡɴᴇʀ")
#======================================================================================#  
            elif "Wladd @" in msg.text:
              if msg.from_ in Owner:
                print "[Command]Wl executing"
                _name = msg.text.replace("Wladd @","")
                _nametarget = _name.rstrip('  ')
                gs = cl.getGroup(msg.to)
                targets = []
                for g in gs.members:
                    if _nametarget == g.displayName:
                        targets.append(g.mid)
                if targets == []:
                   cl.sendText(msg.to,"❂➤Cᴏɴᴛᴀᴄᴛ ɴᴏᴛ ғᴏᴜɴᴅ")
                else:
                   for target in targets:
                        try:
                            admin.append(target)
                            cl.sendText(msg.to,"❂➤WL Dɪᴛᴀᴍʙᴀʜᴋᴀɴ")
                        except:
                            pass
                print "[Command]Whitelist add executed"
              else:
                cl.sendText(msg.to,"❂➤Cᴏᴍᴍᴀɴᴅ ᴅᴇɴɪᴇᴅ")
                cl.sendText(msg.to,"❂➤Oᴡɴᴇʀ ᴘᴇʀᴍɪssɪᴏɴ ʀᴇǫᴜɪʀᴇᴅ")
                
            elif "Wlrem @" in msg.text:
              if msg.from_ in Owner:
                print "[Command]Staff remove executing"
                _name = msg.text.replace("Wlrem @","")
                _nametarget = _name.rstrip('  ')
                gs = cl.getGroup(msg.to)
                targets = []
                for g in gs.members:
                    if _nametarget == g.displayName:
                        targets.append(g.mid)
                if targets == []:
                   cl.sendText(msg.to,"❂➤Cᴏɴᴛᴀᴄᴛ ɴᴏᴛ ғᴏᴜɴᴅ")
                else:
                   for target in targets:
                        try:
                            admin.remove(target)
                            cl.sendText(msg.to,"❂➤WL Dɪʜᴀᴘᴜs")
                        except:
                            pass
                print "[Command]Whitelist remove executed"
              else:
                cl.sendText(msg.to,"❂➤Cᴏᴍᴍᴀɴᴅ ᴅᴇɴɪᴇᴅ")
                cl.sendText(msg.to,"❂➤Oᴡɴᴇʀ ᴘᴇʀᴍɪssɪᴏɴ ʀᴇǫᴜɪʀᴇᴅ")
#-------------------------------------------------------------------------------
            elif msg.text in ["Wlist","wlist"]:
                if msg.from_ in Owner and admin and Bots:
                    if admin == []:
                        cl.sendText(msg.to,"Whitelist is empty")
                    else:
                        cl.sendText(msg.to,"Tunggu...")
                        mc = "╔═══════ஜ۩۞۩ஜ══════╗\n║           || 🔰-Whitelist-🔰 ||\n╠══════════════════╣\n"
                        for mi_d in admin:
                            mc += "╠⌬" +cl.getContact(mi_d).displayName + "\n"
                        cl.sendText(msg.to,mc)
                        print "[Command]Wllist executed"

#======================================================================================#
#================================[ JK SET START ]================================#
#======================================================================================# 

            elif msg.text.lower() == 'protect on':
                if msg.from_ in Owner:
                    if wait["protect"] == True:
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"❂➤ Pʀᴏᴛᴇᴄᴛɪᴏɴ ᴀʟʀᴇᴀᴅʏ ᴏɴ")
                        else:
                            cl.sendText(msg.to,"❂➤ Pʀᴏᴛᴇᴄᴛɪᴏɴ sᴇᴛ ᴛᴏ ᴏɴ")
                    else:
                        wait["protect"] = True
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"❂➤ Pʀᴏᴛᴇᴄᴛɪᴏɴ sᴇᴛ ᴛᴏ ᴏɴ")
                        else:
                            cl.sendText(msg.to,"❂➤ Pʀᴏᴛᴇᴄᴛɪᴏɴ ᴀʟʀᴇᴀᴅʏ ᴏɴ")
                            
            elif msg.text.lower() == 'protect off':
                if msg.from_ in Owner:
                    if wait["protect"] == False:
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"❂➤ Pʀᴏᴛᴇᴄᴛɪᴏɴ ᴀʟʀᴇᴀᴅʏ ᴏғғ")
                        else:
                            cl.sendText(msg.to,"❂➤ Pʀᴏᴛᴇᴄᴛɪᴏɴ sᴇᴛ ᴛᴏ ᴏғғ")
                    else:
                        wait["protect"] = False
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"❂➤ Pʀᴏᴛᴇᴄᴛɪᴏɴ sᴇᴛ ᴛᴏ ᴏғғ")
                        else:
                            cl.sendText(msg.to,"❂➤ Pʀᴏᴛᴇᴄᴛɪᴏɴ ᴀʟʀᴇᴀᴅʏ ᴏғғ")
#-------------------------------------------------------------------------------
            elif msg.text.lower() == 'qr on':
                if msg.from_ in Owner:
                    if wait["linkprotect"] == True:
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"❂➤ Pʀᴏᴛᴇᴄᴛɪᴏɴ Qʀ ᴀʟʀᴇᴀᴅʏ ᴏɴ")
                        else:
                            cl.sendText(msg.to,"❂➤ Pʀᴏᴛᴇᴄᴛɪᴏɴ Qʀ sᴇᴛ ᴛᴏ ᴏɴ")
                    else:
                        wait["linkprotect"] = True
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"❂➤ Pʀᴏᴛᴇᴄᴛɪᴏɴ Qʀ sᴇᴛ ᴛᴏ ᴏɴ")
                        else:
                            cl.sendText(msg.to,"❂➤ Pʀᴏᴛᴇᴄᴛɪᴏɴ Qʀ ᴀʟʀᴇᴀᴅʏ ᴏɴ")
                            
            elif msg.text.lower() == 'qr off':
                if msg.from_ in Owner:
                    if wait["linkprotect"] == False:
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"❂➤ Pʀᴏᴛᴇᴄᴛɪᴏɴ Qʀ ᴀʟʀᴇᴀᴅʏ ᴏғғ")
                        else:
                            cl.sendText(msg.to,"❂➤ Pʀᴏᴛᴇᴄᴛɪᴏɴ Qʀ sᴇᴛ ᴛᴏ ᴏғғ")
                    else:
                        wait["linkprotect"] = False
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"❂➤ Pʀᴏᴛᴇᴄᴛɪᴏɴ Qʀ sᴇᴛ ᴛᴏ ᴏғғ")
                        else:
                            cl.sendText(msg.to,"❂➤ Pʀᴏᴛᴇᴄᴛɪᴏɴ Qʀ ᴀʟʀᴇᴀᴅʏ ᴏғғ")
#-------------------------------------------------------------------------------                     
            elif msg.text.lower() == 'invit on':
                if msg.from_ in Owner:
                    if wait["inviteprotect"] == True:
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"❂➤ Pʀᴏᴛᴇᴄᴛɪᴏɴ Iɴᴠɪᴛᴇ ᴀʟʀᴇᴀᴅʏ ᴏɴ")
                        else:
                            cl.sendText(msg.to,"❂➤ Pʀᴏᴛᴇᴄᴛɪᴏɴ Iɴᴠɪᴛᴇ sᴇᴛ ᴛᴏ ᴏɴ")
                    else:
                        wait["inviteprotect"] = True
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"❂➤ Pʀᴏᴛᴇᴄᴛɪᴏɴ Iɴᴠɪᴛᴇ sᴇᴛ ᴛᴏ ᴏɴ")
                        else:
                            cl.sendText(msg.to,"❂➤ Pʀᴏᴛᴇᴄᴛɪᴏɴ Iɴᴠɪᴛᴇ ᴀʟʀᴇᴀᴅʏ ᴏɴ")
                            
            elif msg.text.lower() == 'invit off':
                if msg.from_ in Owner:
                    if wait["inviteprotect"] == False:
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"❂➤ Pʀᴏᴛᴇᴄᴛɪᴏɴ Iɴᴠɪᴛᴇ ᴀʟʀᴇᴀᴅʏ ᴏғғ")
                        else:
                            cl.sendText(msg.to,"❂➤ Pʀᴏᴛᴇᴄᴛɪᴏɴ Iɴᴠɪᴛᴇ sᴇᴛ ᴛᴏ ᴏғғ")
                    else:
                        wait["inviteprotect"] = False
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"❂➤ Pʀᴏᴛᴇᴄᴛɪᴏɴ Iɴᴠɪᴛᴇ sᴇᴛ ᴛᴏ ᴏғғ")
                        else:
                            cl.sendText(msg.to,"❂➤ Pʀᴏᴛᴇᴄᴛɪᴏɴ Iɴᴠɪᴛᴇ ᴀʟʀᴇᴀᴅʏ ᴏғғ")
#----------------------------------------------------------------------------------------                        
            elif msg.text in ["Wlcip on","Allcipok on"]:
                if msg.from_ in Owner:
                    if wait["admincipok"] == True:
                        wait["adminletak"] = False
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"❂➤ Aᴅᴍɪɴᴄɪᴘᴏᴋ sᴇᴛ ᴛᴏ ᴏɴ")
                        else:
                            cl.sendText(msg.to,"❂➤ Aᴅᴍɪɴᴄɪᴘᴏᴋ ᴀʟʀᴇᴀᴅʏ ᴏɴ")
                    else:
                        wait["admincipok"] = True
                        wait["adminletak"] = False
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"❂➤ Aᴅᴍɪɴᴄɪᴘᴏᴋ sᴇᴛ ᴛᴏ ᴏɴ")
                        else:
                            cl.sendText(msg.to,"❂➤ Aᴅᴍɪɴᴄɪᴘᴏᴋ ᴀʟʀᴇᴀᴅʏ ᴏɴ")
                                                   
            elif msg.text in ["Wlcip off","Allcipok off"]:
                if msg.from_ in Owner:
                    if wait["admincipok"] == False:
                        wait["adminletak"] = False
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"❂➤ Aᴅᴍɪɴᴄɪᴘᴏᴋ sᴇᴛ ᴛᴏ ᴏғғ")
                        else:
                            cl.sendText(msg.to,"❂➤ Aᴅᴍɪɴᴄɪᴘᴏᴋ ᴀʟʀᴇᴀᴅʏ ᴏғғ")
                    else:
                        wait["admincipok"] = False
                        wait["adminletak"] = False
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"❂➤ Aᴅᴍɪɴᴄɪᴘᴏᴋ sᴇᴛ ᴛᴏ ᴏғғ")
                        else:
                            cl.sendText(msg.to,"❂➤ Aᴅᴍɪɴᴄɪᴘᴏᴋ ᴀʟʀᴇᴀᴅʏ ᴏғғ")
#----------------------------------------------------------------------------------------                        
            elif msg.text in ["Wlet on","Allletak on"]:
                if msg.from_ in Owner:
                    if wait["adminletak"] == True:
                        wait["admincipok"] = False
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"❂➤ WL ʟᴇᴛᴀᴋ sᴇᴛ ᴛᴏ ᴏɴ")
                        else:
                            cl.sendText(msg.to,"❂➤ WL ʟᴇᴛᴀᴋ ᴀʟʀᴇᴀᴅʏ ᴏɴ")
                    else:
                        wait["adminletak"] = True
                        wait["admincipok"] = False
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"❂➤ WL ʟᴇᴛᴀᴋ sᴇᴛ ᴛᴏ ᴏɴ")
                        else:
                            cl.sendText(msg.to,"❂➤ WL ʟᴇᴛᴀᴋ ᴀʟʀᴇᴀᴅʏ ᴏɴ")
                                                   
            elif msg.text in ["Wlet off","Allletak off"]:
                if msg.from_ in Owner:
                    if wait["adminletak"] == False:
                        wait["admincipok"] = False
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"❂➤ WL ʟᴇᴛᴀᴋ sᴇᴛ ᴛᴏ ᴏғғ")
                        else:
                            cl.sendText(msg.to,"❂➤ WL ʟᴇᴛᴀᴋ ᴀʟʀᴇᴀᴅʏ ᴏғғ")
                    else:
                        wait["adminletak"] = False
                        wait["admincipok"] = False
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"❂➤ WL ʟᴇᴛᴀᴋ sᴇᴛ ᴛᴏ ᴏғғ")
                        else:
                            cl.sendText(msg.to,"❂➤ WL ʟᴇᴛᴀᴋ ᴀʟʀᴇᴀᴅʏ ᴏғғ")
#-------------------------------------------------------------------------------
            elif msg.text.lower() == 'cancel on':
                if msg.from_ in Owner:
                    if wait["cancelprotect"] == True:
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"❂➤ Cᴀɴᴄᴇʟ Pʀᴏᴛᴇᴄᴛɪᴏɴ Iɴᴠɪᴛᴇ ᴀʟʀᴇᴀᴅʏ ᴏɴ")
                        else:
                            cl.sendText(msg.to,"❂➤ Cᴀɴᴄᴇʟ Pʀᴏᴛᴇᴄᴛɪᴏɴ Iɴᴠɪᴛᴇ sᴇᴛ ᴛᴏ ᴏɴ")
                    else:
                        wait["cancelprotect"] = True
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"❂➤ Cᴀɴᴄᴇʟ Pʀᴏᴛᴇᴄᴛɪᴏɴ Iɴᴠɪᴛᴇ sᴇᴛ ᴛᴏ ᴏɴ")
                        else:
                            cl.sendText(msg.to,"❂➤ Cᴀɴᴄᴇʟ Pʀᴏᴛᴇᴄᴛɪᴏɴ Iɴᴠɪᴛᴇ ᴀʟʀᴇᴀᴅʏ ᴏɴ")
                            
            elif msg.text.lower() == 'cancel off':
                if msg.from_ in Owner:
                    if wait["cancelprotect"] == False:
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"❂➤ Cᴀɴᴄᴇʟ Pʀᴏᴛᴇᴄᴛɪᴏɴ Iɴᴠɪᴛᴇ ᴀʟʀᴇᴀᴅʏ ᴏғғ")
                        else:
                            cl.sendText(msg.to,"❂➤ Cᴀɴᴄᴇʟ Pʀᴏᴛᴇᴄᴛɪᴏɴ Iɴᴠɪᴛᴇ sᴇᴛ ᴛᴏ ᴏғғ")
                    else:
                        wait["cancelprotect"] = False
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"❂➤ Cᴀɴᴄᴇʟ Pʀᴏᴛᴇᴄᴛɪᴏɴ Iɴᴠɪᴛᴇ sᴇᴛ ᴛᴏ ᴏғғ")
                        else:
                            cl.sendText(msg.to,"❂➤ Cᴀɴᴄᴇʟ Pʀᴏᴛᴇᴄᴛɪᴏɴ Iɴᴠɪᴛᴇ ᴀʟʀᴇᴀᴅʏ ᴏғғ")
#-------------------------------------------------------------------------------
            elif msg.text.lower() == 'link on':
                if msg.from_ in Owner:
                    if msg.toType == 2:
                        group = cl.getGroup(msg.to)
                        group.preventJoinByTicket = False
                        cl.updateGroup(group)
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"❂➤URL open")
                        else:
                            cl.sendText(msg.to,"❂➤URL open")
                    else:
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"❂➤It can not be used outside the group")
                        else:
                            cl.sendText(msg.to,"❂➤Can not be used for groups other than")
            
            elif msg.text.lower() == 'link off':
                if msg.from_ in Owner:
                    if msg.toType == 2:
                        group = cl.getGroup(msg.to)
                        group.preventJoinByTicket = True
                        cl.updateGroup(group)
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"❂➤URL close")
                        else:
                            cl.sendText(msg.to,"❂➤URL close")
                    else:
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"❂➤It can not be used outside the group")
                        else:
                            cl.sendText(msg.to,"❂➤Can not be used for groups other than")
#-------------------------------------------------------------------------------
            elif msg.text in ["Bot mute"]:
                if msg.from_ in Owner:
                    wait["Bot"] = False
                    cl.sendText(msg.to,"❂➤ Mᴜᴛᴇ ᴛʜᴇ ʙᴏᴛ")
                else:
                    cl.sendText(msg.to,"❂➤ Cᴏᴍᴍᴀɴᴅ Fᴏʀ Oᴡɴᴇʀ")  
#-------------------------------------------------------------------------------
            elif "Ghost on" in msg.text:
                if msg.from_ in Owner:
                    wait["Ghost"] = True
                    cl.sendText(msg.to,"❂➤Ghost Turn On")
                
            elif "Ghost off" in msg.text:
                if msg.from_ in Owner:
                    wait["Ghost"] = False
                    cl.sendText(msg.to,"❂➤Ghost Turn Off")
#-------------------------------------------------------------------------------
            elif msg.text in ["Setpro on"]:
                if msg.from_ in Owner:
                    wait["Ghost"] = True
                    wait["protect"] = True
                    wait["linkprotect"] = True
                    wait["inviteprotect"] = True
                    wait["cancelprotect"] = True
                    cl.sendText(msg.to,"❂➤ Sᴇᴛ Pʀᴏᴛᴇᴄᴛ Sᴜᴅᴀʜ Dɪ Aᴋᴛɪғᴋᴀɴ Sᴇᴍᴜᴀ")
                else:
                    cl.sendText(msg.to,"❂➤Just for Owner")
                    		            
            elif msg.text in ["Setpro off"]:
                if msg.from_ in Owner:
                    wait["Ghost"] = False
                    wait["protect"] = False
                    wait["linkprotect"] = False
                    wait["inviteprotect"] = False
                    wait["cancelprotect"] = False
                    cl.sendText(msg.to,"❂➤ Sᴇᴛ Pʀᴏᴛᴇᴄᴛ Sᴜᴅᴀʜ Dɪ Nᴏɴᴀᴋᴛɪғᴋᴀɴ Sᴇᴍᴜᴀ")
                else:
                    cl.sendText(msg.to,"❂➤Just for Owner")
#---------------------------------------------------------
            elif msg.text in ["Setself on"]:
                if msg.from_ in Owner:
                    wait["Ghost"] = True
                    wait["autoJoin"] = True
                    wait["leaveRoom"] = True
                    wait["timeline"] = True
                    wait["likeOn"] = True
                    wait["autoAdd"] = True
                    wait["alwayRead"] = True
                    wait["detectMention"] = True
                    wait["commentOn"] = True
                    wait["Sambutan"] = True
                    cl.sendText(msg.to,"❂➤ Sᴇᴛ Sᴇʟғ Sᴜᴅᴀʜ Dɪ Aᴋᴛɪғᴋᴀɴ Sᴇᴍᴜᴀ")
                else:
                    cl.sendText(msg.to,"❂➤Just for Owner")
                    		            
            elif msg.text in ["Setself off"]:
                if msg.from_ in Owner:
                    wait["Ghost"] = False
                    wait["autoJoin"] = False
                    wait["leaveRoom"] = False
                    wait["timeline"] = False
                    wait["likeOn"] = False
                    wait["autoAdd"] = False
                    wait["alwayRead"] = False
                    wait["detectMention"] = False
                    wait["commentOn"] = False
                    wait["Sambutan"] = True
                    cl.sendText(msg.to,"❂➤ Sᴇᴛ Sᴇʟғ Sᴜᴅᴀʜ Dɪ Nᴏɴᴀᴋᴛɪғᴋᴀɴ Sᴇᴍᴜᴀ")
                else:
                    cl.sendText(msg.to,"❂➤Just for Owner")
#-------------------------------------------------------------------------------
            elif msg.text.lower() == 'contact on':
                if msg.from_ in Owner:
                    if wait["contact"] == True:
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"❂➤ ᴄᴏɴᴛᴀᴄᴛ ᴀʟʀᴇᴀᴅʏ ᴏɴ")
                        else:
                            cl.sendText(msg.to,"❂➤ ᴄᴏɴᴛᴀᴄᴛ sᴇᴛ ᴛᴏ ᴏɴ")
                    else:
                        wait["contact"] = True
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"❂➤ ᴄᴏɴᴛᴀᴄᴛ sᴇᴛ ᴛᴏ ᴏɴ")
                        else:
                            cl.sendText(msg.to,"❂➤ ᴄᴏɴᴛᴀᴄᴛ ᴀʟʀᴇᴀᴅʏ ᴏɴ")
                            
            elif msg.text.lower() == 'contact off':
                if msg.from_ in Owner:
                    if wait["contact"] == False:
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"❂➤ ᴄᴏɴᴛᴀᴄᴛ ᴀʟʀᴇᴀᴅʏ ᴏғғ")
                        else:
                            cl.sendText(msg.to,"❂➤ ᴄᴏɴᴛᴀᴄᴛ sᴇᴛ ᴛᴏ ᴏғғ")
                    else:
                        wait["contact"] = False
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"❂➤ ᴄᴏɴᴛᴀᴄᴛ sᴇᴛ ᴛᴏ ᴏғғ")
                        else:
                            cl.sendText(msg.to,"❂➤ ᴄᴏɴᴛᴀᴄᴛ ᴀʟʀᴇᴀᴅʏ ᴏғғ")
#----------------------------------------------------------------------------------------     
            elif msg.text in ["Jkick on"]:
                if msg.from_ in admin:	        
                    wait["joinkick"] = True
                    wait["Sambutan"] = False
                    wait["protect"] = False
                    cl.sendText(msg.to,"❂➤ Jᴏɪɴ Kɪᴄᴋ Sᴇᴛ Tᴏ Oɴ")
                else:
                    cl.sendText(msg.to,"❂➤ Cᴏᴍᴍᴀɴᴅ Fᴏʀ Oᴡɴᴇʀ")
                    
            elif msg.text in ["Jkick off"]:
                if msg.from_ in admin:	        
                    wait["joinkick"] = False
                    wait["Sambutan"] = True
                    wait["protect"] = True
                    cl.sendText(msg.to,"❂➤ Jᴏɪɴ Kɪᴄᴋ Sᴇᴛ Tᴏ Oғғ")
                else:
                    cl.sendText(msg.to,"❂➤ Cᴏᴍᴍᴀɴᴅ Fᴏʀ Oᴡɴᴇʀ")	
#-------------------------------------------------------------------------------
            elif msg.text.lower() == 'autojoin on':
                if msg.from_ in Owner:
                    if wait["autoJoin"] == True:
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"❂➤ Aᴜᴛᴏᴊᴏɪɴ ᴀʟʀᴇᴀᴅʏ ᴏɴ")
                        else:
                            cl.sendText(msg.to,"❂➤ Aᴜᴛᴏᴊᴏɪɴ sᴇᴛ ᴛᴏ ᴏɴ")
                    else:
                        wait["autoJoin"] = True
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"❂➤ Aᴜᴛᴏᴊᴏɪɴ sᴇᴛ ᴛᴏ ᴏɴ")
                        else:
                            cl.sendText(msg.to,"❂➤ Aᴜᴛᴏᴊᴏɪɴ ᴀʟʀᴇᴀᴅʏ ᴏɴ")
                            
            elif msg.text.lower() == 'autojoin off':
                if msg.from_ in Owner:
                    if wait["autoJoin"] == False:
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"❂➤ Aᴜᴛᴏᴊᴏɪɴ ᴀʟʀᴇᴀᴅʏ ᴏғғ")
                        else:
                            cl.sendText(msg.to,"❂➤ Aᴜᴛᴏᴊᴏɪɴ sᴇᴛ ᴛᴏ ᴏғғ")
                    else:
                        wait["autoJoin"] = False
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"❂➤ Aᴜᴛᴏᴊᴏɪɴ sᴇᴛ ᴛᴏ ᴏғғ")
                        else:
                            cl.sendText(msg.to,"❂➤ Aᴜᴛᴏᴊᴏɪɴ ᴀʟʀᴇᴀᴅʏ ᴏғғ")
#-------------------------------------------------------------------------------                    
            elif msg.text.lower() == 'autoleave on':
                if msg.from_ in Owner:
                    if wait["leaveRoom"] == True:
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"❂➤Auto Leave room set to on")
                        else:
                            cl.sendText(msg.to,"❂➤Auto Leave room already on")
                    else:
                        wait["leaveRoom"] = True
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"❂➤Auto Leave room set to on")
                        else:
                            cl.sendText(msg.to,"❂➤Auto Leave room already on")
                            
            elif msg.text.lower() == 'autoleave off':
                if msg.from_ in Owner:
                    if wait["leaveRoom"] == False:
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"❂➤Auto Leave room set to off")
                        else:
                            cl.sendText(msg.to,"❂➤Auto Leave room already off")
                    else:
                        wait["leaveRoom"] = False
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"❂➤Auto Leave room set to off")
                        else:
                            cl.sendText(msg.to,"❂➤Auto Leave room already off")
#-------------------------------------------------------------------------------
            elif msg.text.lower() == 'autoadd on':
                if msg.from_ in Owner:
                    if wait["autoAdd"] == True:
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"❂➤Auto add set to on")
                        else:
                            cl.sendText(msg.to,"❂➤Auto add already on")
                    else:
                        wait["autoAdd"] = True
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"❂➤Auto add set to on")
                        else:
                            cl.sendText(msg.to,"❂➤Auto add already on")
                            
            elif msg.text.lower() == 'autoadd off':
                if msg.from_ in Owner:
                    if wait["autoAdd"] == False:
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"❂➤Auto add set to off")
                        else:
                            cl.sendText(msg.to,"❂➤Auto add already off")
                    else:
                        wait["autoAdd"] = False
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"❂➤Auto add set to off")
                        else:
                            cl.sendText(msg.to,"❂➤Auto add already off")
#-------------------------------------------------------------------------------
            elif msg.text in ["Autorespon on","Autorespon:on","Respon on","Respon:on"]:
                if msg.from_ in Owner:
                    wait["detectMention"] = True
                    wait["detectMention"] = False
                    wait["detectMention2"] = False
                    wait["detectMention3"] = True
                    wait["detectMentionpc"] = False
                    wait["kickMention"] = False
                    cl.sendText(msg.to,"❂➤ Aᴜᴛᴏ Rᴇsᴘᴏɴ Sᴇᴛ Tᴏ Oɴ")
                
            elif msg.text in ["Autorespon off","Autorespon:off","Respon off","Respon:off"]:
                if msg.from_ in Owner:
                    wait["detectMention"] = False
                    wait["detectMention2"] = False
                    wait["detectMention3"] = False
                    wait["detectMentionpc"] = False
                    wait["kickMention"] = False
                    cl.sendText(msg.to,"❂➤ Aᴜᴛᴏ Rᴇsᴘᴏɴ Sᴇᴛ Tᴏ Oғғ")
#-------------------------------------------------------------------------------
            elif msg.text in ["Arespon on"]:
                if msg.from_ in admin:
                    wait["detectMention"] = True
                    wait["detectMention2"] = False
                    wait["detectMention3"] = False
                    wait["detectMentionpc"] = False
                    wait["kickMention"] = False
                    cl.sendText(msg.to,"❂➤ Aᴜᴛᴏʀᴇsᴘᴏɴ Sᴇᴛ Tᴏ 『A』")
                else:
                    cl.sendText(msg.to,"")
                    
            elif msg.text in ["Brespon on"]:
                if msg.from_ in admin:
                    wait["detectMention"] = False
                    wait["detectMention2"] = True
                    wait["detectMention3"] = False
                    wait["detectMentionpc"] = False
                    wait["kickMention"] = False
                    cl.sendText(msg.to,"❂➤ Aᴜᴛᴏʀᴇsᴘᴏɴ Sᴇᴛ Tᴏ 『B』")
                else:
                    cl.sendText(msg.to,"")
                            
            elif msg.text in ["Crespon on"]:
                if msg.from_ in admin:
                    wait["detectMention"] = False
                    wait["detectMention2"] = False
                    wait["detectMention3"] = True
                    wait["detectMentionpc"] = False
                    wait["kickMention"] = False
                    cl.sendText(msg.to,"❂➤ Aᴜᴛᴏʀᴇsᴘᴏɴ Sᴇᴛ Tᴏ 『C』")
                else:
                    cl.sendText(msg.to,"")
                    
            elif msg.text in ["Pcrespon on"]:
                if msg.from_ in admin:
                    wait["detectMentionpc"] = True
                    wait["kickMention"] = False
                    cl.sendText(msg.to,"❂➤ Rᴇsᴘᴏɴ PC Tᴜʀɴ Oɴ")
                else:
                    cl.sendText(msg.to,"")
                    
            elif msg.text in ["Pcrespon off"]:
                if msg.from_ in admin:
                    wait["detectMentionpc"] = False
                    cl.sendText(msg.to,"❂➤ Rᴇsᴘᴏɴ PC Tᴜʀɴ Oғғ")
                else:
                    cl.sendText(msg.to,"")
#-------------------------------------------------------------------------------
            elif msg.text in ["Responkick on"]:
                if msg.from_ in Owner:
                    wait["detectMention"] = False
                    wait["detectMention2"] = False
                    wait["detectMention3"] = False
                    wait["detectMentionpc"] = False
                    wait["kickMention"] = True
                    cl.sendText(msg.to,"❂➤ Rᴇsᴘᴏɴ Kɪᴄᴋ Sᴇᴛ Tᴏ Oɴ")
                
            elif msg.text in ["Responkick off"]:
                if msg.from_ in Owner:
                    wait["kickMention"] = False
                    cl.sendText(msg.to,"❂➤ Rᴇsᴘᴏɴ Kɪᴄᴋ Sᴇᴛ Tᴏ Oғғ")
#-------------------------------------------------------------------------------
            elif msg.text.lower() == 'jam on':
                if msg.from_ in Owner:
                    if wait["clock"] == True:
                        cl.sendText(msg.to,"❂➤Jam already on")
                    else:
                        wait["clock"] = True
                        now2 = datetime.now()
                        nowT = datetime.strftime(now2,"?%H:%M?")
                        profile = cl.getProfile()
                        profile.displayName = wait["cName"] + nowT
                        cl.updateProfile(profile)
                        cl.sendText(msg.to,"❂➤Jam set on")
                        
            elif msg.text.lower() == 'jam off':
                if msg.from_ in Owner:
                    if wait["clock"] == False:
                        cl.sendText(msg.to,"❂➤Jam already off")
                    else:
                        wait["clock"] = False
                        cl.sendText(msg.to,"❂➤Jam set off")
                        
            elif "Jam say:" in msg.text:
                if msg.from_ in Owner and admin and Bots:
                    n = msg.text.replace("Jam say:","")
                    if len(n.decode("utf-8")) > 30:
                        cl.sendText(msg.to,"❂➤terlalu lama")
                    else:
                        wait["cName"] = n
                        cl.sendText(msg.to,"❂➤Nama Jam Berubah menjadi:" + n)
                        
            elif msg.text.lower() == 'update':
                if msg.from_ in Owner:
                    if wait["clock"] == True:
                        now2 = datetime.now()
                        nowT = datetime.strftime(now2,"?%H:%M?")
                        profile = cl.getProfile()
                        profile.displayName = wait["cName"] + nowT
                        cl.updateProfile(profile)
                        cl.sendText(msg.to,"❂➤Diperbarui")
                    else:
                        cl.sendText(msg.to,"❂➤Silahkan Aktifkan Jam")
#-------------------------------------------------------------------------------
            elif "Mimic " in msg.text:
                if msg.from_ in Owner and admin and Bots:
                    cmd = msg.text.replace("Mimic ","")
                    if cmd == "on":
                        if mimic["status"] == False:
                            mimic["status"] = True
                            cl.sendText(msg.to,"❂➤Reply Message on")
                        else:
                            cl.sendText(msg.to,"Sudah on")
                    elif cmd == "off":
                        if mimic["status"] == True:
                            mimic["status"] = False
                            cl.sendText(msg.to,"❂➤Reply Message off")
                        else:
                            cl.sendText(msg.to,"❂➤Sudah off")
                            
            elif ("Micadd " in msg.text):
                if msg.from_ in Owner and admin and Bots:
                    targets = []
                    key = eval(msg.contentMetadata["MENTION"])
                    key["MENTIONEES"][0]["M"]
                    for x in key["MENTIONEES"]:
                        targets.append(x["M"])
                    for target in targets:
                        try:
                            mimic["target"][target] = True
                            cl.sendText(msg.to,"❂➤Target ditambahkan!")
                            break
                        except:
                            cl.sendText(msg.to,"❂➤Fail !")
                            break
                    
            elif ("Micdel " in msg.text):
                if msg.from_ in Owner and admin and Bots:
                    targets = []
                    key = eval(msg.contentMetadata["MENTION"])
                    key["MENTIONEES"][0]["M"]
                    for x in key["MENTIONEES"]:
                        targets.append(x["M"])
                    for target in targets:
                        try:
                            del mimic["target"][target]
                            cl.sendText(msg.to,"❂➤Target dihapuskan!")
                            break
                        except:
                            cl.sendText(msg.to,"❂➤Fail !")
                            break
                    
            elif msg.text in ["Miclist"]:
                if msg.from_ in Owner and admin and Bots:
                        if mimic["target"] == {}:
                            cl.sendText(msg.to,"nothing")
                        else:
                            mc = "Target mimic user\n"
                            for mi_d in mimic["target"]:
                                mc += "?? "+cl.getContact(mi_d).displayName + "\n"
                            cl.sendText(msg.to,mc)

            elif "Mimic target" in msg.text:
                if msg.from_ in Owner and admin and Bots:
                        if mimic["copy"] == True:
                            siapa = msg.text.replace("Mimic target","")
                            if siapa.rstrip(' ') == "me":
                                mimic["copy2"] = "me"
                                cl.sendText(msg.to,"Mimic change to me")
                            elif siapa.rstrip(' ') == "target":
                                mimic["copy2"] = "target"
                                cl.sendText(msg.to,"❂➤Mimic change to target")
                            else:
                                cl.sendText(msg.to,"❂➤I dont know")
#-------------------------------------------------------------------------------
            elif msg.text in ["Welcome on"]:
                if msg.from_ in Owner:
                    if wait["Sambutan"] == True:
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"❂➤ Wᴇʟᴄᴏᴍᴇ ᴀʟʀᴇᴀᴅʏ ᴏɴ")
                        else:
                            cl.sendText(msg.to,"❂➤ Wᴇʟᴄᴏᴍᴇ sᴇᴛ ᴛᴏ ᴏɴ")
                    else:
                        wait["Sambutan"] = True
                        wait["joinkick"] = False
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"❂➤ Wᴇʟᴄᴏᴍᴇ sᴇᴛ ᴛᴏ ᴏɴ")
                        else:
                            cl.sendText(msg.to,"❂➤ Wᴇʟᴄᴏᴍᴇ ᴀʟʀᴇᴀᴅʏ ᴏɴ")
                else:
                    cl.sendText(msg.to,"❂➤ Cᴏᴍᴍᴀɴᴅ Fᴏʀ Oᴡɴᴇʀ")
                            
            elif msg.text in ["Welcome off"]:
                if msg.from_ in Owner:
                    if wait["Sambutan"] == False:
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"❂➤ Wᴇʟᴄᴏᴍᴇ ᴀʟʀᴇᴀᴅʏ ᴏғғ")
                        else:
                            cl.sendText(msg.to,"❂➤ Wᴇʟᴄᴏᴍᴇ sᴇᴛ ᴛᴏ ᴏғғ")
                    else:
                        wait["Sambutan"] = False
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"❂➤ Wᴇʟᴄᴏᴍᴇ sᴇᴛ ᴛᴏ ᴏғғ")
                        else:
                            cl.sendText(msg.to,"❂➤ Wᴇʟᴄᴏᴍᴇ ᴀʟʀᴇᴀᴅʏ ᴏғғ")
                else:
                    cl.sendText(msg.to,"❂➤ Cᴏᴍᴍᴀɴᴅ Fᴏʀ Oᴡɴᴇʀ")
#----------------------------------------------------------------------------------------
            elif msg.text in ["Come on","Com:on","Comment on"]:
                if msg.from_ in Owner and admin and Bots:
                    if wait["commentOn"] == True:
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"❂➤ Cᴏᴍᴍᴇɴᴛ ɪs Aʟʀᴇᴀᴅʏ Oɴ")
                        else:
                            cl.sendText(msg.to,"❂➤ Cᴏᴍᴍᴇɴᴛ Sᴇᴛ Tᴏ Oɴ")
                    else:
                        wait["commentOn"] = True
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"❂➤ Cᴏᴍᴍᴇɴᴛ Sᴇᴛ Tᴏ Oɴ")
                        else:
                            cl.sendText(msg.to,"❂➤ Cᴏᴍᴍᴇɴᴛ ɪs Aʟʀᴇᴀᴅʏ Oɴ")
                                
            elif msg.text in ["Come off"]:
                if msg.from_ in Owner and admin and Bots:
                    if wait["commentOn"] == False:
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"❂➤ Cᴏᴍᴍᴇɴᴛ ɪs Aʟʀᴇᴀᴅʏ ᴏғғ")
                        else:
                            cl.sendText(msg.to,"❂➤ Cᴏᴍᴍᴇɴᴛ Sᴇᴛ Tᴏ Oғғ")
                    else:
                        wait["commentOn"] = False
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"❂➤ Cᴏᴍᴍᴇɴᴛ Sᴇᴛ Tᴏ Oғғ")
                        else:
                            cl.sendText(msg.to,"❂➤ Cᴏᴍᴍᴇɴᴛ ɪs Aʟʀᴇᴀᴅʏ ᴏғғ")
#-------------------------------------------------------------------------------
#==============================[ COSTUME SET ]==================================
#-------------------------------------------------------------------------------
            elif "Responset: " in msg.text:
                if msg.from_ in Owner:
                    c = msg.text.replace("Responset: ","")
                    if c in [""," ","\n",None]:
                        cl.sendText(msg.to,"❂➤ Mᴇʀᴜᴘᴀᴋᴀɴ sᴛʀɪɴɢ ʏᴀɴɢ ᴛɪᴅᴀᴋ ʙɪsᴀ ᴅɪᴜʙᴀʜ")
                    else:
                        wait["arespon"] = c
                        cl.sendText(msg.to,"❂➤ Rᴇsᴘᴏɴ ᴛᴇʟᴀʜ ᴅɪᴜʙᴀʜ...\n\n" + c)
                            
            elif msg.text in ["Aresponcek"]:
                if msg.from_ in Owner:
                    cl.sendText(msg.to,"❂➤ Rᴇsᴘᴏɴ sᴀᴀᴛ ɪɴɪ ᴛᴇʟᴀʜ ᴅɪᴛᴇᴛᴀᴘᴋᴀɴ sᴇʙᴀɢᴀɪ ʙᴇʀɪᴋᴜᴛ:\n\n" + str(wait["arespon"]))
#-------------------------------------------------------------------------------
            elif "Pcresponset: " in msg.text:
                if msg.from_ in Owner:
                    c = msg.text.replace("Pcresponset: ","")
                    if c in [""," ","\n",None]:
                        cl.sendText(msg.to,"❂➤ Mᴇʀᴜᴘᴀᴋᴀɴ sᴛʀɪɴɢ ʏᴀɴɢ ᴛɪᴅᴀᴋ ʙɪsᴀ ᴅɪᴜʙᴀʜ")
                    else:
                        wait["comepc"] = c
                        cl.sendText(msg.to,"❂➤ Pᴄʀᴇꜱᴘᴏɴ ᴛᴇʟᴀʜ ᴅɪᴜʙᴀʜ...\n\n" + c)
                            
            elif msg.text in ["Pcresponcek"]:
                if msg.from_ in Owner:
                    cl.sendText(msg.to,"❂➤ Pᴄʀᴇꜱᴘᴏɴ sᴀᴀᴛ ɪɴɪ:\n\n" + str(wait["comepc"]))
#-------------------------------------------------------------------------------
            elif "Comegreatset: " in msg.text:
                if msg.from_ in Owner:
                    c = msg.text.replace("Comegreatset: ","")
                    if c in [""," ","\n",None]:
                        cl.sendText(msg.to,"❂➤ Mᴇʀᴜᴘᴀᴋᴀɴ sᴛʀɪɴɢ ʏᴀɴɢ ᴛɪᴅᴀᴋ ʙɪsᴀ ᴅɪᴜʙᴀʜ")
                    else:
                        wait["comegreat"] = c
                        cl.sendText(msg.to,"❂➤ Cᴏᴍᴇɢʀᴇᴀᴛ ᴛᴇʟᴀʜ ᴅɪᴜʙᴀʜ...\n\n" + c)
                            
            elif msg.text in ["Comegreatcek"]:
                if msg.from_ in Owner:
                    cl.sendText(msg.to,"❂➤ Cᴏᴍᴇɢʀᴇᴀᴛ sᴀᴀᴛ ɪɴɪ:\n\n" + str(wait["comegreat"]))
#-------------------------------------------------------------------------------
            elif "Leftgreatset: " in msg.text:
                if msg.from_ in Owner:
                    c = msg.text.replace("Leftgreatset: ","")
                    if c in [""," ","\n",None]:
                        cl.sendText(msg.to,"❂➤ Mᴇʀᴜᴘᴀᴋᴀɴ sᴛʀɪɴɢ ʏᴀɴɢ ᴛɪᴅᴀᴋ ʙɪsᴀ ᴅɪᴜʙᴀʜ")
                    else:
                        wait["leftgreat"] = c
                        cl.sendText(msg.to,"❂➤ Lᴇғᴛɢʀᴇᴀᴛ ᴛᴇʟᴀʜ ᴅɪᴜʙᴀʜ👈\n\n" + c)
                            
            elif msg.text in ["Leftgreatcek"]:
                if msg.from_ in Owner:
                    cl.sendText(msg.to,"❂➤ Lᴇғᴛɢʀᴇᴀᴛ sᴀᴀᴛ ɪɴɪ:\n\n" + str(wait["leftgreat"]))
#-------------------------------------------------------------------------------
            elif "Addgreatset: " in msg.text:
                if msg.from_ in Owner:
                    c = msg.text.replace("Addgreatset: ","")
                    if c in [""," ","\n",None]:
                        cl.sendText(msg.to,"❂➤ Mᴇʀᴜᴘᴀᴋᴀɴ sᴛʀɪɴɢ ʏᴀɴɢ ᴛɪᴅᴀᴋ ʙɪsᴀ ᴅɪᴜʙᴀʜ")
                    else:
                        wait["addgreat"] = c
                        cl.sendText(msg.to,"❂➤ Aᴅᴅɢʀᴇᴀᴛ ᴛᴇʟᴀʜ ᴅɪᴜʙᴀʜ...\n\n" + c)
                            
            elif msg.text in ["Addgreatcek"]:
                if msg.from_ in Owner:
                    cl.sendText(msg.to,"❂➤ Aᴅᴅɢʀᴇᴀᴛ sᴀᴀᴛ ɪɴɪ:\n\n" + str(wait["addgreat"]))
#-------------------------------------------------------------------------------
            elif "Siderset: " in msg.text:
                if msg.from_ in Owner:
                    c = msg.text.replace("Siderset: ","")
                    if c in [""," ","\n",None]:
                        cl.sendText(msg.to,"❂➤ Mᴇʀᴜᴘᴀᴋᴀɴ sᴛʀɪɴɢ ʏᴀɴɢ ᴛɪᴅᴀᴋ ʙɪsᴀ ᴅɪᴜʙᴀʜ")
                    else:
                        wait["siderset"] = c
                        cl.sendText(msg.to,"❂➤ Sɪᴅᴇʀꜱᴇᴛ ᴛᴇʟᴀʜ ᴅɪᴜʙᴀʜ...\n\n" + c)
                            
            elif msg.text in ["Sidercek"]:
                if msg.from_ in Owner:
                    cl.sendText(msg.to,"❂➤ Sɪᴅᴇʀꜱᴇᴛ sᴀᴀᴛ ɪɴɪ:\n\n" + str(wait["siderset"]))
#-------------------------------------------------------------------------------
            elif "Comelikeset: " in msg.text:
                if msg.from_ in Owner:
                    c = msg.text.replace("Comelikeset: ","")
                    if c in [""," ","\n",None]:
                        cl.sendText(msg.to,"❂➤ Mᴇʀᴜᴘᴀᴋᴀɴ sᴛʀɪɴɢ ʏᴀɴɢ ᴛɪᴅᴀᴋ ʙɪsᴀ ᴅɪᴜʙᴀʜ")
                    else:
                        wait["comment"] = c
                        cl.sendText(msg.to,"❂➤ Cᴏᴍᴇʟɪᴋᴇ ᴛᴇʟᴀʜ ᴅɪᴜʙᴀʜ...\n\n" + c)
                            
            elif msg.text in ["Comelikecek"]:
                if msg.from_ in Owner:
                    cl.sendText(msg.to,"❂➤ Cᴏᴍᴇʟɪᴋᴇ sᴀᴀᴛ ɪɴɪ:\n\n" + str(wait["comment"]))
#============================[ COSTUME SET FINISHED ]===========================
#-------------------------------------------------------------------------------
            elif "Pesan set:" in msg.text:
                if msg.from_ in Owner:
                    wait["message"] = msg.text.replace("Pesan set:","")
                    cl.sendText(msg.to,"We changed the message")
                    
            elif msg.text.lower() == 'pesan cek':
                if msg.from_ in Owner:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"❂➤Pesan tambahan otomatis telah ditetapkan sebagai berikut \n\n" + wait["message"])
                    else:
                        cl.sendText(msg.to,"❂➤Pesan tambahan otomatis telah ditetapkan sebagai berikut \n\n" + wait["message"])
#-------------------------------------------------------------------------------
            elif msg.text in ["Like:on","Like on"]:
                if msg.from_ in Owner:
                    if wait["likeOn"] == True:
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"❂➤Done")
                    else:
                        wait["likeOn"] = True
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"❂➤Already")
                        
            elif msg.text in ["Like off","Like:off"]:
                if msg.from_ in Owner:
                    if wait["likeOn"] == False:
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"❂➤Done")
                    else:
                        wait["likeOn"] = False
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"❂➤Already")
                            
            elif msg.text in ["Like:me","Like me"]: #Semua Bot Ngelike Status Akun Utama
                if msg.from_ in Owner:
                    print "[Command]Like executed"
                    cl.sendText(msg.to,"❂➤Like Status Owner")
                    try:
                        likeme()
                    except:
                        pass
                
            elif msg.text in ["Like:friend","Like friend"]: #Semua Bot Ngelike Status Teman
                if msg.from_ in Owner:
                    print "[Command]Like executed"
                    cl.sendText(msg.to,"❂➤Like Status Teman")
                    try:
                        likefriend()
                    except:
                        pass
#-------------------------------------------------------------------------------
            elif msg.text in ["Read on","Read:on"]:
                if msg.from_ in Owner:
                    wait['alwayRead'] = True
                    cl.sendText(msg.to,"❂➤Auto Sider ON")
                
            elif msg.text in ["Read off","Read:off"]:
                if msg.from_ in Owner:
                    wait['alwayRead'] = False
                    cl.sendText(msg.to,"❂➤Auto Sider OFF")
#-------------------------------------------------------------------------------
            elif msg.text in ["Sticker on","Stc on"]:
                if msg.from_ in Owner:
                    if wait['sticker'] == True:
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"❂➤ Dᴇᴛᴇᴄᴛ Sᴛɪᴄᴋᴇʀ Aʟʀᴇᴀᴅʏ Oɴ")
                        else:
                            cl.sendText(msg.to,"❂➤ Dᴇᴛᴇᴄᴛ Sᴛɪᴄᴋᴇʀ Sᴇᴛ ᴛᴏ Oɴ")
                    else:
                        wait['sticker'] = True
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"❂➤ Dᴇᴛᴇᴄᴛ Sᴛɪᴄᴋᴇʀ Sᴇᴛ ᴛᴏ Oɴ")
                        else:
                            cl.sendText(msg.to,"❂➤ Dᴇᴛᴇᴄᴛ Sᴛɪᴄᴋᴇʀ Aʟʀᴇᴀᴅʏ Oɴ")
                else:
                    cl.sendText(msg.to,"❂➤ Cᴏᴍᴍᴀɴᴅ Fᴏʀ Oᴡɴᴇʀ")
#-------------------------------------------------------------------------------
            elif msg.text in ["Sticker off","Stc off"]:
                if msg.from_ in Owner:
                    if wait['sticker'] == False:
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"❂➤ Dᴇᴛᴇᴄᴛ Sᴛɪᴄᴋᴇʀ Aʟʀᴇᴀᴅʏ Oғғ")
                        else:
                            cl.sendText(msg.to,"❂➤ Dᴇᴛᴇᴄᴛ Sᴛɪᴄᴋᴇʀ Sᴇᴛ ᴛᴏ Oғғ")
                    else:
                        wait['sticker'] = False
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"❂➤ Dᴇᴛᴇᴄᴛ Sᴛɪᴄᴋᴇʀ Sᴇᴛ ᴛᴏ Oғғ")
                        else:
                            cl.sendText(msg.to,"❂➤ Dᴇᴛᴇᴄᴛ Sᴛɪᴄᴋᴇʀ Aʟʀᴇᴀᴅʏ Oғғ")
                else:
                    cl.sendText(msg.to,"❂➤ Cᴏᴍᴍᴀɴᴅ Fᴏʀ Oᴡɴᴇʀ")
#-------------------------------------------------------------------------------
            elif msg.text.lower() == 'share on':
                if msg.from_ in Owner:
                    if wait["timeline"] == True:
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"❂➤Share set to on")
                        else:
                            cl.sendText(msg.to,"❂➤Share already on")
                    else:
                        wait["timeline"] = True
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"❂➤Share set to on")
                        else:
                            cl.sendText(msg.to,"❂➤Share already on")
                                
            elif msg.text.lower() == 'share off':
                if msg.from_ in Owner:
                    if wait["timeline"] == False:
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"❂➤Share set to off")
                        else:
                            cl.sendText(msg.to,"❂➤Share already off")
                    else:
                        wait["timeline"] = False
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"❂➤Share set to off")
                        else:
                            cl.sendText(msg.to,"❂➤Share already off")
#-------------------------------------------------------------------------------
            elif msg.text in ["Sider crot"]:
                if msg.from_ in Owner:
                    try:
                        del cctv['point'][msg.to]
                        del cctv['sidermem'][msg.to]
                        del cctv['cyduk'][msg.to]
                    except:
                        pass
                    cctv['point'][msg.to] = msg.id
                    cctv['sidermem'][msg.to] = ""
                    cctv['cyduk'][msg.to]=True
                    wait["Sider"] = True
                    cl.sendText(msg.to,"❂➤Sɪᴅᴇʀ Cᴇᴋ Sɪᴀᴘ Cʀᴏᴛ Bᴏᴜs")
                else:
                    cl.sendText(msg.to,"❂➤ Cᴏᴍᴍᴀɴᴅ Fᴏʀ Oᴡɴᴇʀ")
                
            elif msg.text in ["Sider off"]:
                if msg.from_ in Owner:
                    if msg.to in cctv['point']:
                        cctv['cyduk'][msg.to]=False
                        wait["Sider"] = False
                        cl.sendText(msg.to, "❂➤ Cᴇᴋ Sɪᴅᴇʀ Oғғ")
                    else:
                        cl.sendText(msg.to, "❂➤ Aᴜᴛᴏsɪᴅᴇʀ Bᴇʟᴜᴍ Dɪɴʏᴀʟᴀᴋᴀɴ")  
                else:
                    cl.sendText(msg.to,"❂➤ Cᴏᴍᴍᴀɴᴅ Fᴏʀ Oᴡɴᴇʀ")
#----------------------------------------------------------------------------------------                        
            elif msg.text in ["Ksider on"]:
                if msg.from_ in Owner:
                    if wait["Kicksider"] == True:
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"❂➤ Aᴜᴛᴏᴋɪᴄᴋ sɪᴅᴇʀ ᴀʟʀᴇᴀᴅʏ ᴏɴ")
                        else:
                            cl.sendText(msg.to,"❂➤ Aᴜᴛᴏᴋɪᴄᴋ sɪᴅᴇʀ sᴇᴛ ᴛᴏ ᴏɴ")
                    else:
                        wait["Kicksider"] = True
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"❂➤ Aᴜᴛᴏᴋɪᴄᴋ sɪᴅᴇʀ sᴇᴛ ᴛᴏ ᴏɴ")
                        else:
                            cl.sendText(msg.to,"❂➤ Aᴜᴛᴏᴋɪᴄᴋ sɪᴅᴇʀ ᴀʟʀᴇᴀᴅʏ ᴏɴ")
                else:
                    cl.sendText(msg.to,"❂➤ Cᴏᴍᴍᴀɴᴅ Fᴏʀ Oᴡɴᴇʀ")
                            
            elif msg.text in ["Ksider off"]:
                if msg.from_ in Owner:
                    if wait["Kicksider"] == False:
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"❂➤ Aᴜᴛᴏᴋɪᴄᴋ sɪᴅᴇʀ ᴀʟʀᴇᴀᴅʏ ᴏғғ")
                        else:
                            cl.sendText(msg.to,"❂➤ Aᴜᴛᴏᴋɪᴄᴋ sɪᴅᴇʀ sᴇᴛ ᴛᴏ ᴏғғ")
                    else:
                        wait["Kicksider"] = False
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"❂➤ Aᴜᴛᴏᴋɪᴄᴋ sɪᴅᴇʀ sᴇᴛ ᴛᴏ ᴏғғ")
                        else:
                            cl.sendText(msg.to,"❂➤ Aᴜᴛᴏᴋɪᴄᴋ sɪᴅᴇʀ ᴀʟʀᴇᴀᴅʏ ᴏғғ")
                else:
                    cl.sendText(msg.to,"❂➤ Cᴏᴍᴍᴀɴᴅ Fᴏʀ Oᴡɴᴇʀ")
#-------------------------------------------------------------------------------
            elif msg.text in ["Simisimi on","Simisimi:on"]:
                if msg.from_ in Owner and admin and Bots:
                    settings["simiSimi"][msg.to] = True
                    cl.sendText(msg.to,"❂➤Success activated simisimi")
                
            elif msg.text in ["Simisimi off","Simisimi:off"]:
                if msg.from_ in Owner and admin and Bots:
                    settings["simiSimi"][msg.to] = False
                    cl.sendText(msg.to,"❂➤Success deactive simisimi")
#-------------------------------------------------------------------------------
            elif msg.text in ["Com bl"]:
                if msg.from_ in Owner and admin and Bots:
                    wait["wblack"] = True
                    cl.sendText(msg.to,"❂➤Please send contacts from the person you want to add to the blacklist")
                    
            elif msg.text in ["Com hapus bl"]:
                if msg.from_ in Owner and admin and Bots:
                    wait["dblack"] = True
                    cl.sendText(msg.to,"❂➤Please send contacts from the person you want to add from the blacklist")
                    
            elif msg.text in ["Com bl cek"]:
                if msg.from_ in Owner and admin and Bots:
                    if wait["commentBlack"] == {}:
                        cl.sendText(msg.to,"❂➤Nothing in the blacklist")
                    else:
                        cl.sendText(msg.to,"❂➤The following is a blacklist")
                        mc = ""
                        for mi_d in wait["commentBlack"]:
                            mc += "ãƒ»" +cl.getContact(mi_d).displayName + "\n"
                        cl.sendText(msg.to,mc)
                            
            elif msg.text in ["Com bl list"]:
                if msg.from_ in Owner and admin and Bots:
                    if wait["commentBlack"] == {}:
                        cl.sendText(msg.to,"❂➤Nothing in the blacklistô€œ🛡")
                    else:
                        cl.sendText(msg.to,"❂➤The following is a blacklistô€œ")
                        mc = ""
                        for mi_d in wait["commentBlack"]:
                            mc += "ãƒ»" +cl.getContact(mi_d).displayName + "\n"
                        cl.sendText(msg.to,mc)
#-------------------------------------------------------------------------------#
            elif "Mycopy @" in msg.text:
                if msg.from_ in Owner:
                   cl.sendText(msg.to, "❂➤ Copied.")
                   _name = msg.text.replace("Mycopy @","")
                   _nametarget = _name.rstrip('  ')
                   gs = cl.getGroup(msg.to)
                   targets = []
                   for g in gs.members:
                       if _nametarget == g.displayName:
                           targets.append(g.mid)
                   if targets == []:
                       cl.sendText(msg.to, "❂➤Not Found...")
                   else:
                       for target in targets:
                            try:
                               cl.CloneContactProfile(target)
                               cl.sendText(msg.to, "❂➤Contact Copied.")
                            except Exception as e:
                                print e
#-------------------------------------------------------------------------------
            elif msg.text in ["Mybackup","mybackup"]:
                if msg.from_ in Owner:
                    try:
                        cl.updateDisplayPicture(backup.pictureStatus)
                        cl.updateProfile(backup)
                        cl.sendText(msg.to, "❂➤Refreshed.")
                    except Exception as e:
                        cl.sendText(msg.to, str(e))

#======================================================================================#
#===============================[ JK SELF START ]================================#
#======================================================================================#

            elif cms(msg.text,["creator","Creator"]):
                msg.contentType = 13
                msg.contentMetadata = {'mid': "u57a54b914085fea6f04c19f6fe589057"}
                cl.sendText(msg.to,"╔═════ஜ۩۞۩ஜ═════╗\n╚═🎩^$€^™β¤t~🎩═╝")
                cl.sendMessage(msg)
                cl.sendText(msg.to,"╔═════ஜ۩۞۩ஜ═════╗\n╚═════ஜ۩۞۩ஜ═════╝")
#-------------------------------------------------------------------------------
            elif msg.text in ["About"]:
                today = datetime.today()
                future = datetime(2018,03,02)
                days = (str(future - today))
                comma = days.find(",")
                days = days[:comma]
                cl.sendText(msg.to,"🎩^$€^™β¤t~🎩 \n\n「Sᴜʙsᴄʀɪᴘᴛɪᴏɴ」\n ➣ sᴇʟғʙᴏᴛ ᴇᴅɪᴛɪᴏɴ \n\n「Exᴘɪʀᴇᴅ」 " + "\n ➣ Iɴ ᴅᴀʏs: " + days +  "\n\n「Cᴏɴᴛᴀᴄᴛ」\n➣ LINE me: http://line.me/ti/p/QvU09Wriyc")
                msg.contentType = 13
                msg.contentMetadata = {'mid': mid}
                cl.sendMessage(msg)
#-------------------------------------------------------------------------------
            elif msg.text.lower() == 'me':
                msg.contentType = 13
                msg.contentMetadata = {'mid': mid}
                cl.sendMessage(msg)
#-------------------------------------------------------------------------------
            elif msg.text.lower() == 'mymid':
                if msg.from_ in Owner and admin and Bots:
                    cl.sendText(msg.to,mid)
#-------------------------------------------------------------------------------
            elif msg.text in ["Myname"]:
                if msg.from_ in Owner and admin and Bots:
                    h = cl.getContact(mid)
                    cl.sendText(msg.to,"===[DisplayName]===\n" + h.displayName)
#-------------------------------------------------------------------------------
            elif "Myname:" in msg.text:
                if msg.from_ in Owner:
                    string = msg.text.replace("Myname:","")
                    if len(string.decode('utf-8')) <= 20:
                        profile = cl.getProfile()
                        profile.displayName = string
                        cl.updateProfile(profile)
                        cl.sendText(msg.to,"❂➤Update Names Menjadi : " + string + "")
#-------------------------------------------------------------------------------
            elif msg.text in ["Mybio"]:
                if msg.from_ in Owner and admin and Bots:
                    h = cl.getContact(mid)
                    cl.sendText(msg.to,"===[StatusMessage]===\n" + h.statusMessage)
#-------------------------------------------------------------------------------
            elif "Mybio:" in msg.text:
                if msg.from_ in Owner:
                    string = msg.text.replace("Mybio:","")
                    if len(string.decode('utf-8')) <= 500:
                        profile = cl.getProfile()
                        profile.statusMessage = string
                        cl.updateProfile(profile)
                        cl.sendText(msg.to,"❂➤Update Bio..." + string + "")
#-------------------------------------------------------------------------------
            elif msg.text in ["Mypict"]:
                if msg.from_ in Owner and admin and Bots:
                    h = cl.getContact(mid)
                    cl.sendImageWithURL(msg.to,"http://dl.profile.line-cdn.net/" + h.pictureStatus)
#-------------------------------------------------------------------------------
            elif msg.text in ["Mycover"]:
                if msg.from_ in Owner and admin and Bots:
                    h = cl.getContact(mid)
                    cu = cl.channel.getCover(mid)          
                    path = str(cu)
                    cl.sendImageWithURL(msg.to, path)
#-------------------------------------------------------------------------------
            elif msg.text in ["Myvid"]:
                if msg.from_ in Owner and admin and Bots:
                    h = cl.getContact(mid)
                    cl.sendVideoWithURL(msg.to,"http://dl.profile.line-cdn.net/" + h.pictureStatus)
#-------------------------------------------------------------------------------
            elif msg.text in ["Glist"]:
                if msg.from_ in Owner:
                    gid = cl.getGroupIdsJoined()
                    h = ""
                    for i in gid:
                        h += "%s\n" % (cl.getGroup(i).name +" ? ["+str(len(cl.getGroup(i).members))+"]")
                    cl.sendText(msg.to,"-- List Groups --\n\n"+ h +"\n❂➤Total groups =" +" ["+str(len(gid))+"]")
#-------------------------------------------------------------------------------
            elif msg.text in ["Gruplist"]:
                if msg.from_ in Owner:
                    gruplist = cl.getGroupIdsJoined()
                    kontak = cl.getGroups(gruplist)
                    num=1
                    msgs="══════List Grup══════"
                    for ids in kontak:
                        msgs+="\n[%i] %s" % (num, ids.name)
                        num=(num+1)
                    msgs+="\n══════List Grup══════\n\nTotal Grup : %i" % len(kontak)
                    cl.sendText(msg.to, msgs)
#-------------------------------------------------------------------------------
            elif msg.text in ["Gruplistmid"]:
                if msg.from_ in Owner:
                    gruplist = cl.getGroupIdsJoined()
                    kontak = cl.getGroups(gruplist)
                    num=1
                    msgs="══════List GrupMid══════"
                    for ids in kontak:
                        msgs+="\n[%i] %s" % (num, ids.id)
                        num=(num+1)
                    msgs+="\n══════List GrupMid══════\n\n❂➤Total Grup : %i" % len(kontak)
                    cl.sendText(msg.to, msgs)
#-------------------------------------------------------------------------------                   
            elif "Grupcancel: " in msg.text:
                if msg.from_ in Owner:
                    try:
                        strnum = msg.text.replace("Group cancel: ","")
                        if strnum == "off":
                            wait["autoCancel"]["on"] = False
                            if wait["lang"] == "JP":
                                cl.sendText(msg.to,"❂➤Itu off undangan ditolak...\nSilakan kirim dengan menentukan jumlah orang ketika Anda menghidupkan")
                            else:
                                cl.sendText(msg.to,"❂➤Off undangan ditolak...Sebutkan jumlah terbuka ketika Anda ingin mengirim")
                        else:
                            num =  int(strnum)
                            wait["autoCancel"]["on"] = True
                            if wait["lang"] == "JP":
                                cl.sendText(msg.to,strnum + "❂➤Kelompok berikut yang diundang akan ditolak secara otomatis")
                            else:
                                cl.sendText(msg.to,strnum + "❂➤The team declined to create the following automatic invitation")
                    except:
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"❂➤Nilai tidak benar")
                        else:
                            cl.sendText(msg.to,"❂➤Weird value🛡")
#-------------------------------------------------------------------------------
            elif msg.text.lower() == 'gcancel':
                if msg.from_ in Owner:
                    gid = cl.getGroupIdsInvited()
                    for i in gid:
                        cl.rejectGroupInvitation(i)
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"❂➤Aku menolak semua undangan")
                    else:
                        cl.sendText(msg.to,"❂➤He declined all invitations")
#-------------------------------------------------------------------------------
            elif msg.text in ["Urlpict"]:
                if msg.from_ in Owner and admin and Bots:
                    h = cl.getContact(mid)
                    cl.sendText(msg.to,"http://dl.profile.line-cdn.net/" + h.pictureStatus)
#-------------------------------------------------------------------------------
            elif msg.text in ["Urlcover"]:
                if msg.from_ in Owner and admin and Bots:
                    h = cl.getContact(mid)
                    cu = cl.channel.getCover(mid)          
                    path = str(cu)
                    cl.sendText(msg.to, path)
#-------------------------------------------------------------------------------
            elif msg.text in ["Blocklist"]:
                if msg.from_ in Owner:
                    blockedlist = cl.getBlockedContactIds()
                    kontak = cl.getContacts(blockedlist)
                    num=1
                    msgs="═════════List Blocked═════════"
                    for ids in kontak:
                        msgs+="\n[%i] %s" % (num, ids.displayName)
                        num=(num+1)
                    msgs+="\n═════════List Blocked═════════\n\n❂➤Total Blocked : %i" % len(kontak)
                    cl.sendText(msg.to, msgs)
#-------------------------------------------------------------------------------
            elif msg.text in ["Friendlist"]:
                if msg.from_ in Owner:
                    contactlist = cl.getAllContactIds()
                    kontak = cl.getContacts(contactlist)
                    num=1
                    msgs="══════List Friend══════"
                    for ids in kontak:
                        msgs+="\n[%i] %s" % (num, ids.displayName)
                        num=(num+1)
                    msgs+="\n══════List Friend══════\n\n❂➤Total Friend : %i" % len(kontak)
                    cl.sendText(msg.to, msgs)
#-------------------------------------------------------------------------------
            elif msg.text in ["Friendlistmid"]: 
                if msg.from_ in Owner:
                    gruplist = cl.getAllContactIds()
                    kontak = cl.getContacts(gruplist)
                    num=1
                    msgs="══════List FriendMid══════"
                    for ids in kontak:
                        msgs+="\n[%i] %s" % (num, ids.mid)
                        num=(num+1)
                    msgs+="\n══════List FriendMid══════\n\n❂➤Total Friend : %i" % len(kontak)
                    cl.sendText(msg.to, msgs)
#-------------------------------------------------------------------------------
            elif "Timeline: " in msg.text:
                if msg.from_ in Owner and admin and Bots:
                    tl_text = msg.text.replace("Timeline: ","")
                    cl.sendText(msg.to,"line://home/post?userMid="+mid+"&postId="+cl.new_post(tl_text)["result"]["post"]["postInfo"]["postId"])
                    
            elif "Tl:" in msg.text:
                if msg.from_ in Owner:
                    tl_text = msg.text.replace("TL:","")
                    cl.sendText(msg.to,"line://home/post?userMid="+mid+"&postId="+cl.new_post(tl_text)["result"]["post"]["postInfo"]["postId"])
#-------------------------------------------------------------------------------
            elif msg.text in ["Steal contact"]:
                if msg.from_ in Owner and admin and Bots:
                    wait["contact"] = True
                    cl.sendText(msg.to,"❂➤Send Contact")
#-------------------------------------------------------------------------------
            elif "Getmid @" in msg.text:
                if msg.from_ in Owner and admin and Bots:
                    _name = msg.text.replace("Getmid @","")
                    _nametarget = _name.rstrip(' ')
                    gs = cl.getGroup(msg.to)
                    for g in gs.members:
                        if _nametarget == g.displayName:
                            cl.sendText(msg.to, g.mid)
                        else:
                            pass
                                
            elif ("Cekmid " in msg.text):
                if msg.from_ in Owner and admin and Bots:
                   key = eval(msg.contentMetadata["MENTION"])
                   key1 = key["MENTIONEES"][0]["M"]
                   mi = cl.getContact(key1)
                   cl.sendText(msg.to,"Mid:" +  key1)
#-------------------------------------------------------------------------------
            elif "Getcontact" in msg.text:
                if msg.from_ in Owner and admin and Bots:
                    key = eval(msg.contentMetadata["MENTION"])
                    key1 = key["MENTIONEES"][0]["M"]                
                    mmid = cl.getContact(key1)
                    msg.contentType = 13
                    msg.contentMetadata = {"mid": key1}
                    cl.sendMessage(msg)
#-------------------------------------------------------------------------------
            elif "Getprofile" in msg.text:
                if msg.from_ in Owner and admin and Bots:
                    key = eval(msg.contentMetadata["MENTION"])
                    key1 = key["MENTIONEES"][0]["M"]
                    contact = cl.getContact(key1)
                    cu = cl.channel.getCover(key1)
                    path = str(cu)
                    image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                    try:
                        cl.sendText(msg.to,"Nama :\n" + contact.displayName + "\n\nBio :\n" + contact.statusMessage)
                        cl.sendText(msg.to,"Profile Picture " + contact.displayName)
                        cl.sendImageWithURL(msg.to,image)
                        cl.sendText(msg.to,"Cover " + contact.displayName)
                        cl.sendImageWithURL(msg.to,path)
                    except:
                        pass
#-------------------------------------------------------------------------------
            elif "Getinfo" in msg.text:
                if msg.from_ in Owner and admin and Bots:
                    key = eval(msg.contentMetadata["MENTION"])
                    key1 = key["MENTIONEES"][0]["M"]
                    contact = cl.getContact(key1)
                    cu = cl.channel.getCover(key1)
                    try:
                        cl.sendText(msg.to,"Nama :\n" + contact.displayName + "\n\nMid :\n" + contact.mid + "\n\nBio :\n" + contact.statusMessage + "\n\nProfile Picture :\nhttp://dl.profile.line-cdn.net/" + contact.pictureStatus + "\n\nHeader :\n" + str(cu))
                    except:
                        cl.sendText(msg.to,"Nama :\n" + contact.displayName + "\n\nMid :\n" + contact.mid + "\n\nBio :\n" + contact.statusMessage + "\n\nProfile Picture :\n" + str(cu))
#-------------------------------------------------------------------------------
            elif "Getname" in msg.text:
                if msg.from_ in Owner and admin and Bots:
                    key = eval(msg.contentMetadata["MENTION"])
                    key1 = key["MENTIONEES"][0]["M"]
                    contact = cl.getContact(key1)
                    cu = cl.channel.getCover(key1)
                    try:
                        cl.sendText(msg.to, "===[DisplayName]===\n" + contact.displayName)
                    except:
                        cl.sendText(msg.to, "===[DisplayName]===\n" + contact.displayName)
#-------------------------------------------------------------------------------
            elif "Getbio" in msg.text:
                if msg.from_ in Owner and admin and Bots:
                    key = eval(msg.contentMetadata["MENTION"])
                    key1 = key["MENTIONEES"][0]["M"]
                    contact = cl.getContact(key1)
                    cu = cl.channel.getCover(key1)
                    try:
                        cl.sendText(msg.to, "===[StatusMessage]===\n" + contact.statusMessage)
                    except:
                        cl.sendText(msg.to, "===[StatusMessage]===\n" + contact.statusMessage)
#-------------------------------------------------------------------------------
            elif "Getpict @" in msg.text:
                if msg.from_ in Owner and admin and Bots:
                    print "[Command]dp executing"
                    _name = msg.text.replace("Getpict @","")
                    _nametarget = _name.rstrip('  ')
                    gs = cl.getGroup(msg.to)
                    targets = []
                    for g in gs.members:
                        if _nametarget == g.displayName:
                            targets.append(g.mid)
                    if targets == []:
                        cl.sendText(msg.to,"❂➤Contact not found")
                    else:
                        for target in targets:
                            try:
                                contact = cl.getContact(target)
                                path = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                                cl.sendImageWithURL(msg.to, path)
                            except Exception as e:
                                raise e
                    print "[Command]dp executed"
#-------------------------------------------------------------------------------
            elif "Picturl @" in msg.text:
                if msg.from_ in Owner and admin and Bots:
                    print "[Command]dp executing"
                    _name = msg.text.replace("Picturl @","")
                    _nametarget = _name.rstrip('  ')
                    gs = cl.getGroup(msg.to)
                    targets = []
                    for g in gs.members:
                        if _nametarget == g.displayName:
                            targets.append(g.mid)
                    if targets == []:
                        cl.sendText(msg.to,"❂➤Contact not found")
                    else:
                        for target in targets:
                            try:
                                contact = cl.getContact(target)
                                path = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                                cl.sendText(msg.to, path)
                            except Exception as e:
                                raise e
                    print "[Command]dp executed"
#-------------------------------------------------------------------------------
            elif "Getvid @" in msg.text:
                if msg.from_ in Owner and admin and Bots:
                    print "[Command]dp executing"
                    _name = msg.text.replace("Getvid @","")
                    _nametarget = _name.rstrip('  ')
                    gs = cl.getGroup(msg.to)
                    targets = []
                    for g in gs.members:
                        if _nametarget == g.displayName:
                            targets.append(g.mid)
                    if targets == []:
                        cl.sendText(msg.to,"❂➤Contact not found")
                    else:
                        for target in targets:
                            try:
                                contact = cl.getContact(target)
                                path = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                                cl.sendVideoWithURL(msg.to, path)
                            except Exception as e:
                                raise e
                    print "[Command]dp executed"
#-------------------------------------------------------------------------------
            elif "Getcover @" in msg.text:
                if msg.from_ in Owner and admin and Bots:
                    print "[Command]cover executing"
                    _name = msg.text.replace("Getcover @","")    
                    _nametarget = _name.rstrip('  ')
                    gs = cl.getGroup(msg.to)
                    targets = []
                    for g in gs.members:
                        if _nametarget == g.displayName:
                            targets.append(g.mid)
                    if targets == []:
                        cl.sendText(msg.to,"❂➤Contact not found")
                    else:
                        for target in targets:
                            try:
                                contact = cl.getContact(target)
                                cu = cl.channel.getCover(target)          
                                path = str(cu)
                                cl.sendImageWithURL(msg.to, path)
                            except Exception as e:
                                raise e
                    print "[Command]cover executed"
#-------------------------------------------------------------------------------
            elif "Coverurl @" in msg.text:
                if msg.from_ in Owner and admin and Bots:
                    print "[Command]cover executing"
                    _name = msg.text.replace("Coverurl @","")    
                    _nametarget = _name.rstrip('  ')
                    gs = cl.getGroup(msg.to)
                    targets = []
                    for g in gs.members:
                        if _nametarget == g.displayName:
                            targets.append(g.mid)
                    if targets == []:
                        cl.sendText(msg.to,"❂➤Contact not found")
                    else:
                        for target in targets:
                            try:
                                contact = cl.getContact(target)
                                cu = cl.channel.getCover(target)          
                                path = str(cu)
                                cl.sendText(msg.to, path)
                            except Exception as e:
                                raise e
                    print "[Command]cover executed"
#-------------------------------------------------------------------------------
            elif "Checkmid: " in msg.text:
                if msg.from_ in Owner and admin and Bots:
                    saya = msg.text.replace("Checkmid: ","")
                    msg.contentType = 13
                    msg.contentMetadata = {"mid":saya}
                    cl.sendMessage(msg)
                    contact = cl.getContact(saya)
                    cu = cl.channel.getCover(saya)
                    path = str(cu)
                    image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                    try:
                        cl.sendText(msg.to,"Nama :\n" + contact.displayName + "\n\nBio :\n" + contact.statusMessage)
                        cl.sendText(msg.to,"Profile Picture " + contact.displayName)
                        cl.sendImageWithURL(msg.to,image)
                        cl.sendText(msg.to,"Cover " + contact.displayName)
                        cl.sendImageWithURL(msg.to,path)
                    except:
                        pass
#-------------------------------------------------------------------------------
            elif "removechat" in msg.text.lower():
                if msg.from_ in Owner:
                    try:
                        cl.removeAllMessages(op.param2)
                        print "[Command] Remove Chat"
                        cl.sendText(msg.to,"❂➤Done")
                    except Exception as error:
                        print error
                        cl.sendText(msg.to,"❂➤Error")

#======================================================================================#
#===============================[ JK GRUP START ]================================#
#======================================================================================# 

            elif msg.text.lower() == 'welcome':
                ginfo = cl.getGroup(msg.to)
                cl.sendText(msg.to,"█▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀█\n█░░╦─╦╔╗╦─╔╗╔╗╔╦╗╔╗░░█\n█░░║║║╠─║─║─║║║║║╠─░░█\n█░░╚╩╝╚╝╚╝╚╝╚╝╩─╩╚╝░░█\n█▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄█")
                cl.sendText(msg.to,"❂➤Selamat Datang Di Grup " + str(ginfo.name))
                jawaban1 = ("❂➤Selamat Datang Di Grup " + str(ginfo.name))
                cl.sendText(msg.to,"❂➤Owner Grup " + str(ginfo.name) + " :\n" + ginfo.creator.displayName )
                tts = gTTS(text=jawaban1, lang='id')
                tts.save('tts.mp3')
                cl.sendAudio(msg.to,'tts.mp3')
#-------------------------------------------------------------------------------
            elif msg.text.lower() == 'infogrup': 
                if msg.from_ in Owner and admin and Bots:
                    group = cl.getGroup(msg.to)
                    try:
                        gCreator = group.creator.displayName
                    except:
                        gCreator = "Error"
                    md = "[Nama Grup : ]\n" + group.name + "\n\n[Id Grup : ]\n" + group.id + "\n\n[Pembuat Grup :]\n" + gCreator + "\n\n[Gambar Grup : ]\nhttp://dl.profile.line-cdn.net/" + group.pictureStatus
                    if group.preventJoinByTicket is False: md += "\n\nKode Url : Diizinkan"
                    else: md += "\n\nKode Url : Diblokir"
                    if group.invitee is None: md += "\nJumlah Member : " + str(len(group.members)) + " Orang" + "\nUndangan Yang Belum Diterima : 0 Orang"
                    else: md += "\nJumlah Member : " + str(len(group.members)) + " Orang" + "\nUndangan Yang Belum Diterima : " + str(len(group.invitee)) + " Orang"
                    cl.sendText(msg.to,md)
                            
            elif msg.text.lower() == 'ginfo':
                if msg.from_ in Owner and admin and Bots:
                    ginfo = cl.getGroup(msg.to)
                    try:
                        gCreator = ginfo.creator.displayName
                    except:
                        gCreator = "Error"
                    if wait["lang"] == "JP":
                        if ginfo.invitee is None:
                            sinvitee = "0"
                        else:
                            sinvitee = str(len(ginfo.invitee))
                    msg.contentType = 13
                    msg.contentMetadata = {'mid': ginfo.creator.mid}
                    cl.sendText(msg.to,"[Nama]\n" + str(ginfo.name) + "\n[Group Id]\n" + msg.to + "\n\n[Group Creator]\n" + gCreator + "\n\nAnggota:" + str(len(ginfo.members)) + "\nInvitation:" + sinvitee + "")
                    cl.sendMessage(msg)
#-------------------------------------------------------------------------------
            elif msg.text.lower() == 'gcancel':
                if msg.from_ in Owner:
                    gid = cl.getGroupIdsInvited()
                    for i in gid:
                        cl.rejectGroupInvitation(i)
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"❂➤Aku menolak semua undangan")
                    else:
                        cl.sendText(msg.to,"❂➤He declined all invitations")
#-------------------------------------------------------------------------------
            elif "Grupname" in msg.text:
                if msg.from_ in Owner and admin and Bots:
                    saya = msg.text.replace('grupname','')
                    gid = cl.getGroup(msg.to)
                    cl.sendText(msg.to, "[Nama Grup : ]\n" + gid.name)
#-------------------------------------------------------------------------------
            elif "Getgrup image" in msg.text:
                if msg.from_ in Owner and admin and Bots:
                    group = cl.getGroup(msg.to)
                    path = "http://dl.profile.line-cdn.net/" + group.pictureStatus
                    cl.sendImageWithURL(msg.to,path)
#-------------------------------------------------------------------------------
            elif "Urlgrup image" in msg.text:
                if msg.from_ in Owner and admin and Bots:
                    group = cl.getGroup(msg.to)
                    path = "http://dl.profile.line-cdn.net/" + group.pictureStatus
                    cl.sendText(msg.to,path)
#-------------------------------------------------------------------------------
            elif "Gcreator" == msg.text:
                if msg.from_ in Owner and admin and Bots:
                    try:
                        group = cl.getGroup(msg.to)
                        GS = group.creator.mid
                        M = Message()
                        M.to = msg.to
                        M.contentType = 13
                        M.contentMetadata = {'mid': GS}
                        cl.sendMessage(M)
                    except:
                        W = group.members[0].mid
                        M = Message()
                        M.to = msg.to
                        M.contentType = 13
                        M.contentMetadata = {'mid': W}
                        cl.sendMessage(M)
                        cl.sendText(msg.to,"❂➤Creator Grup")
#-------------------------------------------------------------------------------
            elif msg.text.lower() == 'grup id':
                if msg.from_ in Owner and admin and Bots:
                    gid = cl.getGroupIdsJoined()
                    h = ""
                    for i in gid:
                        h += "[%s]:%s\n" % (cl.getGroup(i).name,i)
                    cl.sendText(msg.to,h)
                        
            elif "Grupid" in msg.text:
                if msg.from_ in Owner and admin and Bots:
                    saya = msg.text.replace('Grupid','')
                    gid = cl.getGroup(msg.to)
                    cl.sendText(msg.to, "[ID Grup : ]\n" + gid.id)
#-------------------------------------------------------------------------------
            elif msg.text in ["Memlist"]:
                if msg.from_ in Owner:
                    kontak = cl.getGroup(msg.to)
                    group = kontak.members
                    num=1
                    msgs="══════List Member═════���═══-"
                    for ids in group:
                        msgs+="\n[%i] %s" % (num, ids.displayName)
                        num=(num+1)
                    msgs+="\n══════List Member══════\n\nTotal Members : %i" % len(group)
                    cl.sendText(msg.to, msgs)
#-------------------------------------------------------------------------------
            elif "/tagall" == msg.text:
                group = cl.getGroup(msg.to)
                mem = [contact.mid for contact in group.members]
                for mm in mem:
                    xname = cl.getContact(mm).displayName
                    xlen = str(len(xname)+1)
                    msg.contentType = 0
                    msg.text = "@"+xname+" "
                    msg.contentMetadata = {'MENTION':'{"MENTIONEES":[{"S":"0","E":'+json.dumps(xlen)+',"M":'+json.dumps(mm)+'}]}','EMTVER':'4'}
                    try:
                        cl.sendMessage(msg)
                    except Exception as e:
                        print str(e)
                
            elif msg.text in ["Tagall","Tag all"]:
                if msg.from_ in Owner and admin and Bots:
                    group = cl.getGroup(msg.to)
                    nama = [contact.mid for contact in group.members]
                    cb = ""
                    cb2 = ""
                    strt = int(0)
                    akh = int(0)
                    for md in nama:
                        akh = akh + int(6)
                        cb += """{"S":"""+json.dumps(str(strt))+""","E":"""+json.dumps(str(akh))+""","M":"""+json.dumps(md)+"},"""
                        strt = strt + int(7)
                        akh = akh + 1
                        cb2 += "@nrik \n"
                    cb = (cb[:int(len(cb)-1)])
                    msg.contentType = 0
                    msg.text = cb2
                    msg.contentMetadata ={'MENTION':'{"MENTIONEES":['+cb+']}','EMTVER':'4'}
                    try:
                        cl.sendMessage(msg)
                    except Exception as error:
                        print error
                        
            elif msg.text in ["Ciluk baa","Mention"]:
              if msg.from_ in Owner and admin and Bots:
                 group = cl.getGroup(msg.to)
                 nama = [contact.mid for contact in group.members]
                 nm1, nm2, nm3, nm4, nm5, jml = [], [], [], [], [], len(nama)
                 if jml <= 100:
                    summon(msg.to, nama)
                 if jml > 100 and jml < 200:
                    for i in range(0, 99):
                        nm1 += [nama[i]]
                    summon(msg.to, nm1)
                    for j in range(100, len(nama)-1):
                        nm2 += [nama[j]]
                    summon(msg.to, nm2)
                 if jml > 200  and jml < 500:
                    for i in range(0, 99):
                        nm1 += [nama[i]]
                    summon(msg.to, nm1)
                    for j in range(100, 199):
                        nm2 += [nama[j]]
                    summon(msg.to, nm2)
                    for k in range(200, 299):
                        nm3 += [nama[k]]
                    summon(msg.to, nm3)
                    for l in range(300, 399):
                        nm4 += [nama[l]]
                    summon(msg.to, nm4)
                    for m in range(400, len(nama)-1):
                        nm5 += [nama[m]]
                    summon(msg.to, nm5)
                 if jml > 500:
                     print "Terlalu Banyak Men 500+"
                 cnt = Message()
                 cnt.text = "『Mᴇɴᴛɪᴏɴᴇs』 : \n" + str(jml) +  " Mᴇᴍʙᴇʀs"
                 cnt.to = msg.to
                 cl.sendMessage(cnt)
#-------------------------------------------------------------------------------
            elif "lurk on" == msg.text.lower():
                if msg.to in wait2['readPoint']:
                        try:
                            del wait2['readPoint'][msg.to]
                            del wait2['readMember'][msg.to]
                            del wait2['setTime'][msg.to]
                        except:
                            pass
                        wait2['readPoint'][msg.to] = msg.id
                        wait2['readMember'][msg.to] = ""
                        wait2['setTime'][msg.to] = datetime.now().strftime('%H:%M:%S')
                        wait2['ROM'][msg.to] = {}
                        with open('sider.json', 'w') as fp:
                         json.dump(wait2, fp, sort_keys=True, indent=4)
                         cl.sendText(msg.to,"❂➤Lurking already on")
                else:
                    try:
                            del wait2['readPoint'][msg.to]
                            del wait2['readMember'][msg.to]
                            del wait2['setTime'][msg.to]
                    except:
                          pass
                    wait2['readPoint'][msg.to] = msg.id
                    wait2['readMember'][msg.to] = ""
                    wait2['setTime'][msg.to] = datetime.now().strftime('%H:%M:%S')
                    wait2['ROM'][msg.to] = {}
                    with open('sider.json', 'w') as fp:
                     json.dump(wait2, fp, sort_keys=True, indent=4)
                     cl.sendText(msg.to, "Set reading point:\n" + datetime.now().strftime('%H:%M:%S'))
                     print wait2
                                    
            elif "lurk off" == msg.text.lower():
                if msg.to not in wait2['readPoint']:
                    cl.sendText(msg.to,"❂➤Lurking already off")
                else:
                    try:
                            del wait2['readPoint'][msg.to]
                            del wait2['readMember'][msg.to]
                            del wait2['setTime'][msg.to]
                    except:
                          pass
                    cl.sendText(msg.to, "Delete reading point:\n" + datetime.now().strftime('%H:%M:%S'))
                    
            elif "lurkers" == msg.text.lower():
                    if msg.to in wait2['readPoint']:
                        if wait2["ROM"][msg.to].items() == []:
                             cl.sendText(msg.to, "❂➤Lurkers:\n❂➤None")
                        else:
                            chiya = []
                            for rom in wait2["ROM"][msg.to].items():
                                chiya.append(rom[1])
                               
                            cmem = cl.getContacts(chiya)
                            zx = ""
                            zxc = ""
                            zx2 = []
                            xpesan = 'Lurkers:\n'
                        for x in range(len(cmem)):
                                xname = str(cmem[x].displayName)
                                pesan = ''
                                pesan2 = pesan+"@a\n"
                                xlen = str(len(zxc)+len(xpesan))
                                xlen2 = str(len(zxc)+len(pesan2)+len(xpesan)-1)
                                zx = {'S':xlen, 'E':xlen2, 'M':cmem[x].mid}
                                zx2.append(zx)
                                zxc += pesan2
                                msg.contentType = 0
                                        
                        print zxc
                        msg.text = xpesan+ zxc + "\nLurking time: %s\nCurrent time: %s"%(wait2['setTime'][msg.to],datetime.now().strftime('%H:%M:%S'))
                        lol ={'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}
                        print lol
                        msg.contentMetadata = lol
                        try:
                          cl.sendMessage(msg)
                        except Exception as error:
                              print error
                        pass
                                
                    else:
                        cl.sendText(msg.to, "❂➤Lurking has not been set.")
                        
            elif "bakekok" == msg.text.lower():
                    if msg.to in wait2['readPoint']:
                        if wait2["ROM"][msg.to].items() == []:
                             cl.sendText(msg.to, "Lurkers:\nNone")
                        else:
                            chiya = []
                            for rom in wait2["ROM"][msg.to].items():
                                chiya.append(rom[1])
                               
                            cmem = cl.getContacts(chiya)
                            zx = ""
                            zxc = ""
                            zx2 = []
                            xpesan = 'Lurkers:\n'
                        for x in range(len(cmem)):
                                xname = str(cmem[x].displayName)
                                pesan = ''
                                pesan2 = pesan+"@a\n"
                                xlen = str(len(zxc)+len(xpesan))
                                xlen2 = str(len(zxc)+len(pesan2)+len(xpesan)-1)
                                zx = {'S':xlen, 'E':xlen2, 'M':cmem[x].mid}
                                zx2.append(zx)
                                zxc += pesan2
                                msg.contentType = 0
                                        
                        print zxc
                        msg.text = xpesan+ zxc + "\nLurking time: %s\nCurrent time: %s"%(wait2['setTime'][msg.to],datetime.now().strftime('%H:%M:%S'))
                        lol ={'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}
                        print lol
                        msg.contentMetadata = lol
                        try:
                          cl.sendMessage(msg)
                        except Exception as error:
                              print error
                        pass
                                
                    else:
                        cl.sendText(msg.to, "❂➤Lurking has not been set.")
#-------------------------------------------------------------------------------
            elif msg.text == "Cek":
                    cl.sendText(msg.to, "Mengecek Sider")
                    try:
                      del wait2['readPoint'][msg.to]
                      del wait2['readMember'][msg.to]
                    except:
							          pass
                    now2 = datetime.now()
                    wait2['readPoint'][msg.to] = msg.id
                    wait2['readMember'][msg.to] = ""
                    wait2['setTime'][msg.to] = datetime.strftime(now2,"%H:%M")
                    wait2['ROM'][msg.to] = {}
                    print wait2
                            
            elif msg.text == "set":
                    sendMessage(msg.to, "I have set a read point ♪\n「tes」I will show you who I have read ♪")
                    try:
                        del wait['readPoint'][msg.to]
                        del wait['readMember'][msg.to]
                    except:
                        pass
                    wait['readPoint'][msg.to] = msg.id
                    wait['readMember'][msg.to] = ""
                    wait['setTime'][msg.to] = datetime.datetime.today().strftime('%Y-%m-%d %H:%M:%S')
                    wait['ROM'][msg.to] = {}
                    print wait
                    
            elif msg.text == "Baak":
						        if msg.to in wait2['readPoint']:
							          if wait2["ROM"][msg.to].items() == []:
								            chiya = ""
							          else:
								            chiya = ""
								            for rom in wait2["ROM"][msg.to].items():
									              print rom
									              chiya += rom[1] + "\n"

							          cl.sendText(msg.to, "Semua Yang Membaca%s\nHanya Itu\n\nYang Mengabaikan\n%sHayoo Ngapain Diabaikan\n\nWaktu Pengecekan:\n[%s]"  % (wait2['readMember'][msg.to],chiya,setTime[msg.to]))
						        else:
							          cl.sendText(msg.to, "Cek Untuk Melihat Sider")
#-------------------------------------------------------------------------------
            elif "Add all" in msg.text:
                if msg.from_ in Owner:
                    thisgroup = cl.getGroups([msg.to])
                    Mids = [contact.mid for contact in thisgroup[0].members]
                    mi_d = Mids[:33]
                    cl.findAndAddContactsByMids(mi_d)
                    cl.sendText(msg.to,"❂➤Success Add all")
#--------------------------------MASIH EROR-------------------------------------
            elif "Add @" in msg.text:
                if msg.toType == 2:
                        print "[Command]Add executing"
                        _name = msg.text.replace("add @","")
                        _nametarget = _name.rstrip('  ')
                        gs = cl.getGroup(msg.to)
                        targets = []
                        for g in gs.members:
                            if _nametarget == g.displayName:
                                targets.append(g.mid)
                        if targets == []:
                            cl.sendText(msg.to,"Contact not found")
                        else:
                            for target in targets:
                                try:
                                    cl.findAndAddContactsByMid(target)
                                except:
                                    cl.sendText(msg.to,"Error")
                else:
                    cl.sendText(msg.to,"❂➤Perintah Ditolak.")                
                    cl.sendText(msg.to,"❂➤Hanya Owner Yang bisa Gunain Perintah ini.")
#-------------------------------------------------------------------------------
            elif ("Gname: " in msg.text):
                if msg.from_ in Owner and admin and Bots:
                    if msg.toType == 2:
                        X = cl.getGroup(msg.to)
                        X.name = msg.text.replace("Gname: ","")
                        cl.updateGroup(X)
                        
            elif 'gn: ' in msg.text.lower():
                if msg.from_ in Owner and admin and Bots:
                    if msg.toType == 2:
                        aditya = cl.getGroup(msg.to)
                        aditya.name = msg.text.replace("Gn: ","")
                        cl.updateGroup(aditya)
#-------------------------------------------------------------------------------
            elif "Grupimage: " in msg.text:
                if msg.from_ in Owner and admin and Bots:
                    saya = msg.text.replace('Grupimage: ','')
                    gid = cl.getGroupIdsJoined()
                    for i in gid:
                        h = cl.getGroup(i).name
                        gna = cl.getGroup(i)
                        if h == saya:
                            cl.sendImageWithURL(msg.to,"http://dl.profile.line.naver.jp/"+ gna.pictureStatus)
#-------------------------------------------------------------------------------
            elif "Gbroadcast: " in msg.text:
                if msg.from_ in Owner and admin and Bots:
                    bc = msg.text.replace("Gbroadcast: ","")
                    gid = cl.getGroupIdsJoined()
                    for i in gid:
                        cl.sendText(i, bc)
#-------------------------------------------------------------------------------
            elif "Cbroadcast: " in msg.text:
                if msg.from_ in Owner and admin and Bots:
                    bc = msg.text.replace("Cbroadcast: ","")
                    gid = cl.getAllContactIds()
                    for i in gid:
                        cl.sendText(i, bc)

            elif "Say " in msg.text:
                if msg.from_ in Owner and admin and Bots:
				    bctxt = msg.text.replace("Say ","")
				    cl.sendText(msg.to,(bctxt))
#-------------------------------------------------------------------------------
            elif "Say " in msg.text:
                if msg.from_ in Owner and admin and Bots:
				    bctxt = msg.text.replace("Say ","")
				    cl.sendText(msg.to,(bctxt))
#-------------------------------------------------------------------------------
            elif msg.text.lower() == 'invite:gcreator':
                if msg.toType == 2:
                       ginfo = cl.getGroup(msg.to)
                       try:
                           gcmid = ginfo.creator.mid
                       except:
                           gcmid = "Error"
                       if wait["lang"] == "JP":
                           cl.inviteIntoGroup(msg.to,[gcmid])
                       else:
                           cl.inviteIntoGroup(msg.to,[gcmid])
#-------------------------------------------------------------------------------
            elif msg.text.lower() == 'invite:creatbot':
                if msg.from_ in Owner and admin and Bots:
                    if msg.toType == 2:
                        ginfo = cl.getGroup(msg.to)
                        cl.inviteIntoGroup(msg.to,["u57a54b914085fea6f04c19f6fe589057"])
                        
#=================================[ JK SB SAR }===========================
            elif msg.text.lower() == 'sein1':
                if msg.from_ in Owner and admin and Bots:
                    if msg.toType == 2:
                        ginfo = cl.getGroup(msg.to)
                        cl.inviteIntoGroup(msg.to,["u934df9122b0900900b2c0dac4142dcf7"])
                        
            elif msg.text.lower() == 'ifain':
                if msg.from_ in Owner and admin and Bots:
                    if msg.toType == 2:
                        ginfo = cl.getGroup(msg.to)
                        cl.inviteIntoGroup(msg.to,["u2d3750943da1835063cfc561a5f78ca3"])
                            
            elif msg.text.lower() == 'jkin':
                if msg.from_ in Owner and admin and Bots:
                    if msg.toType == 2:
                        ginfo = cl.getGroup(msg.to)
                        cl.inviteIntoGroup(msg.to,["uf8748b9c71a583fe632191e0b3923afd"])
                            
            elif msg.text.lower() == 'sein':
                if msg.from_ in Owner and admin and Bots:
                    if msg.toType == 2:
                        ginfo = cl.getGroup(msg.to)
                        cl.inviteIntoGroup(msg.to,["uc112eb6a24d68763885b6811a3a0f920"])
                        
            elif msg.text.lower() == 'acin':
                if msg.from_ in Owner and admin and Bots:
                    if msg.toType == 2:
                        ginfo = cl.getGroup(msg.to)
                        cl.inviteIntoGroup(msg.to,["uc912cd778450c7de21ff430b16b151f5"])
                        
            elif msg.text.lower() == 'qin':
                if msg.from_ in Owner and admin and Bots:
                    if msg.toType == 2:
                        ginfo = cl.getGroup(msg.to)
                        cl.inviteIntoGroup(msg.to,["u22301e804bc7e9e3f6ac0065ac378f01"])
#===============================================================================
            elif msg.text.lower() == 'cancel':
                if msg.from_ in Owner and admin and Bots:
                    if msg.toType == 2:
                        group = cl.getGroup(msg.to)
                        if group.invitee is not None:
                            gInviMids = [contact.mid for contact in group.invitee]
                            cl.cancelGroupInvitation(msg.to, gInviMids)
                        else:
                            if wait["lang"] == "JP":
                                cl.sendText(msg.to,"❂➤Tidak ada undangan")
                            else:
                                cl.sendText(msg.to,"❂➤Invitan tidak ada")
                    else:
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"❂➤Tidak ada undangan")
                        else:
                            cl.sendText(msg.to,"❂➤Invitan tidak ada")
#--------------------------------------------------------------------------------
            elif msg.text.lower() == 'ourl':
                if msg.from_ in Owner and admin and Bots:
                    if msg.toType == 2:
                        group = cl.getGroup(msg.to)
                        group.preventJoinByTicket = False
                        cl.updateGroup(group)
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"❂➤URL open")
                        else:
                            cl.sendText(msg.to,"❂➤URL open")
                    else:
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"❂➤It can not be used outside the group")
                        else:
                            cl.sendText(msg.to,"❂➤Can not be used for groups other than")
#--------------------------------------------------------------------------------
            elif msg.text.lower() == 'curl':
                if msg.from_ in Owner and admin and Bots:
                    if msg.toType == 2:
                        group = cl.getGroup(msg.to)
                        group.preventJoinByTicket = True
                        cl.updateGroup(group)
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"❂➤URL close")
                        else:
                            cl.sendText(msg.to,"❂➤URL close")
                    else:
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"It can not be used outside the group")
                        else:
                            cl.sendText(msg.to,"Can not be used for groups other than")
#-------------------------------------------------------------------------------
            elif msg.text in ["Gurl"]:
                if msg.from_ in Owner and admin and Bots:
                    if msg.toType == 2:
                        g = cl.getGroup(msg.to)
                        if g.preventJoinByTicket == True:
                            g.preventJoinByTicket = False
                            cl.updateGroup(g)
                        gurl = cl.reissueGroupTicket(msg.to)
                        cl.sendText(msg.to,"line://ti/g/" + gurl)
#----------------------------------------------------------------------------------------
            elif msg.text.lower() == 'url':
                if msg.from_ in Owner and admin and Bots:
                    if msg.toType == 2:
                        g = cl.getGroup(msg.to)
                        if g.preventJoinByTicket == True:
                            g.preventJoinByTicket = False
                            cl.updateGroup(g)
                        gurl = cl.reissueGroupTicket(msg.to)
                        cl.sendText(msg.to,"line://ti/g/" + gurl)
                    else:
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"❂➤Hal ini tidak dapat digunakan di luar kelompok")
                        else:
                            cl.sendText(msg.to,"❂➤Tidak dapat digunakan untuk kelompok selain")
#-------------------------------------------------------------------------------
            elif "Spam" in msg.text:
                if msg.from_ in Owner and admin and Bots:
                    txt = msg.text.split(" ")
                    jmlh = int(txt[2])
                    teks = msg.text.replace("Spam "+str(txt[1])+" "+str(jmlh)+" ","")
                    tulisan = jmlh * (teks+"\n")
                    if txt[1] == "on":
                        if jmlh <= 100000:
                            for x in range(jmlh):
                                cl.sendText(msg.to, teks)
                        else:
                            cl.sendText(msg.to, "Out of Range!")
                    elif txt[1] == "off":
                        if jmlh <= 100000:
                            cl.sendText(msg.to, tulisan)
                        else:
                            cl.sendText(msg.to, "Out Of Range!")
                            
#-------------------------------------------------------------------------------
            elif "Spam: " in msg.text:
                if msg.from_ in Owner and admin and Bots:
                    strnum = msg.text.replace("Spam: ","")
                    num = int(strnum)
                    for var in range(0,num):
                        cl.sendText(msg.to, wait["spam"])
                        
            elif "Spam add: " in msg.text:
                if msg.from_ in Owner and admin and Bots:
                    wait["spam"] = msg.text.replace("Spam add: ","")
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"spam changed")
                    else:
                        cl.sendText(msg.to,"❂➤Done")
                        
            elif "Spam change: " in msg.text:
                if msg.from_ in Owner and admin and Bots:
                    wait["spam"] = msg.text.replace("Spam change: ","")
                    cl.sendText(msg.to,"spam changed")
                        
            elif "Spamtag @" in msg.text:
                if msg.from_ in Owner and admin and Bots:
                    _name = msg.text.replace("Spamtag @","")
                    _nametarget = _name.rstrip(' ')
                    gs = cl.getGroup(msg.to)
                    for g in gs.members:
                        if _nametarget == g.displayName:
                            xname = g.displayName
                            xlen = str(len(xname)+1)
                            msg.contentType = 0
                            msg.text = "@"+xname+" "
                            msg.contentMetadata ={'MENTION':'{"MENTIONEES":[{"S":"0","E":'+json.dumps(xlen)+',"M":'+json.dumps(g.mid)+'}]}','EMTVER':'4'}
                            cl.sendMessage(msg)
                            cl.sendMessage(msg)
                            cl.sendMessage(msg)
                            cl.sendMessage(msg)
                            cl.sendMessage(msg)
                            cl.sendMessage(msg)
                            cl.sendMessage(msg)
                            cl.sendMessage(msg)
                            cl.sendMessage(msg)
                            cl.sendMessage(msg)
                            cl.sendMessage(msg)
                            cl.sendMessage(msg)
                            cl.sendMessage(msg)
                            cl.sendMessage(msg)
                            cl.sendMessage(msg)
                            cl.sendMessage(msg)
                            cl.sendMessage(msg)
                            cl.sendMessage(msg)
                            cl.sendMessage(msg)
                            cl.sendMessage(msg)
                        else:
                            pass
                            
            elif "Spam album:" in msg.text:
                if msg.from_ in Owner and admin and Bots:
                    try:
                        albumtags = msg.text.replace("Spam album:","")
                        gid = albumtags[:33]
                        name = albumtags.replace(albumtags[:34],"")
                        cl.createAlbum(gid,name)
                        cl.sendText(msg.to,"We created an album" + name)
                    except:
                        cl.sendText(msg.to,"❂➤Error")
#-------------------------------------------------------------------------------
            elif ("Gift" in msg.text):
                if msg.from_ in Owner and admin and Bots:
                   targets = []
                   key = eval(msg.contentMetadata["MENTION"])
                   key["MENTIONEES"][0]["M"]
                   for x in key["MENTIONEES"]:
                       targets.append(x["M"])
                   for target in targets:
                       try:
                	   msg.contentType = 9
                           msg.contentMetadata={'PRDID': '89131c1a-e549-4bd5-9e60-e24de0d2e252',
                                    'PRDTYPE': 'THEME',
                                    'MSGTPL': '10'}
                           msg.text = None
                           cl.sendMessage(msg)
                           cl.sendMessage(msg,target)
                       except:
                           cl.sendText(msg.to,"❂➤Gift send to member")
#----------------------------------------------------------------------------------------
            elif "Album:" in msg.text:
                if msg.from_ in Owner and admin and Bots:
                    gid = msg.text.replace("Album:","")
                    album = cl.getAlbum(gid)
                    if album["result"]["items"] == []:
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"❂➤Tidak ada album")
                        else:
                            cl.sendText(msg.to,"Dalam album tidak")
                    else:
                        if wait["lang"] == "JP":
                            mg = "Berikut ini adalah album dari target"
                        else:
                            mg = "Berikut ini adalah subjek dari album"
                        for y in album["result"]["items"]:
                            if "photoCount" in y:
                                mg += str(y["title"]) + ":" + str(y["photoCount"]) + "\n"
                            else:
                                mg += str(y["title"]) + ":0 Pieces\n"
                        cl.sendText(msg.to,mg)
#----------------------------------------------------------------------------------------
            elif "Hapus:" in msg.text:
                if msg.from_ in Owner and admin and Bots:
                    gid = msg.text.replace("Hapus:","")
                    albums = cl.getAlbum(gid)["result"]["items"]
                    i = 0
                    if albums != []:
                        for album in albums:
                            cl.deleteAlbum(gid,album["gid"])
                            cl.sendText(msg.to,str(i) + "Soal album telah dihapus")
                            i += 1
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,str(i) + "Soal album telah dihapus")
                    else:
                        cl.sendText(msg.to,str(i) + "Hapus kesulitan album")
#-------------------------------------------------------------------------------
            elif msg.text.lower() == 'bye':
                if msg.from_ in Owner and Bots:
                    if wait["leaveRoom"] == True:
                        if msg.toType == 2:
                            ginfo = cl.getGroup(msg.to)
                            try:
                                cl.sendText(msg.to,"❂➤Bye Bye "  +  str(ginfo.name)  + "")
                                cl.leaveGroup(msg.to)
                            except:
                                pass
                    else:
                        cl.sendText(msg.to,"❂➤ Pʟᴇᴀsᴇ Tᴜʀɴ Oɴ Tʜᴇ Aᴜᴛᴏʟᴇᴀᴠᴇ")
                        
            elif msg.text.lower() == 'byeall':
                if msg.from_ in Owner and Bots:
                    if wait["leaveRoom"] == True:
                        gid = cl.getGroupIdsJoined()
                        for i in gid:
                            cl.leaveGroup(i)
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"❂➤ JK Bᴏᴛs Hᴀs ʙᴇᴇɴ Oᴜᴛ Fʀᴏᴍ Gʀᴏᴜᴘs")
                        else:
                            cl.sendText(msg.to,"❂➤ Hᴇ ᴅᴇᴄʟɪɴᴇᴅ ᴀʟʟ ɪɴᴠɪᴛᴀᴛɪᴏɴs")
                    else:
                        cl.sendText(msg.to,"❂➤ Pʟᴇᴀsᴇ Tᴜʀɴ Oɴ Tʜᴇ Aᴜᴛᴏʟᴇᴀᴠᴇ")

#======================================================================================#
#===============================[ JK KICK START ]================================#
#======================================================================================# 
            elif ("Bunuh " in msg.text):
                if msg.from_ in Owner and admin and Bots:
                   targets = []
                   key = eval(msg.contentMetadata["MENTION"])
                   key["MENTIONEES"][0]["M"]
                   for x in key["MENTIONEES"]:
                       targets.append(x["M"])
                   for target in targets:
                       try:
                           cl.kickoutFromGroup(msg.to,[target])
                       except:
                           cl.sendText(msg.to,"Error")
#-------------------------------------------------------------------------------
            elif "Cln" in msg.text:
                if msg.from_ in Owner:
                    if msg.toType == 2:
                        print "[Command]Cleanse executing"
                        _name = msg.text.replace("Cln","Cleanse")
                        gs = cl.getGroup(msg.to)
                        cl.sendText(msg.to,"Group cleansing begin")
                        cl.sendText(msg.to,"Goodbye :)")
                        targets = []
                        for g in gs.members:
                            if _name in g.displayName:
                                targets.append(g.mid)
                        if targets == []:
                            cl.sendText(msg.to,"Not found.")
                        else:
                            for target in targets:
                                try:
                                    cl.kickoutFromGroup(msg.to,[target])
                                    print (msg.to,[g.mid])
                                except:
                                    cl.sendText(msg.to,"")
#-------------------------------------------------------------------------------
            elif "Nk" in msg.text:
                if msg.from_ in Owner and admin and Bots:
                       nk0 = msg.text.replace("Nk","")
                       nk1 = nk0.lstrip()
                       nk2 = nk1.replace("@","")
                       nk3 = nk2.rstrip()
                       _name = nk3
                       gs = cl.getGroup(msg.to)
                       ginfo = cl.getGroup(msg.to)
                       gs.preventJoinByTicket = False
                       cl.updateGroup(gs)
                       invsend = 0
                       Ticket = cl.reissueGroupTicket(msg.to)
                       cl.acceptGroupInvitationByTicket(msg.to,Ticket)
                       time.sleep(0.01)
                       targets = []
                       for s in gs.members:
                           if _name in s.displayName:
                              targets.append(s.mid)
                       if targets == []:
                           sendMessage(msg.to,"user does not exist")
                           pass
                       else:
                           for target in targets:
                                try:
                                    cl.kickoutFromGroup(msg.to,[target])
                                    print (msg.to,[g.mid])
                                except:
                                    cl.leaveGroup(msg.to)
                                    gs = cl.getGroup(msg.to)
                                    gs.preventJoinByTicket = True
                                    cl.updateGroup(gs)
                                    gs.preventJoinByTicket(gs)
                                    cl.updateGroup(gs)
#-------------------------------------------------------------------------------
            elif "Relaxing" in msg.text:
              if msg.from_ in Owner:
                if msg.toType == 2:
                    print "ok"
                    _name = msg.text.replace("Relaxing","")
                    gs = cl.getGroup(msg.to)
                    cl.sendText(msg.to,"Bye All")
                    cl.sendText(msg.to,"Sory guys")
                    targets = []
                    for g in gs.members:
                        if _name in g.displayName:
                            targets.append(g.mid)
                    if targets == []:
                        cl.sendText(msg.to,"Not Found")
                    else:
                        for target in targets:
                            if not target in Bots:
                                if not target in Owner:
                                    if not target in admin:
                                        try:
                                            cl.kickoutFromGroup(msg.to,[target])
                                            print (msg.to,[g.mid])
                                        except:
                                            cl.sendText(msg.to,"")
#======================================================================================#
            elif "Kick:" in msg.text:
                if msg.from_ in Owner and admin and Bots:
                    midd = msg.text.replace("Kick:","")
                    cl.kickoutFromGroup(msg.to,[midd])
#--------------------------------------------------------------------------------
            elif 'invite ' in msg.text.lower():
                if msg.from_ in Owner and Bots:
                    key = msg.text[-33:]
                    cl.findAndAddContactsByMid(key)
                    cl.inviteIntoGroup(msg.to, [key])
                    contact = cl.getContact(key)
                    
            elif msg.text in ["Invite"]:
                if msg.from_ in Owner and Bots:
                    wait['invite'] = True
                    cl.sendText(msg.to,"❂➤Send Contact")
#--------------------------------------------------------------------------------
            elif ("Kick " in msg.text):
                if msg.from_ in Owner and admin and Bots:
                   targets = []
                   key = eval(msg.contentMetadata["MENTION"])
                   key["MENTIONEES"] [0] ["M"]
                   for x in key["MENTIONEES"]:
                       targets.append(x["M"])
                   for target in targets:
                       try:
                           cl.kickoutFromGroup(msg.to,[target])
                       except:
                           cl.sendText(msg.to,"❂➤Error")
#--------------------------------------------------------------------------------
            elif ("Ulti " in msg.text):
                if msg.from_ in Owner and admin and Bots:
                   targets = []
                   key = eval(msg.contentMetadata["MENTION"])
                   key["MENTIONEES"] [0] ["M"]
                   for x in key["MENTIONEES"]:
                       targets.append(x["M"])
                   for target in targets:
                       try:
                           cl.kickoutFromGroup(msg.to,[target])
                           cl.inviteIntoGroup(msg.to,[target])
                           cl.cancelGroupInvitation(msg.to,[target])
                       except:
                           cl.sendText(msg.to,"❂➤Error")
                    
#===============================[ JK BAN START ]=================================#

            elif "Ban @" in msg.text:
                if msg.from_ in Owner:
                    if msg.toType == 2:
                        _name = msg.text.replace("Ban @","")
                        _nametarget = _name.rstrip()
                        gs = cl.getGroup(msg.to)
                        targets = []
                        for g in gs.members:
                            if _nametarget == g.displayName:
                                targets.append(g.mid)
                        if targets == []:
                            cl.sendText(msg.to,_nametarget + "❂➤ Not Found")
                        else:
                            for target in targets:
                                try:
                                    wait["blacklist"][target] = True
                                    cl.sendText(msg.to,_nametarget + "❂➤ Succes Add to Blacklist")
                                except:
                                    cl.sendText(msg.to,"Error")
                                    
            elif "Unban @" in msg.text:
                if msg.from_ in Owner:
                    if msg.toType == 2:
                        _name = msg.text.replace("Unban @","")
                        _nametarget = _name.rstrip()
                        gs = cl.getGroup(msg.to)
                        targets = []
                        for g in gs.members:
                            if _nametarget == g.displayName:
                                targets.append(g.mid)
                        if targets == []:
                            cl.sendText(msg.to,_nametarget + "❂➤ Not Found")
                        else:
                            for target in targets:
                                try:
                                    del wait["blacklist"][target]
                                    cl.sendText(msg.to,_nametarget + " Delete From Blacklist")
                                except:
                                    cl.sendText(msg.to,_nametarget + "❂➤ Not In Blacklist")
#-------------------------------------------------------------------------------
            elif "Mban:" in msg.text:
                if msg.from_ in Owner and admin and Bots:
                    midd = msg.text.replace("Mban:","")
                    wait["blacklist"][midd] = True
                    cl.sendText(msg.to,"❂➤Target Lock")
#-------------------------------------------------------------------------------
            elif msg.text in ["Ban"]:
                if msg.from_ in Owner and admin and Bots:
                    wait["wblacklist"] = True
                    cl.sendText(msg.to,"❂➤Send Contact")
#-------------------------------------------------------------------------------
            elif msg.text in ["Unban"]:
                if msg.from_ in Owner and admin and Bots:
                    wait["dblacklist"] = True
                    cl.sendText(msg.to,"❂➤Send Contact")
#-------------------------------------------------------------------------------
            elif "Cipok ah" in msg.text: 
                if msg.from_ in Owner and admin and Bots:
                       nk0 = msg.text.replace("Cipok ah","")
                       nk1 = nk0.lstrip()
                       nk2 = nk1.replace("","")
                       nk3 = nk2.rstrip()
                       _name = nk3
                       gs = cl.getGroup(msg.to)
                       targets = []
                       for s in gs.members:
                           if _name in s.displayName:
                              targets.append(s.mid)
                       if targets == []:
                           sendMessage(msg.to,"user does not exist")
                           pass
                       else:
                           for target in targets:
                                try:
									wait["blacklist"][target] = True
									f=codecs.open('st2__b.json','w','utf-8')
									json.dump(wait["blacklist"], f, sort_keys=True, indent=4,ensure_ascii=False)
#									cl.sendText(msg.to,_name + "")
                                except:
                                    cl.sendText(msg.to,"Error")
                                
            elif "Poles ah" in msg.text:
                if msg.from_ in Owner and admin and Bots:
                       nk0 = msg.text.replace("Poles ah","")
                       nk1 = nk0.lstrip()
                       nk2 = nk1.replace("","")
                       nk3 = nk2.rstrip()
                       _name = nk3
                       gs = cl.getGroup(msg.to)
                       targets = []
                       for s in gs.members:
                           if _name in s.displayName:
                              targets.append(s.mid)
                       if targets == []:
                           sendMessage(msg.to,"user does not exist")
                           pass
                       else:
                           for target in targets:
                                try:
									del wait["blacklist"][target]
									f=codecs.open('st2__b.json','w','utf-8')
									json.dump(wait["blacklist"], f, sort_keys=True, indent=4,ensure_ascii=False)
#									cl.sendText(msg.to,_name + "")
                                except:
                                    cl.sendText(msg.to,_name + " Not In Blacklist")
#-------------------------------------------------------------------------------
            elif msg.text in ["Banlist"]:
                if msg.from_ in Owner and admin and Bots:
                    if wait["blacklist"] == {}:
                        cl.sendText(msg.to,"❂➤Tɪᴅᴀᴋ Aᴅᴀ Bʟᴀᴄᴋʟɪᴤᴛ")
                    else:
                        cl.sendText(msg.to,"❂➤Daftar Banlist")
                        num=1
                        msgs="═══════List Blacklist══════"
                        for mi_d in wait["blacklist"]:
                            msgs+="\n[%i] %s" % (num, cl.getContact(mi_d).displayName)
                            num=(num+1)
                        msgs+="\n═══════List Blacklist══════\n\nTotal Blacklist : %i" % len(wait["blacklist"])
                        cl.sendText(msg.to, msgs)

            elif msg.text.lower() == 'mcheck':
                if msg.from_ in Owner and admin and Bots:
                    if wait["blacklist"] == {}:
                        cl.sendText(msg.to,"❂➤ Nothing in the blacklist")
                    else:
                        cl.sendText(msg.to,"❂➤ following is a blacklist")
                        mc = ""
                        for mi_d in wait["blacklist"]:
                            mc += ">" +cl.getContact(mi_d).displayName + "\n"
                        cl.sendText(msg.to,mc)
#-------------------------------------------------------------------------------
            elif msg.text in ["Clearban"]:
                if msg.from_ in Owner and admin and Bots:
                    wait["blacklist"] = {}
                    cl.sendText(msg.to,"❂➤Blacklist Telah Dibersihkan")
#--------------------------------------------------------------------------#
            elif msg.text.lower() == 'ulek':
                if msg.from_ in Owner and admin and Bots:
                    if msg.toType == 2:
                        group = cl.getGroup(msg.to)
                        gMembMids = [contact.mid for contact in group.members]
                        matched_list = []
                        for tag in wait["blacklist"]:
                            matched_list+=filter(lambda str: str == tag, gMembMids)
                        if matched_list == []:
                            cl.sendText(msg.to,"❂➤Daftar hitam pengguna tidak memiliki")
                            return
                        for jj in matched_list:
                            try:
                                cl.kickoutFromGroup(msg.to,[jj])
                                print (msg.to,[jj])
                            except:
                                pass

#======================================================================================#
#===============================[ JK MEDIA START ]===============================#
#======================================================================================# 

            elif "Tr-id " in msg.text:
                isi = msg.text.replace("Tr-id ","")
                translator = Translator()
                hasil = translator.translate(isi, dest='id')
                A = hasil.text
                A = A.encode('utf-8')
                cl.sendText(msg.to, A)
            elif "Tr-en " in msg.text:
                isi = msg.text.replace("Tr-en ","")
                translator = Translator()
                hasil = translator.translate(isi, dest='en')
                A = hasil.text
                A = A.encode('utf-8')
                cl.sendText(msg.to, A)
            elif "Tr-ar" in msg.text:
                isi = msg.text.replace("Tr-ar ","")
                translator = Translator()
                hasil = translator.translate(isi, dest='ar')
                A = hasil.text
                A = A.encode('utf-8')
                cl.sendText(msg.to, A)
            elif "Tr-jp" in msg.text:
                isi = msg.text.replace("Tr-jp ","")
                translator = Translator()
                hasil = translator.translate(isi, dest='ja')
                A = hasil.text
                A = A.encode('utf-8')
                cl.sendText(msg.to, A)
            elif "Tr-ko" in msg.text:
                isi = msg.text.replace("Tr-ko ","")
                translator = Translator()
                hasil = translator.translate(isi, dest='ko')
                A = hasil.text
                A = A.encode('utf-8')
                cl.sendText(msg.to, A)
            elif "Tr-th" in msg.text:
                isi = msg.text.replace("Tr-th ","")
                translator = Translator()
                hasil = translator.translate(isi, dest='th')
                A = hasil.text
                A = A.encode('utf-8')
                cl.sendText(msg.to, A)
            elif "Tr-jw" in msg.text:
                isi = msg.text.replace("Tr-jw ","")
                translator = Translator()
                hasil = translator.translate(isi, dest='jw')
                A = hasil.text
                A = A.encode('utf-8')
                cl.sendText(msg.to, A)
#-------------------------------------------------------------------------------
            elif "Id@en" in msg.text:
                bahasa_awal = 'id'
                bahasa_tujuan = 'en'
                kata = msg.text.replace("Id@en ","")
                url = 'https://translate.google.com/m?sl=%s&tl=%s&ie=UTF-8&prev=_m&q=%s' % (bahasa_awal, bahasa_tujuan, kata.replace(" ", "+"))
                agent = {'User-Agent':'Mozilla/5.0'}
                cari_hasil = 'class="t0">'
                request = urllib2.Request(url, headers=agent)
                page = urllib2.urlopen(request).read()
                result = page[page.find(cari_hasil)+len(cari_hasil):]
                result = result.split("<")[0]
                cl.sendText(msg.to,"----FROM ID----\n" + "" + kata + "\n----TO ENGLISH----\n" + "" + result + "\n------SUKSES-----")
            elif "En@id" in msg.text:
                bahasa_awal = 'en'
                bahasa_tujuan = 'id'
                kata = msg.text.replace("En@id ","")
                url = 'https://translate.google.com/m?sl=%s&tl=%s&ie=UTF-8&prev=_m&q=%s' % (bahasa_awal, bahasa_tujuan, kata.replace(" ", "+"))
                agent = {'User-Agent':'Mozilla/5.0'}
                cari_hasil = 'class="t0">'
                request = urllib2.Request(url, headers=agent)
                page = urllib2.urlopen(request).read()
                result = page[page.find(cari_hasil)+len(cari_hasil):]
                result = result.split("<")[0]
                cl.sendText(msg.to,"----FROM EN----\n" + "" + kata + "\n----TO ID----\n" + "" + result + "\n------SUKSES-----")
            elif "Id@jp" in msg.text:
                bahasa_awal = 'id'
                bahasa_tujuan = 'ja'
                kata = msg.text.replace("Id@jp ","")
                url = 'https://translate.google.com/m?sl=%s&tl=%s&ie=UTF-8&prev=_m&q=%s' % (bahasa_awal, bahasa_tujuan, kata.replace(" ", "+"))
                agent = {'User-Agent':'Mozilla/5.0'}
                cari_hasil = 'class="t0">'
                request = urllib2.Request(url, headers=agent)
                page = urllib2.urlopen(request).read()
                result = page[page.find(cari_hasil)+len(cari_hasil):]
                result = result.split("<")[0]
                cl.sendText(msg.to,"----FROM ID----\n" + "" + kata + "\n----TO JP----\n" + "" + result + "\n------SUKSES-----")
            elif "Jp@id" in msg.text:
                bahasa_awal = 'ja'
                bahasa_tujuan = 'id'
                kata = msg.text.replace("Jp@id ","")
                url = 'https://translate.google.com/m?sl=%s&tl=%s&ie=UTF-8&prev=_m&q=%s' % (bahasa_awal, bahasa_tujuan, kata.replace(" ", "+"))
                agent = {'User-Agent':'Mozilla/5.0'}
                cari_hasil = 'class="t0">'
                request = urllib2.Request(url, headers=agent)
                page = urllib2.urlopen(request).read()
                result = page[page.find(cari_hasil)+len(cari_hasil):]
                result = result.split("<")[0]
                cl.sendText(msg.to,"----FROM JP----\n" + "" + kata + "\n----TO ID----\n" + "" + result + "\n------SUKSES-----")
            elif "Id@th" in msg.text:
                bahasa_awal = 'id'
                bahasa_tujuan = 'th'
                kata = msg.text.replace("Id@th ","")
                url = 'https://translate.google.com/m?sl=%s&tl=%s&ie=UTF-8&prev=_m&q=%s' % (bahasa_awal, bahasa_tujuan, kata.replace(" ", "+"))
                agent = {'User-Agent':'Mozilla/5.0'}
                cari_hasil = 'class="t0">'
                request = urllib2.Request(url, headers=agent)
                page = urllib2.urlopen(request).read()
                result = page[page.find(cari_hasil)+len(cari_hasil):]
                result = result.split("<")[0]
                cl.sendText(msg.to,"----FROM ID----\n" + "" + kata + "\n----TO TH----\n" + "" + result + "\n------SUKSES-----")
            elif "Th@id" in msg.text:
                bahasa_awal = 'th'
                bahasa_tujuan = 'id'
                kata = msg.text.replace("Th@id ","")
                url = 'https://translate.google.com/m?sl=%s&tl=%s&ie=UTF-8&prev=_m&q=%s' % (bahasa_awal, bahasa_tujuan, kata.replace(" ", "+"))
                agent = {'User-Agent':'Mozilla/5.0'}
                cari_hasil = 'class="t0">'
                request = urllib2.Request(url, headers=agent)
                page = urllib2.urlopen(request).read()
                result = page[page.find(cari_hasil)+len(cari_hasil):]
                result = result.split("<")[0]
                cl.sendText(msg.to,"----FROM TH----\n" + "" + kata + "\n----TO ID----\n" + "" + result + "\n------SUKSES-----")
            elif "Id@jp" in msg.text:
                bahasa_awal = 'id'
                bahasa_tujuan = 'ja'
                kata = msg.text.replace("Id@jp ","")
                url = 'https://translate.google.com/m?sl=%s&tl=%s&ie=UTF-8&prev=_m&q=%s' % (bahasa_awal, bahasa_tujuan, kata.replace(" ", "+"))
                agent = {'User-Agent':'Mozilla/5.0'}
                cari_hasil = 'class="t0">'
                request = urllib2.Request(url, headers=agent)
                page = urllib2.urlopen(request).read()
                result = page[page.find(cari_hasil)+len(cari_hasil):]
                result = result.split("<")[0]
                cl.sendText(msg.to,"----FROM ID----\n" + "" + kata + "\n----TO JP----\n" + "" + result + "\n------SUKSES-----")
            elif "Id@ar" in msg.text:
                bahasa_awal = 'id'
                bahasa_tujuan = 'ar'
                kata = msg.text.replace("Id@ar ","")
                url = 'https://translate.google.com/m?sl=%s&tl=%s&ie=UTF-8&prev=_m&q=%s' % (bahasa_awal, bahasa_tujuan, kata.replace(" ", "+"))
                agent = {'User-Agent':'Mozilla/5.0'}
                cari_hasil = 'class="t0">'
                request = urllib2.Request(url, headers=agent)
                page = urllib2.urlopen(request).read()
                result = page[page.find(cari_hasil)+len(cari_hasil):]
                result = result.split("<")[0]
                cl.sendText(msg.to,"----FROM ID----\n" + "" + kata + "\n----TO AR----\n" + "" + result + "\n------SUKSES-----")
            elif "Ar@id" in msg.text:
                bahasa_awal = 'ar'
                bahasa_tujuan = 'id'
                kata = msg.text.replace("Ar@id ","")
                url = 'https://translate.google.com/m?sl=%s&tl=%s&ie=UTF-8&prev=_m&q=%s' % (bahasa_awal, bahasa_tujuan, kata.replace(" ", "+"))
                agent = {'User-Agent':'Mozilla/5.0'}
                cari_hasil = 'class="t0">'
                request = urllib2.Request(url, headers=agent)
                page = urllib2.urlopen(request).read()
                result = page[page.find(cari_hasil)+len(cari_hasil):]
                result = result.split("<")[0]
                cl.sendText(msg.to,"----FROM AR----\n" + "" + kata + "\n----TO ID----\n" + "" + result + "\n------SUKSES-----")
            elif "Id@ko" in msg.text:
                bahasa_awal = 'id'
                bahasa_tujuan = 'ko'
                kata = msg.text.replace("Id@ko ","")
                url = 'https://translate.google.com/m?sl=%s&tl=%s&ie=UTF-8&prev=_m&q=%s' % (bahasa_awal, bahasa_tujuan, kata.replace(" ", "+"))
                agent = {'User-Agent':'Mozilla/5.0'}
                cari_hasil = 'class="t0">'
                request = urllib2.Request(url, headers=agent)
                page = urllib2.urlopen(request).read()
                result = page[page.find(cari_hasil)+len(cari_hasil):]
                result = result.split("<")[0]
                cl.sendText(msg.to,"----FROM ID----\n" + "" + kata + "\n----TO KO----\n" + "" + result + "\n------SUKSES-----")
            elif "Ko@id" in msg.text:
                bahasa_awal = 'ko'
                bahasa_tujuan = 'id'
                kata = msg.text.replace("Ko@id ","")
                url = 'https://translate.google.com/m?sl=%s&tl=%s&ie=UTF-8&prev=_m&q=%s' % (bahasa_awal, bahasa_tujuan, kata.replace(" ", "+"))
                agent = {'User-Agent':'Mozilla/5.0'}
                cari_hasil = 'class="t0">'
                request = urllib2.Request(url, headers=agent)
                page = urllib2.urlopen(request).read()
                result = page[page.find(cari_hasil)+len(cari_hasil):]
                result = result.split("<")[0]
                cl.sendText(msg.to,"----FROM KO----\n" + "" + kata + "\n----TO ID----\n" + "" + result + "\n------SUKSES-----")
            elif "Id@jw" in msg.text:
                bahasa_awal = 'id'
                bahasa_tujuan = 'jw'
                kata = msg.text.replace("Id@jw ","")
                url = 'https://translate.google.com/m?sl=%s&tl=%s&ie=UTF-8&prev=_m&q=%s' % (bahasa_awal, bahasa_tujuan, kata.replace(" ", "+"))
                agent = {'User-Agent':'Mozilla/5.0'}
                cari_hasil = 'class="t0">'
                request = urllib2.Request(url, headers=agent)
                page = urllib2.urlopen(request).read()
                result = page[page.find(cari_hasil)+len(cari_hasil):]
                result = result.split("<")[0]
                cl.sendText(msg.to,"----FROM ID----\n" + "" + kata + "\n----TO JW----\n" + "" + result + "\n------SUKSES-----")
            elif "Jw@id" in msg.text:
                bahasa_awal = 'jw'
                bahasa_tujuan = 'id'
                kata = msg.text.replace("jw@id ","")
                url = 'https://translate.google.com/m?sl=%s&tl=%s&ie=UTF-8&prev=_m&q=%s' % (bahasa_awal, bahasa_tujuan, kata.replace(" ", "+"))
                agent = {'User-Agent':'Mozilla/5.0'}
                cari_hasil = 'class="t0">'
                request = urllib2.Request(url, headers=agent)
                page = urllib2.urlopen(request).read()
                result = page[page.find(cari_hasil)+len(cari_hasil):]
                result = result.split("<")[0]
                cl.sendText(msg.to,"----FROM JW----\n" + "" + kata + "\n----TO ID----\n" + "" + result + "\n------SUKSES-----")
#-------------------------------------------------------------------------------
            elif "Say-id " in msg.text:
                say = msg.text.replace("Say-id ","")
                lang = 'id'
                tts = gTTS(text=say, lang=lang)
                tts.save("hasil.mp3")
                cl.sendAudio(msg.to,"❂➤hasil.mp3")
                
            elif "Say-en " in msg.text:
                say = msg.text.replace("Say-en ","")
                lang = 'en'
                tts = gTTS(text=say, lang=lang)
                tts.save("hasil.mp3")
                cl.sendAudio(msg.to,"❂➤hasil.mp3")
                
            elif "Say-jp " in msg.text:
                say = msg.text.replace("Say-jp ","")
                lang = 'ja'
                tts = gTTS(text=say, lang=lang)
                tts.save("hasil.mp3")
                cl.sendAudio(msg.to,"❂➤hasil.mp3")
                
            elif "Say-ar " in msg.text:
                say = msg.text.replace("Say-ar ","")
                lang = 'ar'
                tts = gTTS(text=say, lang=lang)
                tts.save("hasil.mp3")
                cl.sendAudio(msg.to,"❂➤hasil.mp3")
                
            elif "Say-ko " in msg.text:
                say = msg.text.replace("Say-ko ","")
                lang = 'ko'
                tts = gTTS(text=say, lang=lang)
                tts.save("hasil.mp3")
                cl.sendAudio(msg.to,"❂➤hasil.mp3")
                
            elif "Say-th " in msg.text:
                say = msg.text.replace("Say-th ","")
                lang = 'th'
                tts = gTTS(text=say, lang=lang)
                tts.save("hasil.mp3")
                cl.sendAudio(msg.to,"❂➤hasil.mp3")
#-------------------------------------------------------------------------------
            elif "nyunda " in msg.text.lower():
                    query = msg.text.replace("Nyunda ","")
                    with requests.session() as s:
                        s.headers['user-agent'] = 'Mozilla/5.0'
                        url = 'https://google-translate-proxy.herokuapp.com/api/tts'
                        params = {'language': 'su', 'speed': '1', 'query': query}
                        r = s.get(url, params=params)
                        mp3 = r.url
                        cl.sendAudioWithURL(msg.to, mp3)
#-------------------------------------------------------------------------------
            elif "Fb" in msg.text:
                    a = msg.text.replace("Fb","")
                    b = urllib.quote(a)
                    cl.sendText(msg.to,"「 Searching 」\n" "Type:Search Info\nStatus: Processing")
                    cl.sendText(msg.to, "https://www.facebook.com" + b)
                    cl.sendText(msg.to,"「 Searching 」\n" "Type:Search Info\nStatus: Success")
#-------------------------------------------------------------------------------
            elif "Profileig " in msg.text:
                    try:
                        instagram = msg.text.replace("Profileig ","")
                        response = requests.get("https://www.instagram.com/"+instagram+"?__a=1")
                        data = response.json()
                        namaIG = str(data['user']['full_name'])
                        bioIG = str(data['user']['biography'])
                        mediaIG = str(data['user']['media']['count'])
                        verifIG = str(data['user']['is_verified'])
                        usernameIG = str(data['user']['username'])
                        followerIG = str(data['user']['followed_by']['count'])
                        profileIG = data['user']['profile_pic_url_hd']
                        privateIG = str(data['user']['is_private'])
                        followIG = str(data['user']['follows']['count'])
                        link = "Link: " + "https://www.instagram.com/" + instagram
                        text = "Name : "+namaIG+"\nUsername : "+usernameIG+"\nBiography : "+bioIG+"\nFollower : "+followerIG+"\nFollowing : "+followIG+"\nPost : "+mediaIG+"\nVerified : "+verifIG+"\nPrivate : "+privateIG+"" "\n" + link
                        cl.sendImageWithURL(msg.to, profileIG)
                        cl.sendText(msg.to, str(text))
                    except Exception as e:
                        cl.sendText(msg.to, str(e))
#-------------------------------------------------------------------------------
            elif "Checkdate " in msg.text:
                tanggal = msg.text.replace("Checkdate ","")
                r=requests.get('https://script.google.com/macros/exec?service=AKfycbw7gKzP-WYV2F5mc9RaR7yE3Ve1yN91Tjs91hp_jHSE02dSv9w&nama=ervan&tanggal='+tanggal)
                data=r.text
                data=json.loads(data)
                lahir = data["data"]["lahir"]
                usia = data["data"]["usia"]
                ultah = data["data"]["ultah"]
                zodiak = data["data"]["zodiak"]
                cl.sendText(msg.to,"============ I N F O R M A S I ============\n"+"Date Of Birth : "+lahir+"\nAge : "+usia+"\nUltah : "+ultah+"\nZodiak : "+zodiak+"\n============ I N F O R M A S I ============")
#-------------------------------------------------------------------------------
            elif msg.text in ["Kalender","Time","Waktu"]:
                timeNow = datetime.now()
                timeHours = datetime.strftime(timeNow,"(%H:%M)")
                day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
                hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"]
                bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
                inihari = datetime.today()
                hr = inihari.strftime('%A')
                bln = inihari.strftime('%m')
                for i in range(len(day)):
                    if hr == day[i]: hasil = hari[i]
                for k in range(0, len(bulan)):
                    if bln == str(k): blan = bulan[k-1]
                rst = hasil + ", " + inihari.strftime('%d') + " - " + blan + " - " + inihari.strftime('%Y') + "\nJam : [ " + inihari.strftime('%H:%M:%S') + " ]"
                cl.sendText(msg.to, rst)
#-------------------------------------------------------------------------------
            elif "Fancytext: " in msg.text:
                txt = msg.text.replace("Fancytext: ", "")
                cl.kedapkedip(msg.to,txt)
                print "[Command] Kedapkedip"
#-------------------------------------------------------------------------------
            elif "Image " in msg.text:
                search = msg.text.replace("Image ","")
                url = 'https://www.google.com/search?espv=2&biw=1366&bih=667&tbm=isch&oq=kuc&aqs=mobile-gws-lite.0.0l5&q=' + search
                raw_html = (download_page(url))
                items = []
                items = items + (_images_get_all_items(raw_html))
                path = random.choice(items)
                print path
                try:
                    cl.sendImageWithURL(msg.to,path)
                except:
                    pass      
#-------------------------------------------------------------------------------
            elif "Music " in msg.text:
                try:
                    songname = msg.text.lower().replace("Music ","")
                    params = {'songname': songname}
                    r = requests.get('http://ide.fdlrcn.com/workspace/yumi-apis/joox?' + urllib.urlencode(params))
                    data = r.text
                    data = json.loads(data)
                    for song in data:
                        hasil = 'This is Your Music\n'
                        hasil += 'Judul : ' + song[0]
                        hasil += '\nDurasi : ' + song[1]
                        hasil += '\nLink Download : ' + song[4]
                        cl.sendText(msg.to, hasil)
                        cl.sendText(msg.to, "Please Wait for audio...")
                        cl.sendAudioWithURL(msg.to, song[4])
                except Exception as njer:
                        cl.sendText(msg.to, str(njer))
                            
            elif "musik " in msg.text:
					songname = msg.text.replace("/musik ","")
					params = {"songname": songname}
					r = requests.get('http://ide.fdlrcn.com/workspace/yumi-apis/joox?' + urllib.urlencode(params))
					data = r.text
					data = json.loads(data)
					for song in data:
						abc = song[3].replace('https://','http://')
						cl.sendText(msg.to, "Title : " + song[0] + "\nLength : " + song[1] + "\nLink download : " + song[4])
						cl.sendText(msg.to, "Lagu " + song[0] + "\nSedang Di Prosses... Tunggu Sebentar 😊 ")
						cl.sendAudioWithURL(msg.to,abc)
						cl.sendText(msg.to, "Selamat Mendengarkan Lagu " + song[0])
#-------------------------------------------------------------------------------
            elif "Lirik " in msg.text:
                try:
                    songname = msg.text.lower().replace("Lirik ","")
                    params = {'songname': songname}
                    r = requests.get('http://ide.fdlrcn.com/workspace/yumi-apis/joox?' + urllib.urlencode(params))
                    data = r.text
                    data = json.loads(data)
                    for song in data:
                        hasil = 'Lyric Lagu ('
                        hasil += song[0]
                        hasil += ')\n\n'
                        hasil += song[5]
                        cl.sendText(msg.to, hasil)
                except Exception as wak:
                        cl.sendText(msg.to, str(wak))
#-------------------------------------------------------------------------------
            elif "playstore " in msg.text.lower():
                tob = msg.text.lower().replace("playstore ","")
                cl.sendText(msg.to,"Sedang Mencari...")
                cl.sendText(msg.to,"Title : "+tob+"\nSource : Google Play\nLink : https://play.google.com/store/search?q=" + tob)
                cl.sendText(msg.to,"Tuh Linknya Kak (^_^)")
#-------------------------------------------------------------------------------
            elif "Wikipedia " in msg.text:
                  try:
                      wiki = msg.text.lower().replace("Wikipedia ","")
                      wikipedia.set_lang("id")
                      pesan="Title ("
                      pesan+=wikipedia.page(wiki).title
                      pesan+=")\n\n"
                      pesan+=wikipedia.summary(wiki, sentences=1)
                      pesan+="\n"
                      pesan+=wikipedia.page(wiki).url
                      cl.sendText(msg.to, pesan)
                  except:
                          try:
                              pesan="Over Text Limit! Please Click link\n"
                              pesan+=wikipedia.page(wiki).url
                              cl.sendText(msg.to, pesan)
                          except Exception as e:
                              cl.sendText(msg.to, str(e))
#-------------------------------------------------------------------------------
            elif "Yt-search " in msg.text:
                    query = msg.text.replace("Yt-search ","")
                    with requests.session() as s:
                        s.headers['user-agent'] = 'Mozilla/5.0'
                        url = 'http://www.youtube.com/results'
                        params = {'search_query': query}
                        r = s.get(url, params=params)
                        soup = BeautifulSoup(r.content, 'html.parser')
                        hasil = ""
                        for a in soup.select('.yt-lockup-title > a[title]'):
                            if '&list=' not in a['href']:
                                hasil += ''.join((a['title'],'\nUrl : http://www.youtube.com' + a['href'],'\n\n'))
                        cl.sendText(msg.to,hasil)
                        print '[Command] Youtube Search'
#-------------------------------------------------------------------------------
            elif 'Yt-mp4 ' in msg.text:
                    try:
                        textToSearch = (msg.text).replace('Youtubemp4 ', "").strip()
                        query = urllib.quote(textToSearch)
                        url = "https://www.youtube.com/results?search_query=" + query
                        response = urllib2.urlopen(url)
                        html = response.read()
                        soup = BeautifulSoup(html, "html.parser")
                        results = soup.find(attrs={'class': 'yt-uix-tile-link'})
                        ght = ('https://www.youtube.com' + results['href'])
                        cl.sendVideoWithURL(msg.to, ght)
                    except:
                        cl.sendText(msg.to, "Could not find it")
                            
            elif "yt-get " in msg.text:
                        qx = msg.text.replace("yt-get ","")
                        vid = pafy.new(qx)
                        stream = vid.streams
                        for s in stream:
                            vin = vid.title + "\n\nLink Download" + s.url
                        cl.sendText(msg.to,text)
#-------------------------------------------------------------------------------
            elif "Apakah " in msg.text:
                  tanya = msg.text.replace("Apakah ","")
                  jawab = ("Ya","Tidak","Mungkin","Bisa jadi")
                  jawaban = random.choice(jawab)
                  tts = gTTS(text=jawaban, lang='id')
                  tts.save('tts.mp3')
                  cl.sendAudio(msg.to,'tts.mp3')
#-------------------------------------------------------------------------------
            elif "Kapan " in msg.text:
                  tanya = msg.text.replace("Kapan ","")
                  jawab = ("kapan kapan","besok","satu abad lagi","Hari ini","Tahun depan","Minggu depan","Bulan depan","Sebentar lagi")
                  jawaban = random.choice(jawab)
                  tts = gTTS(text=jawaban, lang='id')
                  tts.save('tts.mp3')
                  cl.sendAudio(msg.to,'tts.mp3')
#-------------------------------------------------------------------------------
            elif "Setimage: " in msg.text:
                if msg.from_ in Owner and admin and Bots:
                    wait["pap"] = msg.text.replace("Setimage: ","")
                    cl.sendText(msg.to, "Pap telah di Set")
                    
            elif msg.text in ["Papimage","Papim","Pap"]:
                if msg.from_ in Owner and admin and Bots:
                    cl.sendImageWithURL(msg.to,wait["pap"])
#-------------------------------------------------------------------------------
            elif "Setvideo: " in msg.text:
                if msg.from_ in Owner and admin and Bots:
                    wait["pap"] = msg.text.replace("Setvideo: ","")
                    cl.sendText(msg.to,"Video Has Ben Set To")
                    
            elif msg.text in ["Papvideo","Papvid"]:
                if msg.from_ in Owner and admin and Bots:
                    cl.sendVideoWithURL(msg.to,wait["pap"])
#-------------------------------------------------------------------------------#
#---------------------------[ JK Other Start ]----------------------------#
#-------------------------------------------------------------------------------#  
            elif msg.text in ["Simbol1"]:
#       if msg.from_ in admin:
                cl.sendText(msg.to,"↪ ↩ ← ↑ → ↓ ↔ ↕ ↖ ↗ ↘ ↙ ↚ ↛ ↜ ↝ ↞ ↟ ↠ ↡ ��� ↣ ↤ ↦ ↥ ↧ ↨ ↫ ↬ ↭ ↮ ↯ ↰ ↱ ↲ ↴ ↳ ↵ ↶ ↷ ↸ ↹ ↺ ↻ ⟲ ⟳ ↼ ↽ ↾ ↿ ⇀ ⇁ ⇂ ⇃ ⇄ ⇅ ⇆ ⇇ ⇈ ⇉ ⇊ ⇋ ⇌ ⇍ ⇏ ⇎ ⇑ ⇓ ⇐ ⇒ ⇔ ⇕ ⇖ ⇗ ⇘ ⇙ ⇳ ⇚ ⇛ ⇜ ⇝ ⇞ ⇟ ⇠ ⇡ ⇢ ⇣ ⇤ ⇥ ⇦ ⇨ ⇩ ⇪ ⇧ ⇫ ⇬ ⇭ ⇮ ⇯ ⇰ ⇱ ⇲ ⇴ ⇵ ⇶ ⇷ ⇸ ⇹ ⇺ ⇻ ⇼ ⇽ ⇾ ⇿ ⟰ ⟱ ⟴ ⟵ ⟶ ⟷ ⟸ ⟹ ⟽ ⟾ ⟺ ⟻ ⟼ ⟿ ⤴ ⤵ ➔ ➘ ➙ ➚ ➛ ➜ ➝ ➞ ➟ ➠ ➡ ➢ ➣ ➤ ➥ ➦ ➧ ➨ ➩ ➪ ➫ ➬ ➭ ➮ ➯ ➱ ➲ ➳ ➴ ➵ ➶ ➷ ➸ ➹ ➺ ➻ ➼ ➽ ➾⬅ ⏎ ▲ ▼ ◀ ▶☇ ☈ ⍃ ⍄ ⍇ ⍈ ⍐ ⍗ ⍌ ⍓ ⍍ ⍔ ⍏ ⍖ ⍅ ⍆")
                
            elif msg.text in ["Simbol2"]:
#       if msg.from_ in admin:  
                cl.sendText(msg.to,"☂ ☔ ✈ ☀ ☼ ☁ ⚡ ⌁ ☇ ☈ ❄ ❅ ❆ ☃ ☉ ☄ ★ ☆ ☽ ☾ ⌛ ⌚ ⌂ ✆ ☎ ☏ ✉ ☑ ✓ ✔ ⎷ ⍻ ✖ ✗ ✘ ☒ ✕ ☓ ☕ ♿ ✌ ☚ ☛ ☜ ☝ ☞ ☟ ☹ ☺ ☻ ☯ ⚘ ☮ ⚰ ⚱ ⚠ ☠ ☢ ⚔ ⚓ ⎈ ⚒ ☡ ❂ ⚕ ⚖ ⚗ ✇ ☣ ⚙ ☤ ⚚ ⚜ ☥ ✝ ☦ ☧ ☨ ☩ † ☪ ☫ ☬ ☭ ✁ ✂ ✃ ✄ ✍ ✎ ✏ ✐  ✑ ✒ ✙ ✚ ✜ ✛ ♰ ♱ ✞ ✟ ✠ ✡ ☸ ✢ ✣ ✤ ✥ ✦ ✧ ✩ ✪ ✫ ✬ ✭ ✮ ✯ ✰ ✲ ✱ ✳ ✴ ✵ ✶ ✷ ✸ ✹ ✺ ✻ ✼ ✽ ✾ ❀ ✿ ❁ ❃ ❇ ❈ ❉ ❊ ❋ ⁕ ☘ ❦ ❧ ☙ ❢ ❣ ♀ ♂ ⚤ ⚦ ⚧ ⚨ ⚩ ☿ ♁ ⚯ ♛ ♕ ♚ ♔ ♜ ♖ ♝ ♗ ♞ ♘ ♟ ♙ ☗ ☖ ♠ ♣ ♦ ♥ ❤ ❥ ♡ ♢ ♤ ♧ ⚀ ⚁ ⚂ ⚃ ⚄ ⚅ ⚇ ⚆ ⚈ ⚉ ♨ ♩ ♪ ♫ ♬ ♭ ♮ ♯ ⏏ ⎗ ⎘ ⎙ ⎚ ⎇ ⌘ ⌦ ⌫ ⌧ ♲ ♳ ♴ ♵ ♶ ♷ ♸ ♹ ♻ ♼ ♽ ⁌ ⁍ ⎌ ⌇ ⍝ ⍟ ⍣ ⍤ ⍥ ⍨ ⍩ ⎋ ♃ ♄ ♅ ♆ ♇ ♈ ♉ ♊ ♋ ♌ ♍ ♎ ♏ ♐ ♑ ♒ ♓ ⏚ ⏛")
                
            elif msg.text in ["Simbol3"]:
#       if msg.from_ in admin:
                cl.sendText(msg.to,"▲ ▼ ◀ ▶ ◢ ◣ ◥ ◤ △ ▽ ◿ ◺ ◹ ◸ ▴ ▾ ◂ ▸ ▵ ▿ ◃ ▹ ◁ ▷ ◅ ▻ ◬ ⟁ ⧋ ⧊ ⊿ ∆ ∇ ◭ ◮ ⧩ ⧨ ⌔ ⟐ ◇ ◆ ◈ ⬖ ⬗ ⬘ ⬙ ⬠ ⬡ ⎔ ⋄ ◊ ⧫ ⬢ ⬣ ▰ ▪ ◼ ▮ ◾ ▗ ▖ ■ ∎ ▃ ▄ ▅ ▆ ▇ █ ▌ ▐ ▍ ▎ ▉ ▊ ▋ ❘ ❙ ❚ ▀ ▘ ▝ ▙ ▚ ▛ ▜ ▟ ▞ ░ ▒ ▓ ▂ ▁ ▬ ▔ ▫ ▯ ▭ ▱ ◽ □ ◻ ▢ ⊞ ⊡ ⊟ ⊠ ▣ ▤ ▥ ▦ ⬚ ▧ ▨ ▩ ⬓ ◧ ⬒ ◨ ◩ ◪ ⬔ ⬕ ❏ ❐ ❑ ❒ ⧈ ◰ ◱ ◳ ◲ ◫ ⧇ ⧅ ⧄ ⍁ ⍂ ⟡ ⧉ ○ ◌ ◍ ◎ ◯ ❍ ◉ ⦾ ⊙ ⦿ ⊜ ⊖ ⊘ ⊚ ⊛ ⊝ ● ⚫ ⦁ ◐ ◑ ◒ ◓ ◔ ◕ ⦶ ⦸ ◵ ◴ ◶ ◷ ⊕ ⊗ ⦇ ⦈ ⦉ ⦊ ❨ ❩ ⸨ ⸩ ◖ ◗ ❪ ❫ ❮ ❯ ❬ ❭ ❰ ❱ ⊏ ⊐ ⊑ ⊒ ◘ ◙ ◚ ◛ ◜ ◝ ◞ ◟ ◠ ◡ ⋒ ⋓ ⋐ ⋑ ⥰ ╰ ╮ ╭ ╯ ⌒ ⥿ ⥾ ⥽ ⥼ ⥊ ⥋ ⥌ ⥍ ⥎ ⥐ ⥑ ⥏ ╳ ✕ ⤫ ⤬ ╱ ╲ ⧸ ⧹ ⌓ ◦ ❖ ✖ ✚ ✜ ⧓ ⧗ ⧑ ⧒ ⧖ _ ⚊ ╴ ╼ ╾ ‐ ⁃ ‑ ‒ - – ⎯ — ― ╶ ╺ ╸ ─ ━ ┄ ┅ ┈ ┉ ╌ ╍ ═ ≣ ≡ ☰ ☱ ☲ ☳ ☴ ☵ ☶ ☷ ╵ ╷ ╹ ╻ │ ▕ ▏ ┃ ┆ ┇ ┊ ╎ ┋ ╿ ╽ ⌞ ⌟ ⌜ ⌝ ⌊ ⌋ ⌈ ⌉ ⌋ ┌ ┍ ┎ ┏ ┐ ┑ ┒ ┓ └ ┕ ┖ ┗ ┘ ┙ ┚ ┛ ├ ┝ ┞ ┟ ┠ ┡ ┢ ┣ ┤ ┥ ┦ ┧ ┨ ┩ ┪ ┫ ┬ ┭ ┮ ┳ ┴ ┵ ┶ ┷ ┸ ┹ ┺ ┻ ┼ ┽ ┾ ┿ ╀ ╁ ╂ ╃ ╄ ╅ ╆ ╇ ╈ ╉ ╊ ╋ ╏ ║ ╔ ╒ ╓ ╕ ╖ ╗ ╚ ╘ ╙ ╛ ╜ ╝ ╞ ╟ ╠ ╡ ╢ ╣ ╤ ╥ ╦ ╧ ╨ ╩ ╪ ╫ ╬")
                
            elif msg.text in ["Simbol4"]:
#       if msg.from_ in admin:
                cl.sendText(msg.to,"⓵ ⓶ ⓷ ⓸ ⓹ ⓺ ⓻ ⓼ ⓽ ⓾ ⒈ ⒉ ⒊ ⒋ ⒌ ⒍ ⒎ ⒏ ⒐ ⒑ ⒒ ⒓ ⒔ ⒕ ⒖ ⒗ ⒘ ⒙ ⒚ ⒛ ⓪ ① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨ ⑩ ➀ ➁ ➂ ➃ ➄ ➅ ➆ ➇ ➈ ➉ ⑪ ⑫ ⑬ ⑭ ⑮ ⑯ ⑰ ⑱ ⑲ ⑳ ⓿ ❶ ❷ ❸ ❹ ❺ ❻ ❼ ❽ ❾ ❿ ➊ ➋ ➌ ➍ ➎ ➏ ➐ ➑ ➒ ➓ ⓫ ⓬ ⓭ ⓮ ⓯ ⓰ ⓱ ⓲ ⓳ ⓴ ⑴ ⑵ ⑶ ⑷ ⑸ ⑹ ⑺ ⑻ ⑼ ⑽ ⑾ ⑿ ⒀ ⒁ ⒂ ⒃ ⒄ ⒅ ⒆ ⒇ ¹ ² ³ ↉ ½ ⅓ ¼ ⅕ ⅙ ⅐ ⅛ ⅑ ⅒ ⅔ ⅖ ¾ ⅗ ⅜ ⅘ ⅚ ⅝ ⅞")
                
            elif msg.text in ["Simbol5"]:
#       if msg.from_ in admin:
                cl.sendText(msg.to,"∞ ⟀ ⟁ ⟂ ⟃ ⟄ ⟇ ⟈ ⟉ ⟊ ⟐ ⟑ ⟒ ⟓ ⟔ ⟕ ⟖ ⟗ ⟘ ⟙ ⟚ ⟛ ⟜ ⟝ ⟞ ⟟ ⟠ ⟡ ⟢ ⟣ ⟤ ⟥ ⟦ ⟧ ⟨ ⟩ ��� ⟫ ⦅ ⦆ ⦿ ⧺ ⧻ ∀ ∁ ∂ ∃ ∄ ∅ ∆ ∇ ∈ ∉ ∊ ∋ ∌ ∍ ∎ ∏ ∐ ∑ − ∓ ∔ ∕ ∖ ∗ ∘ ∙ √ ∛ ∜ ∝ ∟ ∠ ∡ ∢ ∣ ∤ ∥ ∦ ∧ ∨ ∩ ∪ ∫ ∬ ∭ ∮ ∯ ∰ ∱ ∲ ∳ ∴ ∵ ∶ ∷ ∸ ∹ ∺ ∻ ∼ ∽ ∾ ∿ ≀ ≁ ≂ ≃ ≄ ≅ ≆ ≇ ≈ ≉ ≊ ≋ ≌ ≍ ≎ ≏ ≐ ≑ ≒ ≓ ≔ ≕ ≖ ≗ ≘ ≙ ≚ ≛ ≜ ≝ ≞ ≟ ≠ ≡ ≢ ≣ ≤ ≥ ≦ ≧ ≨ ≩ ≪ ≫ ≬ ≭ ≮ ≯ ≰ ≱ ≲ ≳ ≴ ≵ ≶ ≷ ≸ ≹ ≺ ≻ ≼ ≽ ≾ ≿ ⊀ ⊁ ⊂ ⊃ ⊄ ⊅ ⊆ ⊇ ⊈ ⊉ ⊊ ⊋ ⊌ ⊍ ⊎ ⊏ ⊐ ⊑ ⊒ ⊓ ⊔ ⊕ ⊖ ⊗ ⊘ ⊙ ⊚ ⊛ ⊜ ⊝ ⊞ ⊟ ⊠ ⊡ ⊢ ⊣ ⊤ ⊥ ⊦ ⊧ ⊨ ⊩ ⊪ ⊫ ⊬ ⊭ ⊮ ⊯ ⊰ ⊱ ⊲ ⊳ ⊴ ⊵ ⊶ ⊷ ⊸ ⊹ ⊺ ⊻ ⊼ ⊽ ⊾ ⊿ ⋀ ⋁ ⋂ ⋃ ⋄ ⋅ ⋆ ⋇ ⋈ ⋉ ⋊ ⋋ ⋌ ⋍ ⋎ ⋏ ⋐ ⋑ ⋒ ⋓ ⋔ ⋕ ⋖ ⋗ ⋘ ⋙ ⋚ ⋛ ⋜ ⋝ ⋞ ⋟ ⋠ ⋡ ⋢ ⋣ ⋤ ⋥ ⋦ ⋧ ⋨ ⋩ ⋪ ⋫ ⋬ ⋭ ⋮ ⋯ ⋰ ⋱ ⋲ ⋳ ⋴ ⋵ ⋶ ⋷ ⋸ ⋹ ⋺ ⋻ ⋼ ⋽ ⋾ ⋿ ✕ ✖ ✚")
               
            elif msg.text in ["Simbol6"]:
#       if msg.from_ in admin:
                cl.sendText(msg.to,"🎳 🏂 🌁 🌉 🌋 🌌 🌏 🌑 🌓 🌔 🌕 🌛 🌠 🌰 🍏 🌱 🌼 🌽 🌿 🍄 🍇 �� 🍌 🍍 🍑 🍒 🍩 🍕 🍖 🍗 🍠 🍤 🍥 🍨 🍪 🍫 🍬 🍭 🍮 🍯 🍷 🍹 🎊 🎋 🎠 🎣 🎭 🎮 🎲 🎴 🎹 🎻 🎼 🎽 🏡 🏮 🐌 🐜 🐝 🐞 🐡 🐢 🐣 🐥 🐩 🐼 🐽 🐾 👅 👓 👖 👚 👛 👝 👤 👪 👰 👹 👺 💌 💕 💖 💞 💠 💥 💧 💫 💬 💮 💯 💲 💳 💴 💵 💸 💾 📁 📂 📃 📄 📅 📆 📇 📈 📉 📊 📋 📌 📍 📎 📏 📐 📑 📒 📓 📔 📕 📙 📚 📛 📜 📞 📟 📤 📥 📦 📧 📨 📪 📰 📹 🔃 🔋 🔌 🔎 🔏 🔐 🔖 🔗 🔘 🔙 🔚 🔛 🔜 🔟 🔠 🔡 🔢 🔣 🔤 🔦 🔧 🔩 🔪 🔮 🔵 🔶 🔷 🔸 🔹 🔼 🔽 😄 😊 😃 😉 😍 😘 😚 😳 😌 😁 😜 😝 😒 😏 😓 😔 😞 😱 😠 😡 😪 😷 👿 👽 💛 💙 💜 💗 💚 💔 💓 💘 🌟 💢 💤 💨 💦 🎶 🎵 🔥 💩 👍 👎 👌 👊 👋 👐 👆 👇 👉 👈 🙌 🙏 👏 💪 🚶 🏃 👫 💃 👯 🙆 🙅 💁 🙇 💏 💑 💆 💇 💅 👦 👧 👩 👨 👶 👵 👴 👱 👲 👳 👷 👮 👼 👸 💂 💀 👣 💋 👄 👂 👀 👃 ⛄ 🌙 🌀 🌊 🐱 🐶 🐭 🐹 🐰 🐺 🐸 🐯 🐨 🐻 🐷 🐮 🐗 🐵 🐒 🐴 🐎 🐫 🐑 🐘 🐍 🐦 🐤 🐔 🐧 🐛 🐙 🐠 🐟 🐳 🐬 💐 🌸 🌹 🌻 🌺 🍁 🍃 🍂 🌴 🌵 🌾 🐚 🎍 💝 🎎 🎒 🎓 🎏 🎆 🎇 🎐 🎑 🎃 👻 🎅 🎄 🎁 🔔 🎉 🎈 💿 📀 📷 🎥 💻 📺 📱 📠 ���� 📼 🔊 📢 📣 📻 📡 🔍 🔓 🔒 🔑 ���� 💡 📲 📩 📫 📮 🛀 🚽 💺 💰 🔱 🚬 💣 🔫 💊 💉 🏈 🏀 ⚽ ⚾ 🎾 ⛳ 🎱 🏊 🏄 🎿 🏆 👾 🎷 🎸 👟 👡 👠 👢 👕 👔 👜 💄 💍 💎 🍵 🍺 🍻 🍸 🍶 🍴 🍔 🍟 🍝 🍛 🍱 🍣 🍙 🍘 🍚 🍜 🍲 🍞 🍳 🍢 🍡 🍦 🍧 🎂 🍰 🍎 🍊 🍉 🍓 🍆 🍅 🏠 🏫 🏢 🏣 🏥 🏦 🏪 🏩 🏨 💒 ⛪ 🏬 🌇 🌆 🏯 🏰 ⛺ 🏭 🗼 🗻 🌄 🌅 🌃 🗽 🌈 🎡 ⛲ 🎢 🚢 🚤 ⛵ 🚀 🚲 🚙 🚗 🚕 🚌 🚓 🚒 🚑 🚚 🚃 🚉 🚄 🚅 🎫 ⛽ 🚥 🚧 🔰 🏧 🎰 🚏 💈 🏁 🎌 🎯 🀄 🎬 📝 📖 🎨 🎤 🎧 🎺 👗 👘 👙 🎀 🎩 👑 👒 🌂 💼")
                
            elif msg.text in ["Simbol7"]:
#       if msg.from_ in admin:
                cl.sendText(msg.to,"Aku belum mandi")
#----------------------------------------------------------------------------------------
            elif msg.text.lower() == 'hadeh':
                msg.contentType = 7
                msg.text = None
                msg.contentMetadata = {
                                     "STKID" : "12772854",
                                     "STKPKGID" : "1316466",
                                     "STKVER" : "1" }
                cl.sendMessage(msg)
                cl.sendMessage(msg)
#                cl.sendMessage(msg)
            elif msg.text.lower() == 'ok':
                msg.contentType = 7
                msg.text = None
                msg.contentMetadata = {
                                     "STKID" : "15597509",
                                     "STKPKGID" : "1403265",
                                     "STKVER" : "1" }
                cl.sendMessage(msg)
                cl.sendMessage(msg)
#                cl.sendMessage(msg)
            elif msg.text.lower() == 'haha':
                msg.contentType = 7
                msg.text = None
                msg.contentMetadata = {
                                     "STKID" : "15524866",
                                    "STKPKGID" : "1400906",
                                    "STKVER" : "1" }
                cl.sendMessage(msg)
                cl.sendMessage(msg)
#                cl.sendMessage(msg)
            elif msg.text.lower() == 'hahaha':
                msg.contentType = 7
                msg.text = None
                msg.contentMetadata = {
                                     "STKID": "15351421",
                                     "STKPKGID": "1395222",
                                     "STKVER": "1" }
                cl.sendMessage(msg)
                cl.sendMessage(msg)
                cl.sendMessage(msg)
            elif msg.text.lower() == 'hmm':
                msg.contentType = 7
                msg.text = None
                msg.contentMetadata = {
                                     "STKID" : "8853517",
                                     "STKPKGID" : "1218039",
                                     "STKVER" : "1" }
                cl.sendMessage(msg)
                cl.sendMessage(msg)
#                cl.sendMessage(msg)
            elif msg.text.lower() == 'tidur':
                msg.contentType = 7
                msg.text = None
                msg.contentMetadata = {
                                     "STKID" : "16844057",
                                     "STKPKGID" : "8670",
                                     "STKVER" : "3" }
                cl.sendMessage(msg)
                cl.sendMessage(msg)
#                cl.sendMessage(msg)
            elif msg.text.lower() == 'pagi':
                msg.contentType = 7
                msg.text = None
                msg.contentMetadata = {
                                     "STKID": "12860219",
                                     "STKPKGID": "1318703",
                                     "STKVER": "1" }
                cl.sendMessage(msg)
                cl.sendMessage(msg)
                cl.sendMessage(msg)
            elif msg.text.lower() == 'cium':
                msg.contentType = 7
                msg.text = None
                msg.contentMetadata = {
                                     "STKID": "15017202",
                                     "STKPKGID": "1384664",
                                     "STKVER": "1" }
                cl.sendMessage(msg)
                cl.sendMessage(msg)
                cl.sendMessage(msg)
            elif msg.text.lower() == 'tega ih':
                msg.contentType = 7
                msg.text = None
                msg.contentMetadata = {
                                     "STKID" : "7846219",
                                     "STKPKGID" : "1193024",
                                     "STKVER" : "1" }
                cl.sendMessage(msg)
                cl.sendMessage(msg)
#                cl.sendMessage(msg)
            elif msg.text.lower() == 'cie':
                msg.contentType = 7
                msg.text = None
                msg.contentMetadata = {
                                     "STKID": "26055267",
                                     "STKPKGID": "1834462",
                                     "STKVER": "1" }
                cl.sendMessage(msg)
                cl.sendMessage(msg)
                cl.sendMessage(msg)
            elif msg.text in ["Wslm"]:
                msg.contentType = 7
                msg.text = None
                msg.contentMetadata = {
                                     "STKID": "15669531",
                                     "STKPKGID": "1405607",
                                     "STKVER": "1" }
                cl.sendMessage(msg)
            elif msg.text.lower() == 'kibat':
                msg.contentType = 7
                msg.text = None
                msg.contentMetadata = {
                                     "STKID": "10764",
                                     "STKPKGID": "787",
                                     "STKVER": "9" }
                cl.sendMessage(msg)
                cl.sendMessage(msg)
                cl.sendMessage(msg)
#-------------------------------------------------------------------------------
            elif "Spam" in msg.text:
                if msg.from_ in Owner and admin and Bots:
                    txt = msg.text.split(" ")
                    jmlh = int(txt[2])
                    teks = msg.text.replace("Spam "+str(txt[1])+" "+str(jmlh)+" ","")
                    tulisan = jmlh * (teks+"\n")
                    if txt[1] == "on":
                        if jmlh <= 100000:
                            for x in range(jmlh):
                                cl.sendText(msg.to, teks)
                        else:
                            cl.sendText(msg.to, "Out of Range!")
                    elif txt[1] == "off":
                        if jmlh <= 100000:
                            cl.sendText(msg.to, tulisan)
                        else:
                            cl.sendText(msg.to, "Out Of Range!")
                    
                    
    except Exception as error:
        print error
                    
while True:
    try:
        Ops = cl.fetchOps(cl.Poll.rev, 5)
    except EOFError:
        raise Exception("It might be wrong revision\n" + str(cl.Poll.rev))

    for Op in Ops:
        if (Op.type != OpType.END_OF_OPERATION):
            cl.Poll.rev = max(cl.Poll.rev, Op.revision)
            bot(Op)
