# -*- coding: utf-8 -*-

import LINETCR
from LINETCR.lib.curve.ttypes import *
from datetime import datetime
import time, random, sys, ast, re, os, io, json, subprocess, threading, string, codecs, requests, ctypes, urllib, urllib2, urllib3, wikipedia, tempfile
from bs4 import BeautifulSoup
from urllib import urlopen
from io import StringIO
from threading import Thread
from gtts import gTTS
from googletrans import Translator

#cl = LINETCR.LINE()
#cl.login(qr=True)
#cl.loginResult()

cl = LINETCR.LINE()
cl.login(token="ErSM91tsYVxCtYLA4mBb.0p9gOXYX0kSWjbxtjkkWQW.+eDQKEYpihBNjDFCUBk2xuaFZOSN+6D8kzHLpVFgRPg=")
cl.loginResult()
#ue8b464b7b97ecb946f763ad07e7a7533
print "==================[Login Success]==================="
reload(sys)
sys.setdefaultencoding('utf-8')

helpmsg ="""╔════ஜ 🎓 ஜ═══╗
║              🔥 $3KT0R 87 🔥        ║
╚════ஜ 🎓 ஜ═══╝
🔰Hᴇʟᴘ ᴘᴄ
🔰Hᴇʟᴘ sᴇʟғ
🔰Hᴇʟᴘ ɢʀᴜᴘ
🔰Hᴇʟᴘ sᴇᴛ
🔰Hᴇʟᴘ ᴋɪᴄᴋ
🔰Hᴇʟᴘ ᴍᴇᴅɪᴀ
🔰Hᴇʟᴘ ᴏᴛʜᴇʀ
🔰Hᴇʟᴘ ᴄᴏsᴛᴜᴍᴇ
╔════ஜ 🎓 ஜ═══╗
║  line.me/ti/p/5rdNmqNL9c      ║
╚════ஜ 🎓 ஜ═══╝
"""

helppc ="""╔════ஜ 🎓 ஜ═══╗
║              🔥 $3KT0R 87 🔥        ║
╚════ஜ 🎓 ஜ═══╝
🔰Sᴘᴇᴇᴅ
🔰Rᴜɴᴛɪᴍᴇ
🔰Bᴏᴛ ᴏɴ
🔰Bᴏᴛ ᴍᴍᴜᴛᴇ
🔰Rᴇsᴛᴀʀᴛ
🔰Tᴜʀɴ ᴏғғ 
╔════ஜ 🎓 ஜ═══╗
║  line.me/ti/p/5rdNmqNL9c      ║
╚════ஜ 🎓 ஜ═══╝
"""

helpkick ="""╔════ஜ 🎓 ஜ═══╗
║              🔥 $3KT0R 87 🔥       ║
╚════ஜ 🎓 ஜ═══╝
🔰ʙᴜɴᴜʜ.@.
🔰ᴋɪᴄᴋ.@.
🔰ᴜʟᴛɪ.@.
🔰ᴄʟɴ
🔰ɴᴋ
🔰ʀᴇʟᴀxɪɴɢ
🔰ᴄᴀɴᴄᴇʟ
╠════ஜ 🎓 ஜ═══╣
🔰ʙᴀɴ.@.
🔰ᴍɪᴅʙᴀɴ
🔰ᴜɴʙᴀɴ.@.
🔰ᴄʟᴇᴀʀʙᴀɴ
🔰ʙᴀɴʟɪsᴛ
╔════ஜ 🎓 ஜ═══╗
║  line.me/ti/p/5rdNmqNL9c      ║
╚════ஜ 🎓 ஜ═══╝
"""

helpself ="""╔════ஜ 🎓 ஜ═══╗
║              🔥 $3KT0R 87 🔥      ║
╚════ஜ 🎓 ஜ═══╝
🔰Cʀᴇᴀᴛᴏʀ
🔰Mᴇ
🔰Mʏᴍɪᴅ
🔰Mʏɴᴀᴍᴇ:
🔰Mʏʙɪᴏ:
🔰Mʏᴘɪᴄᴛ
🔰Gʟɪsᴛ
🔰Gʀᴜᴘʟɪsᴛ
🔰Gᴄᴀɴᴄᴇʟ
🔰ʀᴇᴍᴏᴠᴇᴄʜᴀᴛ.
🔰Mᴇɴᴛɪᴏɴ/Cɪʟᴜᴋ ʙᴀᴀ 
╠═══ஜ 🎓 ஜ═══╣
🔰Gᴇᴛᴍɪᴅ 
🔰Gᴇᴛᴘʀᴏғɪʟᴇ
🔰Gᴇᴛᴄᴏɴᴛᴀᴄᴛ
🔰Gᴇᴛɪɴғᴏ
🔰Gᴇᴛɴᴀᴍᴇ
🔰Gᴇᴛʙɪᴏ
╔════ஜ 🎓 ஜ═══╗
║  http://line.me/ti/p/5rdNmqNL9c      ║
╚════ஜ 🎓 ஜ═══╝
"""

helpset ="""╔════ஜ 🎓 ஜ═══╗
║             🔥 $3KT0R 87 🔥         ║
╚════ஜ 🎓 ஜ═══╝
🔰Pʀᴏᴛᴇᴄᴛ ᴏɴ/ᴏғғ
🔰Qʀ ᴏɴ/ᴏғғ
🔰Iɴᴠɪᴛ ᴏɴ/ᴏғғ
🔰Cᴀɴᴄᴇʟ ᴏɴ/ᴏғғ
🔰Lɪɴᴋ ᴏɴ/ᴏғғ
🔰SᴇᴛPʀᴏ ᴏɴ/ᴏғғ
🔰Sᴇᴛsᴇʟғ ᴏɴ/ᴏғ
╠════ஜ 🎓 ஜ═══╣
🔰Sɪᴅᴇʀ ᴏɴ/ᴏғғ
🔰Ksɪᴅᴇʀ ᴏɴ/ᴏғ
🔰ᴊᴏɪɴᴋɪᴄᴋ ᴏɴ/ᴏғғ
🔰Cᴏɴᴛᴀᴄᴛ ᴏɴ/ᴏғғ
🔰Aᴜᴛᴏᴊᴏɪɴ ᴏɴ/ᴏғғ
🔰Aᴜᴛᴏʟᴇᴀᴠᴇ ᴏɴ/ᴏғғ
🔰Aᴜᴛᴏᴀᴅᴅ ᴏɴ/ᴏғғ
🔰ᴊᴀᴍ ᴏɴ/ᴏғғ
╠════ஜ 🎓 ஜ═══╣
🔰Aᴜᴛᴏʀᴇsᴘᴏɴ ᴏɴ/ᴏғғ
🔰Rᴇsᴘᴏɴ ᴏɴ
🔰Rᴇsᴘᴏɴᴋɪᴄᴋ ᴏɴ/ᴏғғ
🔰Sᴛɪᴄᴋᴇʀ ᴏɴ/ᴏғғ
🔰Mɪᴍɪᴄ ᴏɴ/ᴏғғ
🔰Wᴇʟᴄᴏᴍᴇ ᴏɴ/ᴏғғ
🔰Cᴏᴍᴇ ᴏɴ/ᴏғғ
🔰Cᴏᴍᴇ ᴄᴇᴋ
🔰Cᴏᴍᴇsᴇᴛ:
╠════ஜ 🎓 ஜ═══╣
🔰Lɪᴋᴇ ᴏɴ/ᴏғғ
🔰Lɪᴋᴇ ᴍᴇ
🔰Lɪᴋᴇ ғʀɪᴇɴᴅ
╠════ஜ 🎓 ஜ═══╣
🔰Rᴇᴀᴅ ᴏɴ/ᴏғғ
🔰Sʜᴀʀᴇ ᴏɴ/ᴏғғ
🔰Sɪᴍɪsɪᴍɪ ᴏɴ/ᴏғғ
╠════ஜ 🎓 ஜ═══╣
🔰Mɪᴍɪᴄ ᴛᴀʀɢᴇᴛ
🔰Mɪᴄʟɪsᴛ
🔰Mʏᴄᴏᴘʏ
🔰Mʏʙᴀᴄᴋᴜᴘ
🔰Sᴛᴀᴛᴜs
╔════ஜ 🎓 ஜ═══╗
║  line.me/ti/p/5rdNmqNL9c      ║
╚════ஜ 🎓 ஜ═══╝
"""
helpcostume ="""╔════ஜ 🎓 ஜ═══╗
║             🔥 $3KT0R 87 🔥         ║
╚════ஜ 🎓 ஜ═══╝
🔰CᴏᴍᴇɢʀᴇᴀᴛSᴇᴛ: [ᴄᴇᴋ]
🔰LᴇғᴛɢʀᴇᴀᴛSᴇᴛ: [ᴄᴇᴋ]
🔰AᴅᴅɢʀᴇᴀᴛSᴇᴛ: [ᴄᴇᴋ]
🔰SɪᴅᴇʀSᴇᴛ: [ᴄᴇᴋ]
🔰RᴇsᴘᴏɴSᴇᴛ: [ᴄᴇᴋ]
╔════ஜ 🎓 ஜ═══╗
║  line.me/ti/p/mt6qgzsLee     ║
╚════ஜ 🎓 ஜ═══╝
"""

helpgrup ="""╔════ஜ 🎓 ஜ═══╗
║             🔥 $3KT0R 87 🔥         ║
╚════ஜ 🎓 ஜ═══╝
🔰Wᴇʟᴄᴏᴍᴇ
🔰Iɴғᴏɢʀᴜᴘ
🔰Gʀᴜᴘɴᴀᴍᴇ
🔰Uʀʟɢʀᴜᴘ ɪᴍᴀɢᴇ
🔰Gᴇᴛɢʀᴜᴘ ɪᴍᴀɢᴇ
🔰Gᴄʀᴇᴀᴛᴏʀ
🔰Gʀᴜᴘɪᴅɢʀᴜᴘ ɪᴅ
🔰Mᴇᴍʟɪsᴛ
🔰ʟᴜʀᴋ ᴏɴ/ғғ
🔰ʟᴜʀᴋᴇʀs
🔰Aᴅᴅ ᴀʟʟ
🔰Aᴅᴅ
╠═══ஜ 🎓 ஜ═══╣
🔰Gɴᴀᴍᴇ
🔰Gʀᴜᴘɪᴍᴀɢᴇ:
🔰Gʙʀᴏᴀᴅᴄᴀsᴛ
🔰Cʙʀᴏᴀᴅᴄᴀsᴛ:
╠═══ஜ 🎓 ஜ═══╣
🔰Uʀʟ
🔰Iɴᴠɪᴛᴇ
🔰ɪɴᴠɪᴛᴇ:ᴄʀᴇᴀᴛʙᴏᴛ
🔰ɪɴᴠɪᴛᴇ:ɢᴄʀᴇᴀᴛᴏʀ
🔰Sᴘᴀᴍ
🔰Gɪғᴛ
🔰Bʏᴇ.
🔰Bʏᴇᴀʟʟ.
╔════ஜ 🎓 ஜ═══╗
║  line.me/ti/p/5rdNmqNL9c      ║
╚════ஜ 🎓 ஜ═══╝
"""

helpmed ="""╔════ஜ 🎓 ஜ═══╗
║             🔥 $3KT0R 87 🔥         ║
╚════ஜ 🎓 ஜ═══╝
🔰Tʀ-ɪᴅ/ᴇɴ/ᴋᴏ/ᴊᴘ/ᴛʜ/ᴊᴡ
🔰Sᴀʏ-ɪᴅ/ᴇɴ/ᴋᴏ/ᴊᴘ/ᴛʜ
╠════ஜ 🎓 ஜ═══╣
🔰ᴘʀᴏғɪʟᴇɪɢ
🔰ᴄʜᴇᴄᴋᴅᴀᴛᴇ
🔰Kᴀʟᴇɴᴅᴇʀ
🔰Iᴍᴀɢᴇ
🔰Mᴜsɪᴄ
🔰Lɪʀɪᴋ
🔰Pʟᴀʏsᴛᴏʀᴇ
🔰Wɪᴋɪᴘᴇᴅɪᴀ
╠════ஜ 🎓 ஜ═══╣
🔰ʏᴛ-sᴇᴀʀᴄʜ
🔰ʏᴛ-ᴍᴘ4
🔰ʏᴛ-ɢᴇᴛ
╔════ஜ 🎓 ஜ═══╗
║  line.me/ti/p/5rdNmqNL9c      ║
╚════ஜ 🎓 ஜ═══╝
"""
helpother ="""╔════ஜ 🎓 ஜ═══╗
║             🔥 $3KT0R 87 🔥         ║
╚════ஜ 🎓 ஜ═══╝
🔰Wᴇʟᴄᴏᴍᴇ
🔰Sɪᴍʙᴏʟ1
🔰Sɪᴍʙᴏʟ2
🔰Sɪᴍʙᴏʟ3
🔰Sɪᴍʙᴏʟ4
🔰Sɪᴍʙᴏʟ5
╔════ஜ 🎓 ஜ═══╗
║  line.me/ti/p/5rdNmqNL9c     ║
╚════ஜ 🎓 ஜ═══╝
"""

mid = cl.getProfile().mid
Bots=[mid,"ud0ff46a31cb1d0ab302415d324a2b0ab"]
Owner=["ud0ff46a31cb1d0ab302415d324a2b0ab"]
admin=["ud0ff46a31cb1d0ab302415d324a2b0ab"]
blacklist=[""]
dangerMessage = [".Modar",".modar","!modar","#modar",".","Cleanse","cleanse","Group cleansed.",".winebot",".kickall","Mayhem","mayhem","Kick on","makasih :d","!kickall","Nuke","nuke"]

wait = {
    "likeOn":True,
    "alwayRead":False,
    "detectMention":False,
    "detectMention2":False,  
    "detectMention3":True,  
    "detectMentionpc":False,  
    "kickMention":False,
    "steal":False,
    'pap':{},
    'invite':{},
    "spam":{},
    'contact':False,
    'autoJoin':True,
    'autoCancel':{"on":False,"members":50},
    "joinkick":False,
    'leaveRoom':True,
    'timeline':False,
    'autoAdd':False,
    'message':"",
    "lang":"JP",
    "comment":"╔══ஜ°°°Aᴜᴛᴏ°°Lɪᴋᴇ°°°ஜ══╗\n║           🎩^$€^™^β¤t^🎩           \n╚══ஜ°°Oᴘᴇɴ Oʀᴅᴇʀ°°ஜ══╝\n⚖SᴇʟғBᴏᴛ\n⚖Pʀᴏᴛᴇᴄᴛ Bᴏᴛ\n⚖Cᴏɪɴ Lɪɴᴇ Vɪᴀ Gɪғᴛ\n⚖Tʜᴇᴍᴀ\n⚖Vɪᴘ Sᴍᴜʟᴇ\n⚖Sᴀɢᴀʟᴀ Aʏᴀ Wᴇʟᴀʜ\n╔═ஜ°° Cʀᴇᴀᴛᴇᴅ Bʏ °°ஜ══╗\n║  line.me/ti/p/QvU09Wriyc \n╚═ஜ°°Sᴜɴᴅᴀɴis Eᴅᴀɴ°°ஜ═╝",
    "arespon":"",
    "comegreat":"",
    "leftgreat":"",
    "comepc":"",
    "addgreat":"",
    "siderset":"",
    "comment1":"❂➤Thanks For Add me!!\n 🎩^$€^~Sᴜɴᴅᴀɴis Eᴅᴀɴ™β¤t~🎩\n\n http://line.me/ti/p/QvU09Wriyc",
    "commentOn":True,
    "commentBlack":{},
    "wblack":False,
    "dblack":False,
    "clock":False,
    "cNames":"",
    "blacklist":{},
    "wblacklist":False,
    "dblacklist":False,
    "protect":False,
    "cancelprotect":False,
    "inviteprotect":False,
    "linkprotect":False,
    "Ghost":False,
    "Sambutan":True,
    "admincipok":False,
    "adminletak":False,
    "Sider":{},
    "Kicksider":False,
    "sticker":False,
    "Bot":True,
}

wait2 = {
    "readPoint":{},
    "readMember":{},
    "setTime":{},
    "ROM":{}
    }

mimic = {
    "copy":False,
    "copy2":False,
    "status":False,
    "target":{}
    }
    
settings = {
    "simiSimi":{}
    }

cctv = {
    "cyduk":{},
    "point":{},
    "sidermem":{}
}    

res = {
    'num':{},
    'us':{},
    'au':{},
    }

setTime = {}
setTime = wait2['setTime']
mulai = time.time() 

contact = cl.getProfile()
backup = cl.getProfile()
backup.displayName = contact.displayName
backup.statusMessage = contact.statusMessage                        
backup.pictureStatus = contact.pictureStatus

def restart_program():
    python = sys.executable
    os.execl(python, python, * sys.argv)
        
def download_page(url):
    version = (3,0)
    cur_version = sys.version_info
    if cur_version >= version:     #If the Current Version of Python is 3.0 or above
        import urllib,request    #urllib library for Extracting web pages
        try:
            headers = {}
            headers['User-Agent'] = "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36"
            req = urllib,request.Request(url, headers = headers)
            resp = urllib,request.urlopen(req)
            respData = str(resp.read())
            return respData
        except Exception as e:
            print(str(e))
    else:                        #If the Current Version of Python is 2.x
        import urllib2
        try:
            headers = {}
            headers['User-Agent'] = "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.17 (KHTML, like Gecko) Chrome/24.0.1312.27 Safari/537.17"
            req = urllib2.Request(url, headers = headers)
            response = urllib2.urlopen(req)
            page = response.read()
            return page
        except:
            return"Page Not found"

#Finding 'Next Image' from the given raw page
def _images_get_next_item(s):
    start_line = s.find('rg_di')
    if start_line == -1:    #If no links are found then give an error!
        end_quote = 0
        link = "no_links"
        return link, end_quote
    else:
        start_line = s.find('"class="rg_meta"')
        start_content = s.find('"ou"',start_line+90)
        end_content = s.find(',"ow"',start_content-90)
        content_raw = str(s[start_content+6:end_content-1])
        return content_raw, end_content
        
#Getting all links with the help of '_images_get_next_image'
def _images_get_all_items(page):
    items = []
    while True:
        item, end_content = _images_get_next_item(page)
        if item == "no_links":
            break
        else:
            items.append(item)      #Append all the links in the list named 'Links'
            time.sleep(0.1)        #Timer could be used to slow down the request for image downloads
            page = page[end_content:]
    return items

def upload_tempimage(client):
    '''
        Upload a picture of a kitten. We don't ship one, so get creative!
    '''
    config = {
        'album': album,
        'name':  'bot auto upload',
        'title': 'bot auto upload',
        'description': 'bot auto upload'
    }

    print("Uploading image... ")
    image = client.upload_from_path(image_path, config=config, anon=False)
    print("Done")
    print()

def summon(to, nama):
    aa = ""
    bb = ""
    strt = int(14)
    akh = int(14)
    nm = nama
    for mm in nm:
      akh = akh + 2
      aa += """{"S":"""+json.dumps(str(strt))+""","E":"""+json.dumps(str(akh))+""","M":"""+json.dumps(mm)+"},"""
      strt = strt + 6
      akh = akh + 4
      bb += "\xe2\x95\xa0 @x \n"
    aa = (aa[:int(len(aa)-1)])
    msg = Message()
    msg.to = to
    msg.text = "\xe2\x95\x94\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\n"+bb+"\xe2\x95\x9a\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90"
    msg.contentMetadata ={'MENTION':'{"MENTIONEES":['+aa+']}','EMTVER':'4'}
    print "[Command] Tag All"
    try:
       cl.sendMessage(msg)
    except Exception as error:
       print error
       
def waktu(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    return '%02d Jam %02d Menit %02d Detik' % (hours, mins, secs)      

def cms(string, commands): #/XXX, >XXX, ;XXX, ^XXX, %XXX, $XXX...
    tex = ["+","@","/",">",";","^","%","$","＾","サテラ:","サテラ:","サテラ：","サテラ："]
    for texX in tex:
        for command in commands:
            if string ==command:
                return True
    return False

def sendMessage(to, text, contentMetadata={}, contentType=0):
    mes = Message()
    mes.to, mes.from_ = to, profile.mid
    mes.text = text
    mes.contentType, mes.contentMetadata = contentType, contentMetadata
    if to not in messageReq:
        messageReq[to] = -1
    messageReq[to] += 1

def autolike():
    count = 1
    while True:
        try:
           for posts in cl.activity(1)["result"]["posts"]:
             if posts["postInfo"]["liked"] is False:
                if wait["likeOn"] == True:
                   cl.like(posts["userInfo"]["writerMid"], posts["postInfo"]["postId"], 1001)
                   print "Like"
                   if wait["commentOn"] == True:
                      if posts["userInfo"]["writerMid"] in wait["commentBlack"]:
                         pass
                      else:
                          cl.comment(posts["userInfo"]["writerMid"],posts["postInfo"]["postId"],wait["comment"])
        except:
            count += 1
            if(count == 50):
                sys.exit(0)
            else:
                pass
thread2 = threading.Thread(target=autolike)
thread2.daemon = True
thread2.start()

def likefriend():
    for zx in range(0,20):
      hasil = cl.activity(limit=20)
      if hasil['result']['posts'][zx]['postInfo']['liked'] == False:
        try:
          cl.like(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],likeType=1001)
          print "Like"
        except:
          pass
      else:
          print "Already Liked"
time.sleep(0.60)

def likeme():
    for zx in range(0,20):
        hasil = cl.activity(limit=20)
        if hasil['result']['posts'][zx]['postInfo']['liked'] == False:
            if hasil['result']['posts'][zx]['userInfo']['mid'] in mid:
                try:
                    cl.like(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],likeType=1002)
                    print "Like"
                except:
                    pass
            else:
                print "Status Sudah di Like"
                
def bot(op):
    try:
        if op.type == 0:
            return
        if op.type == 13:
            if mid in op.param3:
                G = cl.getGroup(op.param1)
                if wait["autoJoin"] == True:
                    if wait["autoCancel"]["on"] == True:
                        if len(G.members) <= wait["autoCancel"]["members"]:
                            cl.rejectGroupInvitation(op.param1)
                        else:
                            cl.acceptGroupInvitation(op.param1)
                    else:
                        cl.acceptGroupInvitation(op.param1)
                elif wait["autoCancel"]["on"] == True:
                    if len(G.members) <= wait["autoCancel"]["members"]:
                        cl.rejectGroupInvitation(op.param1)
            else:
                Inviter = op.param3.replace("",',')
                InviterX = Inviter.split(",")
                matched_list = []
                for tag in wait["blacklist"]:
                    matched_list+=filter(lambda str: str == tag, InviterX)
                if matched_list == []:
                    pass
                else:
                    cl.cancelGroupInvitation(op.param1, matched_list)
        if op.type == 13:
            if blacklist in op.param3:
                cl.cancelGroupInvitation(op.param1, matched_list)
            else:
                pass
            
        if op.type == 5:
            print ("[ 5 ] NOTIFIED ADD CONTACT")
            if wait["autoAdd"] == True:
                dit = wait["addgreat"]
                dut = cl.getContact(op.param1).displayName
                cl.sendText(op.param1, "Haii...❂➤" + dut + " \nThanks For Add me!!\n 🎩^$€^~Sᴜɴᴅᴀɴis Eᴅᴀɴ™β¤t~🎩\n\n http://line.me/ti/p/QvU09Wriyc" + dit)
            else:
                dit = wait["addgreat"]
                dut = cl.getContact(op.param1).displayName
                cl.sendText(op.param1, "Yap...❂➤" + dut + " \nThanks For Add Me..!!\n 🎩^$€^~Sᴜɴᴅᴀɴis Eᴅᴀɴ™β¤t~🎩\n\n http://line.me/ti/p/QvU09Wriyc" + dit)
#-------------------------------------------------------------------------------
        if op.type == 19:
            if mid in op.param3:
                wait["blacklist"][op.param2] = True
#-------------------------------------------------------------------------------
        if op.type == 22:
            if wait["leaveRoom"] == True:
                cl.leaveRoom(op.param1)
#-------------------------------------------------------------------------------
        if op.type == 24:
            if wait["leaveRoom"] == True:
                cl.leaveRoom(op.param1)
#==============================================#
        if op.type == 17:
            if op.param2 not in Bots:
                if op.param2 in Bots:
                    pass
            if wait["protect"] == True:
                if wait["blacklist"][op.param2] == True:
                    try:
                        cl.kickoutFromGroup(op.param1,[op.param2])
                        G = cl.getGroup(op.param1)
                        G.preventJoinByTicket = True
                        cl.updateGroup(G)
                    except:
                        try:
                            cl.kickoutFromGroup(op.param1,[op.param2])
                            G = cl.getGroup(op.param1)
                            G.preventJoinByTicket = True
                            cl.updateGroup(G)
                        except:
                            pass
                                                            
#----------------------------------------------------------------------
        if op.type == 19:
            if op.param2 not in Bots:
                if op.param2 in Bots:
                    pass
                elif wait["protect"] == True:
                    wait ["blacklist"][op.param2] = True
                    cl.kickoutFromGroup(op.param1,[op.param2])
                    cl.inviteIntoGroup(op.param1,[op.param2])
                    
        if op.type == 13:
            if op.param2 not in Bots:
                if op.param2 in Bots:
                    pass
                elif wait["inviteprotect"] == True:
                    wait ["blacklist"][op.param2] = True
                    cl.kickoutFromGroup(op.param1,[op.param2])
                    if op.param2 not in Bots:
                        if op.param2 in Bots:
                            pass
                        elif wait["inviteprotect"] == True:
                            wait ["blacklist"][op.param2] = True
                            cl.cancelGroupInvitation(op.param1,[op.param3])
                            if op.param2 not in Bots:
                                if op.param2 in Bots:
                                    pass
                                elif wait["cancelprotect"] == True:
                                    wait ["blacklist"][op.param2] = True
                                    cl.cancelGroupInvitation(op.param1,[op.param3])
        if op.type == 11:
            if op.param2 not in Bots:
                if op.param2 in Bots:
                    pass
                elif wait["linkprotect"] == True:
                    wait ["blacklist"][op.param2] = True
                    G = cl.getGroup(op.param1)
                    G.preventJoinByTicket = True
                    cl.updateGroup(G)
                    cl.kickoutFromGroup(op.param1,[op.param2])
                    
        if op.type == 5:
            if wait["autoAdd"] == True:
                if (wait["message"] in [""," ","\n",None]):
                    pass
                else:
                    cl.sendText(op.param1,str(wait["message"]))

        if op.type == 11:
            if wait["linkprotect"] == True:
                if op.param2 not in Bots:
                    G = cl.getGroup(op.param1)
                    G.preventJoinByTicket = True
                    cl.kickoutFromGroup(op.param1,[op.param3])
                    cl.updateGroup(G)
                        
        if op.type == 55:
            try:
                if op.param1 in wait2['readPoint']:
           
                    if op.param2 in wait2['readMember'][op.param1]:
                        pass
                    else:
                        wait2['readMember'][op.param1] += op.param2
                    wait2['ROM'][op.param1][op.param2] = op.param2
                    with open('sider.json', 'w') as fp:
                     json.dump(wait2, fp, sort_keys=True, indent=4)
                else:
                    pass
            except:
                pass           
                    
                    
        if op.type == 59:
            print op
                
        if op.type == 55:
            try:
                group_id = op.param1
                user_id=op.param2
                subprocess.Popen('echo "'+ user_id+'|'+str(op.createdTime)+'" >> dataSeen/%s.txt' % group_id, shell=True, stdout=subprocess.PIPE, )
            except Exception as e:
                print e
                                
        if op.type == 55:
                try:
                    if cctv['cyduk'][op.param1]==True:
                        if op.param1 in cctv['point']:
                            Name = cl.getContact(op.param2).displayName
                            ginfo = cl.getGroup(op.param1)
                            dit = wait["siderset"]
                            contact = cl.getContact(op.param2)
                            image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                            if Name in cctv['sidermem'][op.param1]:
                                pass
                            else:
                                cctv['sidermem'][op.param1] += "\n• " + Name
                                if " " in Name:
                                    nick = Name.split(' ')
                                    if len(nick) == 2:
                                        time.sleep(0.2)
                                        summon(op.param1,[op.param2])
                                        cl.sendImageWithURL(op.param1,image)
                                        cl.sendText(op.param1, "『Aᴜᴛᴏsɪᴅᴇʀ』" + "\nEʜ ᴀᴅᴀ...🔥 " + nick[0] + " 🔥" + "\n" + dit)
                                    else:
                                        time.sleep(0.2)
                                        summon(op.param1,[op.param2])
                                        cl.sendImageWithURL(op.param1,image)
                                        cl.sendText(op.param1, "『Aᴜᴛᴏsɪᴅᴇʀ』" + "\nEʜ ᴀᴅᴀ...🔥 " + nick[1] + " 🔥" + "\n" + dit)
                                else:
                                    time.sleep(0.2)
                                    summon(op.param1,[op.param2])
                                    cl.sendImageWithURL(op.param1,image)
                                    cl.sendText(op.param1, "『Aᴜᴛᴏsɪᴅᴇʀ』" + "\nEʜ ᴀᴅᴀ...🔥 " + Name + " 🔥" + "\n" + dit)
                        else:
                            pass
                    else:
                        pass
                except:
                    pass
        else:
            pass 
#-------------------------------------------------------------------------------
        if op.type == 55:
            if op.param2 not in Bots:
                if op.param2 in admin and Bots and Owner:
                    pass
                elif wait["Kicksider"] == True:
                    wait["Sider"] == True
                    wait ["blacklist"][op.param2] = True
                    cl.kickoutFromGroup(op.param1,[op.param2])
#-------------------------------------------------------------------------------
        if op.type == 25:
            msg = op.message
            if msg.toType == 0:
                msg.to = msg.from_
                if msg.from_ == mid:
                    if "join:" in msg.text:
                        list_ = msg.text.split(":")
                        try:
                            cl.acceptGroupInvitationByTicket(list_[1],list_[2])
                            G = cl.getGroup(list_[1])
                            G.preventJoinByTicket = True
                            cl.updateGroup(G)
                        except:
                            cl.sendText(msg.to,"🔥 error")
#-------------------------------------------------------------------------------
            if msg.toType == 1:
                if wait["leaveRoom"] == True:
                    cl.leaveRoom(msg.to)
#-------------------------------------------------------------------------------
            if msg.contentType == 16:
                url = msg.contentMetadata["postEndUrl"]
                cl.like(url[25:58], url[66:], likeType=1001)
#-------------------------------------------------------------------------------
        if op.type == 26:
            msg = op.message
            if msg.from_ in mimic["target"] and mimic["status"] == True and mimic["target"][msg.from_] == True:
                    text = msg.text
                    if text is not None:
                        cl.sendText(msg.to,text)
#-------------------------------------------------------------------------------
        if op.type == 26 or op.type == 25:
            if msg.contentType == 7:
                if wait["sticker"] == True:
                    msg.contentType = 0
                    stk_id = msg.contentMetadata['STKID']
                    stk_ver = msg.contentMetadata['STKVER']
                    pkg_id = msg.contentMetadata['STKPKGID']
                    filler = "『 Sticker Check 』\nSTKID : %s\nSTKPKGID : %s\nSTKVER : %s\n『 Link 』\nline://shop/detail/%s" % (stk_id,pkg_id,stk_ver,pkg_id)
                    cl.sendText(msg.to, filler)
#                    wait["sticker"] = False
                else:
                    pass    
#-------------------------------------------------------------------------------
        if op.type == 26:
            msg = op.message
            if msg.to in settings["simiSimi"]:
                if settings["simiSimi"][msg.to] == True:
                    if msg.text is not None:
                        text = msg.text
                        r = requests.get("http://api.ntcorp.us/chatbot/v1/?text=" + text.replace(" ","+") + "&key=beta1.nt")
                        data = r.text
                        data = json.loads(data)
                        if data['status'] == 200:
                            if data['result']['result'] == 100:
                                cl.sendText(msg.to, "[ChatBOT] " + data['result']['response'].encode('utf-8'))
#-------------------------------------------------------------------------------
            if 'MENTION' in msg.contentMetadata.keys() != None:
                 if wait["detectMention"] == True:
                     contact = cl.getContact(msg.from_)
                     cName = contact.displayName
                     dit = wait["arespon"]
                     name = re.findall(r'@(\w+)', msg.text)
                     mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                     mentionees = mention['MENTIONEES']
                     for mention in mentionees:
                           if mention['M'] in Bots:
                                  cl.sendText(msg.to, "Hai.. ✒  " + cName + " \n ..😊😊😊.. " + dit +"\n")
                                  break            
                                    
            if 'MENTION' in msg.contentMetadata.keys() != None:
                 if wait["detectMention2"] == True:          
                    contact = cl.getContact(msg.from_)
                    cName = contact.displayName
                    balas = ["Ciee..." + cName + "Mau Ngasih Kado Yaa...",cName + " Ada Yang Bisa Saya Bantu Kak..?? \n" + cName,"Ada Apa Kak..??" + cName + " Kangen Aku Kah ??"]
                    ret_ = random.choice(balas)
                    name = re.findall(r'@(\w+)', msg.text)
                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                    mentionees = mention['MENTIONEES']
                    for mention in mentionees:
                           if mention['M'] in Bots:
                                  cl.sendText(msg.to,ret_)
                                  msg.contentType = 7   
                                  msg.text = None
                                  msg.contentMetadata = {
                                                       "STKID" : "5507",
                                                       "STKPKGID" : "608",
                                                       "STKVER" : "16" }
                                  cl.sendMessage(msg)                                
                                  break
                                    
            if 'MENTION' in msg.contentMetadata.keys() != None:
                 if wait["detectMention3"] == True:          
                    contact = cl.getContact(msg.from_)
                    cName = contact.displayName
                    balas = ["🔥 " + cName + "🔥"]
                    balas1 = "Gosah Tag Aim Lagi sibuk njiirr. . .??"
                    ret_ = random.choice(balas)
                    image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                    dit = wait["arespon"]
                    name = re.findall(r'@(\w+)', msg.text)
                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                    mentionees = mention['MENTIONEES']
                    for mention in mentionees:
                           if mention['M'] in Bots:
                                  cl.sendText(msg.to,ret_)
#                                 cl.sendText(msg.to,balas1)
                                  cl.sendImageWithURL(msg.to,image)
                                  cl.sendText(msg.to, "『Aᴜᴛᴏʀᴇsᴘᴏɴ』\n❂☞" + cName + "☜❂\n" + dit +"")
                                  msg.contentType = 7   
                                  msg.text = None
                                  msg.contentMetadata = {
                                                       "STKID" : "5507",
                                                       "STKPKGID" : "608",
                                                       "STKVER" : "16" }
                                  cl.sendMessage(msg)                                
                                  break
                                    
            if 'MENTION' in msg.contentMetadata.keys() != None:
                if wait["detectMentionpc"] == True:          
                    contact = cl.getContact(msg.from_)
                    cName = contact.displayName
                    balas = wait["comepc"]
                    name = re.findall(r'@(\w+)', msg.text)
                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                    mentionees = mention['MENTIONEES']
                    for mention in mentionees:
                        if mention['M'] in admin:
                                cl.sendText(msg.from_,balas)
                                msg.to = msg.from_
                                msg.contentType = 7   
                                msg.text = None
                                msg.contentMetadata =  {
                                                       "STKID": "410",
                                                       "STKPKGID": "1",
                                                       "STKVER": "100" }
                                cl.sendMessage(msg)                                
                                break
#-------------------------------------------------------------------------------
            if 'MENTION' in msg.contentMetadata.keys() != None:
                 if wait["kickMention"] == True:
                     contact = cl.getContact(msg.from_)
                     cName = contact.displayName
                     balas = ["Dont Tag Me!! Im Busy",cName + " Ngapain Ngetag?",cName + " Nggak Usah Tag-Tag! Kalo Penting Langsung Pc Aja","-_-","Gw lagi off", cName + " Kenapa Tag saya?","SPAM PC aja " + cName, "Jangan Suka Tag gua " + cName, "Kamu siapa " + cName + "?", "Ada Perlu apa " + cName + "?","Tenggelamkan tuh yang suka tag pake BOT","Tersummon -_-"]
                     ret_ = "[Auto Respond] " + random.choice(balas)
                     name = re.findall(r'@(\w+)', msg.text)
                     mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                     mentionees = mention['MENTIONEES']
                     for mention in mentionees:
                           if mention['M'] in Bots:
                                  cl.sendText(msg.to,ret_)
                                  cl.kickoutFromGroup(msg.to,[msg.from_])
                                  break
#-------------------------------------------------------------------------------
            if msg.toType == 2:
                if msg.text in dangerMessage:
                    wait["blacklist"] = True
                    if msg.from_ in admin and Bots:
                        pass
                    else:
                        if wait["protect"] == True:
                            try:
                                cl.kickoutFromGroup(msg.to,[msg.from_])
                                cl.sendText(msg.from_,"🔥 Wᴀᴛᴄʜ ʏᴏᴜʀ ᴡᴏʀᴅs...!!!")
                            except:
                                pass
                        else:
                            pass
                else:
                    pass
#---------------------------------------------------------------------
            if msg.contentType == 13:
                if wait['invite'] == True:
                    _name = msg.contentMetadata["displayName"]
                    invite = msg.contentMetadata["mid"]
                    groups = cl.getGroup(msg.to)
                    pending = groups.invitee
                    targets = []
                    for s in groups.members:
                        if _name in s.displayName:
                            cl.sendText(msg.to, _name + "🔥 Berada DiGrup Ini")
                        else:
                            targets.append(invite)
                    if targets == []:
                        pass
                    else:
                        for target in targets:
                            try:
                                cl.findAndAddContactsByMid(target)
                                cl.inviteIntoGroup(msg.to,[target])
                                cl.sendText(msg.to,"Invite " + _name)
                                wait['invite'] = False
                                break                              
                            except:             
                                    cl.sendText(msg.to,"Error")
                                    wait['invite'] = False
                                    break
#=============================[ Admin add Contact ]==================================
            if msg.contentType == 13:
                    if wait['admincipok'] == True:
                        wait['adminletak'] == False
                        _name = msg.contentMetadata["displayName"]
                        gs = msg.contentMetadata["mid"]
                        try:
                            admin[gs] = True
                            f=codecs.open('admin.json','w','utf-8')
                            json.dump(admin, f, sort_keys=True, indent=4,ensure_ascii=False)
                            cl.sendText(msg.to,"🔥 WL Dɪᴛᴀᴍʙᴀʜᴋᴀɴ\nKɪʀɪᴍ ᴋᴏɴᴛᴀᴋ ʟᴀɢɪ, ᴀᴛᴀᴜ ᴍᴀᴛɪᴋᴀɴ")
                        except:
                            pass
#----------------------------------------------------------------------------
            if msg.contentType == 13:
                    if wait['adminletak'] == True:
                        wait['adminletak'] == False
                        _name = msg.contentMetadata["displayName"]
                        gs = msg.contentMetadata["mid"]
                        try:
                            del admin[gs]
                            f=codecs.open('admin.json','w','utf-8')
                            json.dump(admin, f, sort_keys=True, indent=4,ensure_ascii=False)
                            cl.sendText(msg.to,"🔥 WL Dɪʜᴀᴘᴜs\nKɪʀɪᴍ ᴋᴏɴᴛᴀᴋ ʟᴀɢɪ, ᴀᴛᴀᴜ ᴍᴀᴛɪᴋᴀɴ")
                        except:
                            pass
#=============================[ Admin add Contact ]==================================
            if msg.contentType == 13:
                if wait["steal"] == True:
                    _name = msg.contentMetadata["displayName"]
                    copy = msg.contentMetadata["mid"]
                    groups = cl.getGroup(msg.to)
                    pending = groups.invitee
                    targets = []
                    for s in groups.members:
                        if _name in s.displayName:
                            print "[Target] Stealed"
                            break                             
                        else:
                            targets.append(copy)
                    if targets == []:
                        pass
                    else:
                        for target in targets:
                            try:
                                cl.findAndAddContactsByMid(target)
                                contact = cl.getContact(target)
                                cu = cl.channel.getCover(target)
                                path = str(cu)
                                image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                                cl.sendText(msg.to,"Nama :\n" + contact.displayName + "\n\nMid :\n" + msg.contentMetadata["mid"] + "\n\nBio :\n" + contact.statusMessage)
                                cl.sendText(msg.to,"Profile Picture " + contact.displayName)
                                cl.sendImageWithURL(msg.to,image)
                                cl.sendText(msg.to,"Cover " + contact.displayName)
                                cl.sendImageWithURL(msg.to,path)
                                wait["steal"] = False
                                break
                            except:
                                    pass    
#-------------------------------------------------------------------------------
            if msg.contentType == 16:
                if wait["likeOn"] == True:
                    url = msg.contentMetadata["postEndUrl"]
                    cl.like(url[25:58], url[66:], likeType=1005)
                    cl.comment(url[25:58], url[66:], wait["comment"])
                    cl.sendText(msg.to,"🔥 Like Success") 
                    wait["likeOn"] == False
#-------------------------------------------------------------------------------
            if wait["alwayRead"] == True:
                if msg.toType == 0:
                    cl.sendChatChecked(msg.from_,msg.id)
                else:
                    cl.sendChatChecked(msg.to,msg.id)
#-------------------------------------------------------------------------------
        if op.type == 17:
          if wait["joinkick"] == True:
            if op.param2 in admin:
              if op.param2 in Bots:
                return
            cl.kickoutFromGroup(op.param1,[op.param2])
            print "MEMBER JOIN KICK TO GROUP"
#-------------------------------------------------------------------------------
        if op.type == 17:
            if wait["Sambutan"] == True:
                if op.param2 in Bots:
                    return
                ginfo = cl.getGroup(op.param1)
                contact = cl.getContact(op.param2)
                image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                jawaban1 = ("Selamat Datang Di Grup " + str(ginfo.name))
                tts = gTTS(text=jawaban1, lang='id')
                tts.save('tts.mp3')
                dit = wait["comegreat"]
                cl.sendText(op.param1,"╔════ஜ🔥  🔥ஜ════╗\n╠👉    WELCOME     \n╚════ஜ🔥 🔥ஜ════╝")
                cl.sendImageWithURL(op.param1,image) 
                cl.sendText(op.param1,"╔══════ஜ 🔥 ஜ══════\n╠👉 Hᴇʟʟᴏ...🔥" + cl.getContact(op.param2).displayName + "\n╠⚖ Selamat Datang Di" + str(ginfo.name) + " 🔥" + "\n╠🔰"  + dit)
                print "MEMBER JOIN TO GROUP"
#-------------------------------------------------------------------------------
        if op.type == 15:
            if wait["Sambutan"] == True:
                if op.param2 in Bots:
                    return
                image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                dit = wait["leftgreat"]
                cl.sendImageWithURL(op.param1,image)
                cl.sendText(op.param1,"🔥 Good Bye... " + cl.getContact(op.param2).displayName +  "\n" + dit)
#  	            cl.sendImageWithURL(op.param1,image)
                d = Message(to=op.param1, from_=None, text=None, contentType=7)
                d.contentMetadata = {
                                    "STKID": "14741438",
                                    "STKPKGID": "1376009",
                                    "STKVER": "1"}
                cl.sendMessage(d)
                print "MEMBER HAS LEFT THE GROUP"
#-------------------------------------------------------------------------------
        if op.type == 25:
            msg = op.message
            if msg.contentType == 13:
                if wait["wblack"] == True:
                    if msg.contentMetadata["mid"] in wait["commentBlack"]:
                        cl.sendText(msg.to,"🔥 In Blacklist")
                        wait["wblack"] = False
                    else:
                        wait["commentBlack"][msg.contentMetadata["mid"]] = True
                        wait["wblack"] = False
                        cl.sendText(msg.to,"🔥 Nothing")
                elif wait["dblack"] == True:
                    if msg.contentMetadata["mid"] in wait["commentBlack"]:
                        del wait["commentBlack"][msg.contentMetadata["mid"]]
                        cl.sendText(msg.to,"❂➤Done")
                        wait["dblack"] = False
                    else:
                        wait["dblack"] = False
                        cl.sendText(msg.to,"🔥 Not in Blacklist")
                elif wait["wblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["blacklist"]:
                        cl.sendText(msg.to,"In Blacklist")
                        wait["wblacklist"] = False
                    else:
                        wait["blacklist"][msg.contentMetadata["mid"]] = True
                        wait["wblacklist"] = False
                        cl.sendText(msg.to,"🔥 Done")
                elif wait["dblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["blacklist"]:
                        del wait["blacklist"][msg.contentMetadata["mid"]]
                        cl.sendText(msg.to,"🔥 Done")
                        wait["dblacklist"] = False
                    else:
                        wait["dblacklist"] = False
                        cl.sendText(msg.to,"🔥 Done")
                elif wait["contact"] == True:
                    msg.contentType = 0
                    cl.sendText(msg.to,msg.contentMetadata["mid"])
                    if 'displayName' in msg.contentMetadata:
                        contact = cl.getContact(msg.contentMetadata["mid"])
                        try:
                            cu = cl.channel.getCover(msg.contentMetadata["mid"])
                        except:
                            cu = ""
                        cl.sendText(msg.to,"[displayName]:\n" + msg.contentMetadata["displayName"] + "\n[mid]:\n" + msg.contentMetadata["mid"] + "\n[statusMessage]:\n" + contact.statusMessage + "\n[pictureStatus]:\nhttp://dl.profile.line-cdn.net/" + contact.pictureStatus + "\n[coverURL]:\n" + str(cu))
                    else:
                        contact = cl.getContact(msg.contentMetadata["mid"])
                        try:
                            cu = cl.channel.getCover(msg.contentMetadata["mid"])
                        except:
                            cu = ""
                        cl.sendText(msg.to,"[displayName]:\n" + contact.displayName + "\n[mid]:\n" + msg.contentMetadata["mid"] + "\n[statusMessage]:\n" + contact.statusMessage + "\n[pictureStatus]:\nhttp://dl.profile.line-cdn.net/" + contact.pictureStatus + "\n[coverURL]:\n" + str(cu))
#-------------------------------------------------------------------------------
            elif msg.contentType == 16:
                if wait["timeline"] == True:
                    msg.contentType = 0
                    if wait["lang"] == "JP":
                        msg.text = "menempatkan URL\n" + msg.contentMetadata["postEndUrl"]
                    else:
                        msg.text = msg.contentMetadata["postEndUrl"]
                    cl.sendText(msg.to,msg.text)
#-------------------------------------------------------------------------------
            elif msg.text is None:
                return
#======================================================================================#
#===============================[ JK HELP START ]================================#
#======================================================================================#  
            elif msg.text.lower() == 'help':
                if wait["lang"] == "JP":
                    cl.sendText(msg.to,helpmsg)
                else:
                    cl.sendText(msg.to,helpmsg)
            elif msg.text.lower() == 'help pc':
                if wait["lang"] == "JP":
                    cl.sendText(msg.to,helppc)
                else:
                    cl.sendText(msg.to,helppc)
            elif msg.text.lower() == 'help self':
                if wait["lang"] == "JP":
                    cl.sendText(msg.to,helpself)
                else:
                    cl.sendText(msg.to,helpself)
            elif msg.text.lower() == 'help grup':
                if wait["lang"] == "JP":
                    cl.sendText(msg.to,helpgrup)
                else:
                    cl.sendText(msg.to,helpgrup)
            elif msg.text.lower() == 'help set':
                if wait["lang"] == "JP":
                    cl.sendText(msg.to,helpset)
                else:
                    cl.sendText(msg.to,helpset)
            elif msg.text.lower() == 'help costume':
                if wait["lang"] == "JP":
                    cl.sendText(msg.to,helpcostume)
                else:
                    cl.sendText(msg.to,helpset)
            elif msg.text.lower() == 'help media':
                if wait["lang"] == "JP":
                    cl.sendText(msg.to,helpmed)
                else:
                    cl.sendText(msg.to,helpmed)
            elif msg.text.lower() == 'help other':
                if wait["lang"] == "JP":
                    cl.sendText(msg.to,helpother)
                else:
                    cl.sendText(msg.to,helpother)
            elif msg.text.lower() == 'help kick':
                if wait["lang"] == "JP":
                    cl.sendText(msg.to,helpkick)
                else:
                    cl.sendText(msg.to,helpkick)

#======================================================================================#
#===============================[ JK PC START ]==================================#
#======================================================================================#  

            elif msg.text.lower() == 'ifconfig':
                if msg.from_ in Owner and admin and Bots:
                    botKernel = subprocess.Popen(["ifconfig"], stdout=subprocess.PIPE).communicate()[0]
                    cl.sendText(msg.to, botKernel + "\n\n===SERVER INFO NetStat===")
#-------------------------------------------------------------------------------
            elif msg.text.lower() == 'system':
                if msg.from_ in Owner and admin and Bots:
                    botKernel = subprocess.Popen(["df","-h"], stdout=subprocess.PIPE).communicate()[0]
                    cl.sendText(msg.to, botKernel + "\n\n===SERVER INFO SYSTEM===")
#-------------------------------------------------------------------------------
            elif msg.text.lower() == 'kernel':
                if msg.from_ in Owner and admin and Bots:
                    botKernel = subprocess.Popen(["uname","-srvmpio"], stdout=subprocess.PIPE).communicate()[0]
                    cl.sendText(msg.to, botKernel + "\n\n===SERVER INFO KERNEL===")
#-------------------------------------------------------------------------------
            elif msg.text.lower() == 'cpu':
                if msg.from_ in Owner and admin and Bots:
                    botKernel = subprocess.Popen(["cat","/proc/cpuinfo"], stdout=subprocess.PIPE).communicate()[0]
                    cl.sendText(msg.to, botKernel + "\n\n===SERVER INFO CPU===")
#-------------------------------------------------------------------------------
            elif msg.text in ["Sp","Speed","speed"]:
                if msg.from_ in Owner and admin and Bots:
                    start = time.time()
                    cl.sendText(msg.to, "Progress...")
                    elapsed_time = time.time() - start
                    cl.sendText(msg.to, "%sseconds" % (elapsed_time))
#-------------------------------------------------------------------------------
            elif "Restart" in msg.text:
                if msg.from_ in Owner:
                    print "[Command]Restart"
                    try:
                        cl.sendText(msg.to,"🔥 Rᴇsᴛᴀʀᴛɪɴɢ...\nLoading\n█▒▒▒▒▒▒▒▒▒\n10%\n███▒▒▒▒▒▒▒\n30%\n█████▒▒▒▒▒\n50%\n███████▒▒▒\n100%\n██████████")
                        cl.sendText(msg.to,"🔥 Rᴇsᴛᴀʀᴛ Sᴜᴄᴄᴇss")
                        restart_program()
                    except:
                        cl.sendText(msg.to,"🔥 Pʟᴇᴀsᴇ ᴡᴀɪᴛ")
                        restart_program()
                        pass
#-------------------------------------------------------------------------------
            elif "Turn off" in msg.text:
                if msg.from_ in Owner:
                    try:
                        import sys
                        sys.exit()
                    except:
                        pass
                        
            elif cms(msg.text,["Matikan"]):
                if msg.from_ in Owner:
                    cl.sendText(msg.to,"Reboot")
                    exit(1)
#-------------------------------------------------------------------------------
            elif msg.text.lower() == 'runtime':
                if msg.from_ in Owner:
                    eltime = time.time() - mulai
                    van = "🔥 Bot has been active "+waktu(eltime)
                    cl.sendText(msg.to,van) 
#======================================================================================# 
#===============================[ JK STATUS START ]==============================#
#======================================================================================# 
            elif msg.text.lower() == 'status':
                if msg.from_ in Owner and admin and Bots:
                    today = datetime.today()
                    future = datetime(2018,06,07)
                    days = (str(future - today))
                    comma = days.find(",")
                    days = days[:comma]
                    dit = wait["arespon"]
                    dat = wait["comepc"]
                    dut = wait["comegreat"]
                    dot = wait["leftgreat"]
                    det = wait["addgreat"]
                    crot = wait["siderset"]
                    crit = wait["comment"]
                    md = ""
                    md+="╚══ஜ🔥Pʀᴏᴛᴇᴄᴛ🔥ஜ══╝\n"
                    if wait["protect"] == True: md+="🔰 Pʀᴏᴛᴇᴄᴛ: Oɴ \n"
                    else:md+="🔰 Pʀᴏᴛᴇᴄᴛ: Oғғ \n"
                    if wait["inviteprotect"] == True: md+="🔰 Iɴᴠɪᴛᴀᴛɪᴏɴ Pʀᴏᴛᴇᴄᴛ: Oɴ \n"
                    else:md+="🔰 Iɴᴠɪᴛᴀᴛɪᴏɴ Pʀᴏᴛᴇᴄᴛ: Oғғ \n"
                    if wait["cancelprotect"] == True: md+="🔰 Cᴀɴᴄᴇʟ Pʀᴏᴛᴇᴄᴛ: Oɴ \n"
                    else:md+="🔰 Cᴀɴᴄᴇʟ Pʀᴏᴛᴇᴄᴛ: Oғғ \n"
                    if wait["linkprotect"] == True: md+="🔰 Lɪɴᴋ Pʀᴏᴛᴇᴄᴛ: Oɴ \n"
                    else:md+="🔰 Lɪɴᴋ Pʀᴏᴛᴇᴄᴛ: Oғғ \n"
                    md+="╠═══ஜ🔥Sᴇʟғ🔥ஜ═══╣\n"
                    if wait["autoJoin"] == True: md+="🔰 Aᴜᴛᴏ Jᴏɪɴ: Oɴ \n"
                    else: md +="🔰 Aᴜᴛᴏ Jᴏɪɴ: Oғғ \n"
                    if wait["leaveRoom"] == True: md+="🔰 Aᴜᴛᴏ ʟᴇᴀᴠᴇ: Oɴ \n"
                    else: md+="🔰 Aᴜᴛᴏ ʟᴇᴀᴠᴇ: Oғғ \n"
                    if wait["contact"] == True: md+="🔰 Cᴏɴᴛᴀᴄᴛ: Oɴ  \n"
                    else: md+="🔰 Cᴏɴᴛᴀᴄᴛ: Oғғ \n"
                    if wait["autoCancel"] == True: md+="🔰 Auto cancel: Oɴ \n"
                    else: md+= "🔰 Gʀᴏᴜᴘ ᴄᴀɴᴄᴇʟ: Oғғ \n"
                    if wait["timeline"] == True: md+="🔰 Sʜᴀʀᴇ: Oɴ \n"
                    else:md+="🔰 Sʜᴀʀᴇ: Oғғ \n"
                    if wait["clock"] == True: md+="🔰 Jᴀᴍ: Oɴ \n"
                    else:md+="🔰 Jᴀᴍ: Oғғ \n"
                    if wait["likeOn"] == True: md+="🔰 Aᴜᴛᴏ Lɪᴋᴇ: Oɴ \n"
                    else:md+="🔰 Aᴜᴛᴏ Lɪᴋᴇ: Oғғ \n"
                    if wait["autoAdd"] == True: md+="🔰 Aᴜᴛᴏ ᴀᴅᴅ: Oɴ \n"
                    else:md+="🔰 Aᴜᴛᴏ ᴀᴅᴅ: Oғғ \n"
                    if wait["alwayRead"] == True: md+="🔰 Aᴜᴛᴏ Rᴇᴀᴅ: Oɴ \n"
                    else:md+="🔰 Aᴜᴛᴏ Rᴇᴀᴅ: Oғғ \n"
                    if wait["detectMention3"] == True: md+="🔰 Aᴜᴛᴏʀᴇsᴘᴏɴ: Oɴ \n"
                    else:md+="🔰 Aᴜᴛᴏʀᴇsᴘᴏɴ: Oғғ \n"
                    if wait["detectMentionpc"] == True: md+="🔰 Pᴄʀᴇsᴘᴏɴ: Oɴ \n"
                    else:md+="🔰 Pᴄʀᴇsᴘᴏɴ: Oғғ \n"
                    if mimic["status"] == True: md+="😋 Mɪᴍɪᴄ: Oɴ \n"
                    else:md+="🔰 Mɪᴍɪᴄ: Oғғ \n"
                    if settings["simiSimi"] == True: md+="🔰 Sɪᴍɪsɪᴍɪ Oɴ \n"
                    else:md+="🔰Sɪᴍɪsɪᴍɪ: Oғғ \n"
                    if wait["commentOn"] == True: md+="🔰 Cᴏᴍᴍᴇɴᴛ: Oɴ \n"
                    else:md+="🔰 Cᴏᴍᴍᴇɴᴛ: Oғғ \n"
                    if wait["Sambutan"] == True: md+="🔰 Wᴇʟᴄᴏᴍᴇ: Oɴ \n"
                    else:md+="🔰 Wᴇʟᴄᴏᴍᴇ: Oғғ \n"
                    if wait["sticker"] == True: md+="🔰 Dᴇᴛᴇᴄᴛ Sᴛɪᴄᴋᴇʀ: Oɴ \n"
                    else:md+="🔰 Dᴇᴛᴇᴄᴛ Sᴛɪᴄᴋᴇʀ: Oғғ \n"
                    if wait["Sider"] == True: md+="🔰 Aᴜᴛᴏ sɪᴅᴇʀ: Oɴ \n"
                    else:md+="🔰 Aᴜᴛᴏ sɪᴅᴇʀ: Oғғ \n"
                    if wait["Kicksider"] == True: md+="🔰 Aᴜᴛᴏᴋɪᴄᴋ sɪᴅᴇʀ: Oɴ \n"
                    else:md+="🔰 Aᴜᴛᴏᴋɪᴄᴋ sɪᴅᴇʀ: Oғғ \n"
                    if wait["kickMention"] == True: md+="🔰 Rᴇsᴘᴏɴᴋɪᴄᴋ: Oɴ \n"
                    else:md+="🔰 Rᴇsᴘᴏɴᴋɪᴄᴋ: Oғғ \n"
                    if wait["joinkick"] == True: md+="🔰 Jᴏɪɴᴋɪᴄᴋ: Oɴ \n"
                    else:md+="🔰 Jᴏɪɴᴋɪᴄᴋ: Oғғ \n"
                    md+="╠═ஜ🔥ᴄᴏSᴛᴜᴍᴇSᴇᴛ🔥ஜ═╣"
                    md+="\n⚖RᴇsᴘᴏɴSᴇᴛ:" + dit + ""
                    md+="\n⚖PᴄʀᴇSᴘᴏɴSᴇᴛ:" + dat + ""
                    md+="\n⚖CᴏᴍᴇɢʀᴇᴀᴛSᴇᴛ:" + dut + ""
                    md+="\n⚖LᴇғᴛɢʀᴇᴀᴛSᴇᴛ:" + dot + ""
                    md+="\n⚖AᴅᴅɢʀᴇᴀᴛSᴇᴛ:" + det + ""
                    md+="\n⚖SɪᴅᴇʀSᴇᴛ:" + crot + ""
                    md+="\n╔═══🔥^$€^™^β¤t^🔥══╗\n╚> line.me/ti/p/mt6qgzsLee <╝"
                    cl.sendText(msg.to,"╔═══>ஜ 🎓 ஜ<═══╗\n║              ⚖-Sᴛᴀᴛᴜᴤ-⚖\n"+md)
#-------------------------------------------------------------------------------#  
            elif msg.text in ["Wlcip","Allcipok"]:
                if msg.from_ in Owner:
                    wait["admincipok"] = True
                    cl.sendText(msg.to,"🔥 Pʟᴇᴀsᴇ sᴇɴᴅ ᴄᴏɴᴛᴀᴄᴛs ғʀᴏᴍ ᴛʜᴇ ᴘᴇʀsᴏɴ ʏᴏᴜ ᴡᴀɴᴛ ᴛᴏ ᴀᴅᴅ WL")
                else:
                    cl.sendText(msg.to,"🔥  Cᴏᴍᴍᴀɴᴅ Fᴏʀ Oᴡɴᴇʀ")
#-------------------------------------------------------------------------------#  
            elif msg.text in ["Wlet","Allletak"]:
                if msg.from_ in Owner:
                    wait["adminletak"] = True
                    cl.sendText(msg.to,"🔥 Pʟᴇᴀsᴇ sᴇɴᴅ ᴄᴏɴᴛᴀᴄᴛs ғʀᴏᴍ ᴛʜᴇ ᴘᴇʀsᴏɴ ʏᴏᴜ ᴡᴀɴᴛ ᴛᴏ ʀᴇᴍᴏᴠᴇ WL")
                else:
                    cl.sendText(msg.to,"🔥  Cᴏᴍᴍᴀɴᴅ Fᴏʀ Oᴡɴᴇʀ")
#======================================================================================#  
            elif "Wladd @" in msg.text:
              if msg.from_ in Owner:
                print "[Command]Wl executing"
                _name = msg.text.replace("Wladd @","")
                _nametarget = _name.rstrip('  ')
                gs = cl.getGroup(msg.to)
                targets = []
                for g in gs.members:
                    if _nametarget == g.displayName:
                        targets.append(g.mid)
                if targets == []:
                   cl.sendText(msg.to,"🔥 Cᴏɴᴛᴀᴄᴛ ɴᴏᴛ ғᴏᴜɴᴅ")
                else:
                   for target in targets:
                        try:
                            admin.append(target)
                            cl.sendText(msg.to,"🔥 WL Dɪᴛᴀᴍʙᴀʜᴋᴀɴ")
                        except:
                            pass
                print "[Command]Whitelist add executed"
              else:
                cl.sendText(msg.to,"🔥 Cᴏᴍᴍᴀɴᴅ ᴅᴇɴɪᴇᴅ")
                cl.sendText(msg.to,"🔥 Oᴡɴᴇʀ ᴘᴇʀᴍɪssɪᴏɴ ʀᴇǫᴜɪʀᴇᴅ")
                
            elif "Wlrem @" in msg.text:
              if msg.from_ in Owner:
                print "[Command]Staff remove executing"
                _name = msg.text.replace("Wlrem @","")
                _nametarget = _name.rstrip('  ')
                gs = cl.getGroup(msg.to)
                targets = []
                for g in gs.members:
                    if _nametarget == g.displayName:
                        targets.append(g.mid)
                if targets == []:
                   cl.sendText(msg.to,"🔥 Cᴏɴᴛᴀᴄᴛ ɴᴏᴛ ғᴏᴜɴᴅ")
                else:
                   for target in targets:
                        try:
                            admin.remove(target)
                            cl.sendText(msg.to,"🔥 WL Dɪʜᴀᴘᴜs")
                        except:
                            pass
                print "[Command]Whitelist remove executed"
              else:
                cl.sendText(msg.to,"🔥 Cᴏᴍᴍᴀɴᴅ ᴅᴇɴɪᴇᴅ")
                cl.sendText(msg.to,"🔥 Oᴡɴᴇʀ ᴘᴇʀᴍɪssɪᴏɴ ʀᴇǫᴜɪʀᴇᴅ")
#-------------------------------------------------------------------------------
            elif msg.text in ["Wlist","wlist"]:
                if msg.from_ in Owner and admin and Bots:
                    if admin == []:
                        cl.sendText(msg.to,"Whitelist is empty")
                    else:
                        cl.sendText(msg.to,"Tunggu...")
                        mc = "╔═══════ஜ۩۞۩ஜ══════╗\n║           || 🔰-Whitelist-🔰 ||\n╠══════════════════╣\n"
                        for mi_d in admin:
                            mc += "╠⌬" +cl.getContact(mi_d).displayName + "\n"
                        cl.sendText(msg.to,mc)
                        print "[Command]Wllist executed"

#======================================================================================#
#================================[ JK SET START ]================================#
#======================================================================================# 

            elif msg.text.lower() == 'protect on':
                if msg.from_ in Owner:
                    if wait["protect"] == True:
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"🔥 Pʀᴏᴛᴇᴄᴛɪᴏɴ ᴀʟʀᴇᴀᴅʏ ᴏɴ")
                        else:
                            cl.sendText(msg.to,"🔥 Pʀᴏᴛᴇᴄᴛɪᴏɴ sᴇᴛ ᴛᴏ ᴏɴ")
                    else:
                        wait["protect"] = True
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"🔥 Pʀᴏᴛᴇᴄᴛɪᴏɴ sᴇᴛ ᴛᴏ ᴏɴ")
                        else:
                            cl.sendText(msg.to,"🔥 Pʀᴏᴛᴇᴄᴛɪᴏɴ ᴀʟʀᴇᴀᴅʏ ᴏɴ")
                            
            elif msg.text.lower() == 'protect off':
                if msg.from_ in Owner:
                    if wait["protect"] == False:
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"🔥 Pʀᴏᴛᴇᴄᴛɪᴏɴ ᴀʟʀᴇᴀᴅʏ ᴏғғ")
                        else:
                            cl.sendText(msg.to,"🔥  Pʀᴏᴛᴇᴄᴛɪᴏɴ sᴇᴛ ᴛᴏ ᴏғғ")
                    else:
                        wait["protect"] = False
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"🔥 Pʀᴏᴛᴇᴄᴛɪᴏɴ sᴇᴛ ᴛᴏ ᴏғғ")
                        else:
                            cl.sendText(msg.to,"🔥  Pʀᴏᴛᴇᴄᴛɪᴏɴ ᴀʟʀᴇᴀᴅʏ ᴏғғ")
#-------------------------------------------------------------------------------
            elif msg.text.lower() == 'qr on':
                if msg.from_ in Owner:
                    if wait["linkprotect"] == True:
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"🔥 Pʀᴏᴛᴇᴄᴛɪᴏɴ Qʀ ᴀʟʀ